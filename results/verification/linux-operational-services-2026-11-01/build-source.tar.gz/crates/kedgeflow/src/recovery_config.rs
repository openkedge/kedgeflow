//! Operator-owned recovery deployment. No listener or target mutation API.
use crate::{
    clock::SystemClock,
    config::key,
    contracts::{GrantVerifier, strict_value},
    error::{Error, Result},
    grant_reference::{bounded_response, fixed_https},
    ledger::{AuthoritativeObservation, EtcdLedger, OutcomeQuerier},
    recovery::{PROFILE, RecoveryWorker},
    service_files::ServiceFiles,
};
use async_trait::async_trait;
use ed25519_dalek::{SigningKey, VerifyingKey};
use serde::Deserialize;
use serde_json::json;
use std::{collections::BTreeMap, path::PathBuf, sync::Arc, time::Duration};

pub struct HttpOutcomeQuerier {
    client: reqwest::Client,
    url: reqwest::Url,
    token: String,
}
impl HttpOutcomeQuerier {
    pub fn new(client: reqwest::Client, url: &str, token: String) -> Result<Self> {
        if token.trim().is_empty() {
            return Err(Error::Invalid("query credential required".into()));
        }
        Ok(Self {
            client,
            url: fixed_https(url)?,
            token,
        })
    }
}
#[async_trait]
impl OutcomeQuerier for HttpOutcomeQuerier {
    async fn query(&self, id: &str) -> Result<AuthoritativeObservation> {
        if id.is_empty() || id.len() > 1024 {
            return Err(Error::Invalid("invalid attempt query".into()));
        }
        let response = self
            .client
            .post(self.url.clone())
            .bearer_auth(&self.token)
            .json(&json!({"profile":PROFILE,"operation":"query","attempt_id":id}))
            .timeout(Duration::from_secs(5))
            .send()
            .await?;
        if response.url() != &self.url || !response.status().is_success() {
            return Err(Error::Unavailable("target query failed".into()));
        }
        let raw = bounded_response(response, 65536).await?;
        let value = strict_value(&raw)?;
        crate::recovery::validate(&value)?;
        let observation: AuthoritativeObservation = serde_json::from_value(value)?;
        if observation.attempt_id != id {
            return Err(Error::Unknown("uncorrelated query response".into()));
        }
        Ok(observation)
    }
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RecoveryConfig {
    #[serde(
        default,
        deserialize_with = "crate::compensation_execution::deserialize_execution"
    )]
    pub inverse_execution: Option<crate::compensation_execution::ExecutionConfig>,
    #[serde(default, deserialize_with = "crate::family::deserialize_selection")]
    pub family: Option<crate::family::Selection>,
    #[serde(
        default,
        deserialize_with = "crate::action_domain::deserialize_selection"
    )]
    pub action_domain: Option<crate::action_domain::Selection>,
    #[serde(default)]
    pub reservation: Option<crate::reserved_leaf::Registration>,
    #[serde(default)]
    pub restore_gate: Option<crate::restore::RestoreGateConfig>,
    pub etcd_endpoint: String,
    pub etcd_prefix: String,
    pub etcd_ca: PathBuf,
    pub etcd_certificate: PathBuf,
    pub etcd_private_key: PathBuf,
    pub etcd_token_file: PathBuf,
    pub gateway_audience: String,
    pub grant_keys: BTreeMap<String, String>,
    pub query_url: String,
    pub query_ca: PathBuf,
    pub query_certificate: PathBuf,
    pub query_private_key: PathBuf,
    pub query_token_file: PathBuf,
    pub receipt_key_id: String,
    pub receipt_signing_key_file: PathBuf,
    pub source_id: String,
    pub page_size: usize,
    pub poll_interval_ms: u64,
}
impl RecoveryConfig {
    pub fn decode(raw: &[u8]) -> Result<Self> {
        if raw.len() > 1 << 20 {
            return Err(Error::Invalid(
                "recovery configuration exceeds bound".into(),
            ));
        }
        let c: Self = serde_json::from_value(strict_value(raw)?)?;
        if !(1..=64).contains(&c.page_size)
            || !(100..=60000).contains(&c.poll_interval_ms)
            || c.grant_keys.is_empty()
        {
            return Err(Error::Invalid("invalid recovery polling bounds".into()));
        }
        fixed_https(&c.etcd_endpoint)?;
        fixed_https(&c.query_url)?;
        fixed_https(&c.gateway_audience)?;
        Ok(c)
    }
    pub async fn worker(&self) -> Result<RecoveryWorker> {
        self.worker_with_files(&ServiceFiles::default()).await
    }
    pub async fn worker_with_files(&self, files: &ServiceFiles) -> Result<RecoveryWorker> {
        let client = files
            .http_client(
                &self.etcd_ca,
                &self.etcd_certificate,
                &self.etcd_private_key,
                Duration::from_secs(5),
            )
            .await?;
        let mut ledger = EtcdLedger::new(client, &self.etcd_endpoint, &self.etcd_prefix)?
            .with_auth_token(&files.secret(&self.etcd_token_file).await?)?;
        if let Some(r) = &self.reservation {
            if r.scope.audience != self.gateway_audience
                || crate::control_config::keys(&r.issuer_keys)?
                    != crate::control_config::keys(&self.grant_keys)?
            {
                return Err(Error::Invalid(
                    "reserved recovery role/scope mismatch".into(),
                ));
            }
            ledger = ledger.requiring_control(None).with_reservation(r.clone())?;
        }
        if let Some(s) = &self.action_domain {
            ledger = ledger.with_action_domain(s.clone())?;
        }
        if let Some(e) = &self.inverse_execution {
            ledger = e.attach(ledger)?;
        }
        if let Some(family) = &self.family {
            ledger = family.attach(ledger)?;
        }
        if let Some(gate) = &self.restore_gate {
            ledger = gate.attach_with_files(ledger, files).await?;
        }
        let client = files
            .http_client(
                &self.query_ca,
                &self.query_certificate,
                &self.query_private_key,
                Duration::from_secs(5),
            )
            .await?;
        // The exact protected family member selects the wire binding. No
        // caller-supplied flag changes a generic query into physical authority.
        let physical = match &self.family {
            Some(s) => match &s.registration.composition {
                Some(plan) => plan.node(&s.child_id)?.physical.is_some(),
                None => false,
            },
            None => false,
        };
        let token = files.secret(&self.query_token_file).await?;
        let query: Arc<dyn OutcomeQuerier> = if physical {
            Arc::new(crate::kube_drain_query::ControllerQuery::new(
                client,
                &self.query_url,
                token,
            )?)
        } else {
            Arc::new(HttpOutcomeQuerier::new(client, &self.query_url, token)?)
        };
        let keys = self
            .grant_keys
            .iter()
            .map(|(id, k)| {
                Ok((
                    id.clone(),
                    VerifyingKey::from_bytes(&key(k)?)
                        .map_err(|_| Error::Invalid("invalid grant key".into()))?,
                ))
            })
            .collect::<Result<BTreeMap<_, _>>>()?;
        RecoveryWorker::new(
            ledger,
            GrantVerifier {
                keys,
                audience: self.gateway_audience.clone(),
            },
            query,
            self.receipt_key_id.clone(),
            SigningKey::from_bytes(&key(&files.secret(&self.receipt_signing_key_file).await?)?),
            self.source_id.clone(),
            Arc::new(SystemClock),
        )
    }
}
