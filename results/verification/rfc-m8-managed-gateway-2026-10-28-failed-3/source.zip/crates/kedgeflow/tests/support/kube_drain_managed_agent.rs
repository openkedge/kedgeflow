//! Actual official MCP agent -> admission/issuer -> broker/gateway -> shipping
//! managed controller/current SQL source; independent operating/physical audit.
use super::super::super::process::agent as common;
use super::*;

fn native_ledger(
    r: &Ready,
    source: &SourceProcess,
    pki: &support::Pki,
    credential: &str,
) -> kedgeflow::ledger::EtcdLedger {
    let client = kedgeflow::tls::pinned_client_pem(
        pki.ca.as_bytes(),
        pki.client.as_bytes(),
        pki.client_key.as_bytes(),
        Duration::from_secs(5),
    )
    .unwrap();
    kedgeflow::family::Selection {
        registration: r.r.clone(),
        child_id: "child-1".into(),
    }
    .attach(
        kedgeflow::ledger::EtcdLedger::new(
            client.client().clone(),
            &source._relay.url,
            &r.r.namespace,
        )
        .unwrap()
        .with_auth_token(credential)
        .unwrap(),
    )
    .unwrap()
}
async fn recover(
    r: &Ready,
    source: &SourceProcess,
    process: &Process,
    identity: &[support::Pki],
) -> Value {
    // This recovery root contains its own native/query credentials and outcome
    // signer only. It never imports the controller/source/observer signing keys.
    let directory = tempfile::tempdir().unwrap();
    std::fs::set_permissions(directory.path(), std::fs::Permissions::from_mode(0o700)).unwrap();
    let dir = directory.path().canonicalize().unwrap();
    let write = |name: &str, bytes: &[u8]| {
        let path = dir.join(name);
        std::fs::write(&path, bytes).unwrap();
        std::fs::set_permissions(&path, std::fs::Permissions::from_mode(0o600)).unwrap();
        path
    };
    let native = &identity[7];
    let ca = write("native-ca.pem", native.ca.as_bytes());
    let cert = write("native.pem", native.client.as_bytes());
    let key = write("native.key", native.client_key.as_bytes());
    let native_token = write("native.token", OUTCOME_ETCD.as_bytes());
    let query_ca = write("query-ca.pem", process.query_tls.0.as_bytes());
    let query_cert = write("query.pem", process.query_tls.1.as_bytes());
    let query_key = write("query.key", process.query_tls.2.as_bytes());
    let query_token = write("query.token", OUTCOME.as_bytes());
    let signer = write("outcome.key", STANDARD.encode([14; 32]).as_bytes());
    let cfg = json!({"family":{"registration":r.r,"child_id":"child-1"},"reservation":r.r.child("child-1").unwrap().reservation,
      "etcd_endpoint":source._relay.url,"etcd_prefix":r.r.namespace,"etcd_ca":ca,"etcd_certificate":cert,"etcd_private_key":key,"etcd_token_file":native_token,
      "gateway_audience":r.physical.registration.scope.audience,"grant_keys":public(5),"query_url":format!("{}/query",process.endpoint),"query_ca":query_ca,
      "query_certificate":query_cert,"query_private_key":query_key,"query_token_file":query_token,"receipt_key_id":"key-14","receipt_signing_key_file":signer,
      "source_id":"spiffe://test/outcome","page_size":8,"poll_interval_ms":100});
    let file = write("recovery.json", &canonical(&cfg).unwrap());
    let deadline = tokio::time::Instant::now() + Duration::from_secs(15);
    let mut attempts = Vec::new();
    loop {
        let out = tokio::time::timeout_at(
            deadline,
            tokio::process::Command::new(env!("CARGO_BIN_EXE_kf-recover"))
                .arg("--config")
                .arg(&file)
                .arg("--once")
                .kill_on_drop(true)
                .output(),
        )
        .await
        .unwrap()
        .unwrap();
        let diagnostic = String::from_utf8_lossy(&out.stderr);
        let mut sweep: Value = serde_json::from_slice(&out.stdout).unwrap();
        attempts
            .push(json!({"success":out.status.success(),"sweep":sweep,"diagnostic":diagnostic}));
        assert_eq!(sweep["examined"], 1);
        if out.status.success() {
            assert_eq!(sweep["reported"], 1);
            assert_eq!(sweep["unavailable"], 0);
            sweep["attempts"] = json!(attempts);
            return sweep;
        }
        // A normal recovery service polls again after a guarded read loses its
        // epoch. Exercise that query-only behavior under one original bound;
        // retain every failed sweep and refuse all other failures. This never
        // changes a grant, exchanges credentials or repeats physical dispatch.
        assert_eq!(sweep["reported"], 0);
        assert_eq!(sweep["deferred"], 0);
        assert_eq!(sweep["unavailable"], 1);
        assert!(
            diagnostic.contains("reservation read epoch raced")
                || diagnostic.contains("invalid guarded proof read"),
            "shipping managed recovery refused: {diagnostic}; sweep={sweep}"
        );
        assert!(
            attempts.len() < 3,
            "bounded recovery read races: {attempts:?}"
        );
        tokio::time::sleep_until(
            deadline.min(tokio::time::Instant::now() + Duration::from_millis(100)),
        )
        .await;
    }
}
async fn run(discard_reply: bool, shipping_gateway: bool) {
    let links = common::Links::new().await;
    let gateway = links.gateway();
    let broker = links.broker();
    let sink = SinkServer::new(false).await;
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let listen = listener.local_addr().unwrap();
    let (r, identity, source, mut source_child) = Box::pin(setup_source_gateway(
        Some(sink.policy(30000, 16)),
        format!("https://{listen}/accept"),
        Some(&gateway),
    ))
    .await;
    let process = Process::with_broker(&r, &source, &identity, listen, &broker);
    let supervisor = SupervisorProcess::new(&r, &source, &identity, &sink);
    process.json("check").await;
    let tls = kedgeflow::tls::server_config_pem(
        &std::fs::read(process.directory.path().join("server.pem")).unwrap(),
        &std::fs::read(process.directory.path().join("server.key")).unwrap(),
        &std::fs::read(process.directory.path().join("workload-ca.pem")).unwrap(),
    )
    .unwrap();
    let context = Store::new(r.physical.ledger.clone()).unwrap().context;
    let managed = common::ManagedServing {
        ledger: native_ledger(&r, &source, &identity[6], GATEWAY_ETCD),
        evidence: common::ManagedEvidence {
            client: source.assembler.clone(),
            endpoint: context.enrollment.current_sql.evidence_endpoint.clone(),
            token: EVIDENCE.into(),
            enrollment_digest: context.enrollment.digest().unwrap(),
        },
    };
    let mut serving = Box::pin(common::serve_inner(
        &r,
        links,
        &process.endpoint,
        process.gateway_transport.clone(),
        tls,
        Some(managed),
        discard_reply,
        shipping_gateway.then(|| common::ShippingGateway {
            native_endpoint: source._relay.url.clone(),
            credential: GATEWAY_ETCD.into(),
            identity: identity[6].clone(),
        }),
    ))
    .await;
    serving.config["state"] = json!(r.saga.status().await.unwrap());
    let file = serving.directory.path().join("agent.json");
    std::fs::write(&file, canonical(&serving.config).unwrap()).unwrap();
    let before = sql_rows(&r).await;
    source.pending_pause.armed.store(true, Ordering::SeqCst);
    drop(listener);
    let mut child = process.start().await;
    // Preparation may outlast the ordinary installation ACK. Refresh it before
    // SDK admission; the grant/source/dispatch validity bounds remain unchanged.
    Box::pin(refresh(&r.physical)).await;
    let first = common::run_node_with_log(
        file.clone(),
        if shipping_gateway {
            vec![
                serving.directory.path().join("gateway/gateway.log"),
                process.directory.path().join("controller.log"),
            ]
        } else {
            vec![]
        },
    )
    .await;
    assert_eq!(
        serving.dispatch.discarded.load(Ordering::SeqCst),
        usize::from(discard_reply),
        "the loss case must discard an actual fully verified original adapter reply"
    );
    let raw_acceptance = if shipping_gateway {
        // This is the full first reply parsed by the actual official SDK from
        // the separate shipping process, not an in-process adapter inspection.
        assert!(serving.dispatch.reply.lock().unwrap().is_none());
        first["managed_acceptance"].clone()
    } else {
        serving.dispatch.reply.lock().unwrap().clone().expect("original verified adapter reply")
            ["structuredContent"]["kedgeflow_managed_drain_acceptance"].clone()
    };
    let acceptance: kedgeflow::managed_drain_acceptance::Proof =
        serde_json::from_value(raw_acceptance).unwrap();
    acceptance.verify(&context).unwrap();
    eprintln!(
        "managed SDK: original {} attempt={}",
        first["state"], first["attempt_id"]
    );
    assert_eq!(serving.minter.1.load(Ordering::SeqCst), 1);
    assert_eq!(
        serving.dispatch.calls.load(Ordering::SeqCst),
        usize::from(!shipping_gateway)
    );
    let until = std::time::Instant::now() + Duration::from_secs(5);
    while source.pending_pause.intercepted.load(Ordering::SeqCst) == 0 {
        assert!(child.try_wait().unwrap().is_none(), "{}", process.log());
        assert!(
            std::time::Instant::now() < until,
            "first actual Pending CAS not reached: {}",
            process.log()
        );
        tokio::time::sleep(Duration::from_millis(20)).await;
    }
    child.kill().await.unwrap();
    child.wait().await.unwrap();
    source.pending_pause.release.notify_one();
    let accepted = r.controller.state().await.unwrap().unwrap();
    assert!(accepted.body.steps.is_empty());
    let attempt = first["attempt_id"].as_str().unwrap();
    assert_eq!(accepted.body.accepted.attempt_id, attempt);
    let mut traces = vec![first.clone()];
    if discard_reply {
        // Stop the original root before any Pending/send; status recovery cannot
        // authorize the stopped work or replace its original grant/attempt.
        Box::pin(common::stop_root(&r, 601)).await;
    } else {
        let proof: kedgeflow::managed_drain_acceptance::Proof =
            serde_json::from_value(first["managed_acceptance"].clone())
                .expect("SDK must retain actual complete gateway acceptance proof");
        let report = proof.verify(&context).unwrap();
        assert_eq!(report["complete_acceptance_sources"], true);
        assert_eq!(report["physical_status"], "unresolved");
        assert_eq!(proof.sources.claims.len(), 1);
    }
    Box::pin(refresh(&r.physical)).await;
    child = process.start().await;
    if !discard_reply {
        let until = std::time::Instant::now() + Duration::from_secs(28);
        loop {
            assert!(child.try_wait().unwrap().is_none(), "{}", process.log());
            let state = match r.controller.state().await {
                Ok(s) => s,
                Err(kedgeflow::error::Error::Unavailable(message))
                    if message == "invalid guarded proof read" =>
                {
                    None
                }
                other => panic!("original controller query: {other:?}"),
            };
            if state.as_ref().is_some_and(|s| {
                s.body.steps.len() == 2
                    && s.body.steps.iter().all(|step| {
                        step.response
                            .as_ref()
                            .is_some_and(|p| (200..300).contains(&p.http_status))
                    })
            }) {
                break;
            }
            assert!(
                std::time::Instant::now() < until,
                "original managed physical work did not complete: {}; {}",
                process.log(),
                json!(state)
            );
            tokio::time::sleep(Duration::from_millis(150)).await;
        }
    }
    let sweep = recover(&r, &source, &process, &identity).await;
    serving.config["mode"] = json!("resume");
    serving.config["expectedState"] = json!("accepted");
    serving.config["physical"]["token"] = json!(common::token(&r.physical));
    std::fs::write(&file, canonical(&serving.config).unwrap()).unwrap();
    let resumed = common::run_node(file).await;
    assert_eq!(resumed["attempt_id"], attempt);
    assert_eq!(resumed["grant_digest"], first["grant_digest"]);
    traces.push(resumed);
    let state = r.controller.state().await.unwrap().unwrap();
    if discard_reply {
        assert!(state.body.steps.is_empty());
        assert!(
            !r.api
                .inventory(&r.contract)
                .await
                .unwrap()
                .target(&r.contract)
                .unwrap()
                .unschedulable
        );
    }
    assert_eq!(serving.minter.1.load(Ordering::SeqCst), 1);
    assert_eq!(
        serving.dispatch.calls.load(Ordering::SeqCst),
        usize::from(!shipping_gateway)
    );
    assert_eq!(serving.source.baselines.load(Ordering::SeqCst), 1);
    assert_eq!(serving.source.collections.load(Ordering::SeqCst), 1);
    child.kill().await.unwrap();
    child.wait().await.unwrap();
    if let Some(slot) = Store::new(r.physical.ledger.clone())
        .unwrap()
        .status()
        .await
        .unwrap()
        .unwrap()
        .pending
    {
        // The read-only supervisor cannot steal the original consumed source
        // slot. Wait for that exact recorded expiry; never align or extend a
        // grant/token/deadline, refund a slot, or repeat an execution request.
        let remaining = slot.expires_at.saturating_sub(now());
        if remaining > 0 {
            assert!(remaining <= 5000);
            tokio::time::sleep(Duration::from_millis(remaining as u64 + 1)).await;
        }
    }
    let observation = supervisor.json("observe").await;
    assert_eq!(
        observation["observed"], true,
        "complete audit requires an actual retained observation"
    );
    if !discard_reply {
        assert_eq!(
            observation["operating"]["observation"]["resolution"],
            "observed_completed"
        );
    }
    let (bundle, trust) = supervisor::export(&supervisor, &r).await;
    let report = bundle.verify(&trust).unwrap();
    assert_eq!(before, sql_rows(&r).await);
    assert_eq!(report["held_forward"], 2);
    assert_eq!(report["held_compensation"], 1);
    if !discard_reply {
        assert_eq!(report["physical"]["physical_status"], "observed_completed");
        assert_eq!(report["operating"]["send_checks"], 2);
        assert_eq!(report["source_claims"], 4);
    }
    let name = if shipping_gateway {
        "managed-gateway-shipping"
    } else if discard_reply {
        "managed-gateway-unknown"
    } else {
        "managed-gateway-completed"
    };
    supervisor::save(
        name,
        &bundle,
        &trust,
        json!({"shipping_gateway":shipping_gateway,"shipping_controller":true,"shipping_source":true,"shipping_supervisor":true,"official_mcp_sdk":true,"native_admission_issuer_broker_gateway":true,
      "native_broker_mints":1,"in_process_adapter_dispatches":serving.dispatch.calls.load(Ordering::SeqCst),"provider_baselines":1,"provider_collections":1,"actual_preflight_witnesses":1,"restart_same_original":true,
      "lost_original_acceptance_reply":discard_reply,"discarded_verified_replies":serving.dispatch.discarded.load(Ordering::SeqCst),"native_committed_is_acceptance":true,"interrupted_query_claim_remains_consumed":true,"sql_rows_unchanged":true,"shipping_recovery":sweep,"traces":traces,
      "controller_diagnostics":process.log(),"gateway_diagnostics":if shipping_gateway {std::fs::read_to_string(serving.directory.path().join("gateway/gateway.log")).unwrap()} else {String::new()},
      "scope":"generated co-located fixture identities; actual SQL/native/Kubernetes and shipping managed source/controller/supervisor/recovery with official SDK/native services; optional shipping gateway; admission/issuer/broker hosted as typed services; no independent deployment/custody claim"}),
    );
    if let Some(output) = std::env::var_os("KF_CONFORMANCE_ARTIFACTS") {
        let folder = PathBuf::from(output).join(name);
        std::fs::write(
            folder.join("acceptance.json"),
            canonical(&json!(acceptance)).unwrap(),
        )
        .unwrap();
        std::fs::write(
            folder.join("acceptance-verification.json"),
            canonical(&acceptance.verify(&context).unwrap()).unwrap(),
        )
        .unwrap();
    }
    source_child.kill().await.unwrap();
    source_child.wait().await.unwrap();
}
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn kube_drain_real_managed_official_sdk_native_gateway_complete_sources_and_physical_audit() {
    Box::pin(run(false, false)).await;
}
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn kube_drain_real_managed_official_sdk_lost_reply_query_only_recovery_after_root_stop() {
    Box::pin(run(true, false)).await;
}
#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn kube_drain_real_managed_official_sdk_shipping_gateway_protected_runtime_and_complete_audit()
 {
    Box::pin(run(false, true)).await;
}
