# KedgeFlow code and protocol implementation milestones

Planning baseline: **10 October 2026**, runtime `769c0a8`, proposed white paper v0.9. This plan follows the [implementation review](IMPLEMENTATION_REVIEW_2026_10_10.md). M1 now has [fifty-four RFC drafts](rfcs/README.md), a template, profile index and separate draft schemas. M2 has verified admission/issuance plus a bounded signed administrative control lifecycle, gateway acknowledgements and revocation comparisons. The software slice is delivered; owner acceptance and deployment qualification remain open. M3a now supplies a live official-client adapter and durable grant/attempt status; M3b adds signed-proposal operation lookup and bounded client fault qualification; M4a now adds retained journal, query-only recovery, signed receipts and an offline receipt-chain verifier; M4b1 supplies authenticated retained delivery and signed acknowledgements; M4b2 adds signed admission-lineage export and offline verification; M4b3 now retains and authenticates governance history and approved key membership; M4b4 now retains and verifies observer-attested per-transition control comparisons; M4c1 now qualifies nine shipping-binary process termination/restart boundaries; M4c2 now supplies a bounded independent write-ahead restore gate; M4c3 now supplies bounded owned incidents and automatic ordered delivery; M5a now supplies optional shared DPoP consumption and subject/workload/scope registration; M5b now supplies independent grant/original-claim/target authorization before a one-shot credential mint; M5c1 now verifies actual subject/actor signatures with bounded atomic trust refresh; approved identity lifecycle precedes enterprise acceptance.

## Execution status — 22 October 2026

[RFCs 0029–0033 and the new prerequisites](MILESTONE_PREREQUISITES.md) add
M6d2b pinned SQL kernel peer transport and a separate-account Linux CI harness,
M6d3a fenced stale logical SQL restore/storage budgets, M7a canonical assertion and
durable review consumption, M8a hierarchical capacity conservation, and M9a a
required source-pinned software conformance runner. These are software
prerequisites. The Linux account fixture is unobserved locally; M7 native
frozen HITL and M8 independent coordination/whole-saga acceptance and drain remain unfinished.
M7b now adds [native reviewed evidence](NATIVE_REVIEW.md), protected provider files,
exact consumed-challenge/enrollment comparisons in admission/issuance and shipping
crash recovery. M7c now adds [exact-proposal static leases](STATIC_ADMISSION_LEASES.md),
fresh JIT evidence and durable membership generations through native admission /
issuance. M8b1 now adds [native fixed-cost leaf reservations](NATIVE_RESERVED_LEAF.md):
fenced allocation, signed immutable bindings, original-attempt claim consumption
and stopped-root dispatch refusal. M8b2 adds [opt-in budget history and signed
outcome refinement](RESERVED_HISTORY.md), retaining both allowances. Original
enterprise/hardware/independent release exit gates remain open.
M8c1 adds [authenticated A2A root-reference views](A2A_ROOT_RESOLUTION.md),
without granting execution or writing capacity.
M8c2 adds [static hierarchical leaf authority](HIERARCHICAL_LEAF_AUTHORITY.md):
signed nonexecutable composites and atomic fresh leaf-cost/issuance. M8c3 adds
[complete audited static hierarchy](HIERARCHICAL_HISTORY.md), signed outcomes
and all-leaf admission replay without refunds. M8d1 adds [durable query-only saga
observation](SAGA_OBSERVATION.md) with blocked inverse intent and original native
proofs. M8d2a adds [native preallocated forward-DAG authority](SAGA_FORWARD_AUTHORITY.md);
M8d2b1 adds [protected inverse contracts and signed proof qualification](INVERSE_QUALIFICATION.md);
M8d2b2a adds [explicit paired controls](PAIRED_ACTION_DOMAINS.md);
M8d2b2 adds [fresh inverse authority and held spending](NATIVE_COMPENSATION_AUTHORITY.md);
M8c4 adds [shared family capacity and live narrowed delegation](FAMILY_AUTHORITY.md).
M8c5 adds [core A2A v1 family tasks](A2A_FAMILY_TASKS.md), actual official SDK
exchange and query-only task recovery across a shipping peer restart. The
bounded multi-contract inverse runner is added by M8d3f below; M8e1 adds bounded
real governed drain. Wider physical qualification and external acceptance remain
open. The earlier required results and source pins are in the
[family verification bundle](../results/verification/rfc-m8-family-authority-2026-10-16/README.md).

[M8d3f / RFC 0054](FAMILY_SAGA_RUNTIME.md) adds native global phase/epoch
enforcement, consistent capture, original inverse ordering, protected local
CLI/Node orchestration and signed aggregate replay. The
[required qualification](../results/verification/rfc-m8-family-saga-native-2026-10-22/README.md) covers two real SQL contracts,
official SDK inverse execution and original-attempt recovery/restart after root
stop, final CAS races and retained SQL guard failure. Host code performs forwards
and owner transitions. Wider crash qualification, shipping owner-command deployment,
independent whole-saga acceptance and drain remain open; M8 is incomplete.

| Increment | Delivered | Remaining gate |
| --- | --- | --- |
| M0 profile clarity | Active profile index; legacy v0.1 guide labelled; required etcd/SDK runtime rerun | Minimum Rust version and separate paper reproduction qualification |
| M8e1 governed drain | Explicit Level C controller/observer and complete native physical aggregate; real SQL predecessor, cordon/eviction, PDB refusal, positive unstarted closure and fresh original SQL restore | Same-host fixture; M8e2 shipping process/SDK, actual reply loss/SIGKILL/stop/UID/late-acceptance; M8e3 physical/writer/SLO and independent acceptance remain open |
| M8d3f native family saga | Global phase/epoch, complete signed capture, reverse original inverse ordering, two real SQL contracts, official SDK inverses with lost commit reply and query-only restart, serialized completed/unknown/failed aggregate CLI replay | One fresh namespace/fixed catalog; SDK forwards, shipping owner CLI deployment, wider crash matrix, drain, independent whole-saga and enterprise acceptance remain open |
| M8c5 core A2A tasks | Shipping v1 JSON-RPC peer, official SDK card/task exchange, stable signed operation replay and process restart, owner/delegate ACL and separate native child authority | Completed coordination only; independent authority implementation, multi-contract saga/drain and deployment acceptance remain open |
| M8c4 family authority | Shared preallocation across cataloged contracts, signed runtime narrowed branches, one-time attachments, native ancestor CAS and bounded family replay/CLI | One namespace; aggregate execution evidence, independent peers, multi-contract SQL runner, drain and deployment acceptance remain open |
| M8d3e inverse SQL restore | Real stale dump/restore copy, five-role connection fence, query-only reopening, same consumed native authority/spend and original unknown/committed receipts | Stopped local logical copy; physical backup/cutover/custody, accepted external history and fresh deployed enrollment remain open |
| M8d3d inverse failure recovery | Shipping target SIGKILL at actual SQL row lock and after COMMIT, separate-witness stale authority quarantine, original query-only receipt and held spend | Local stopped authority rollback; inverse SQL storage restore, wider process/partial-failure matrix, independent and deployed acceptance remain open |
| M8d3c compound evidence | Complete all-claimed-forward and qualification chains, independently replayed original inverse authority/outcomes, bounded native proof CAS and offline CLI; explicit partial/unresolved classification | One selected inverse contract; independent peer, multi-contract execution and inverse restore/crash/deployment acceptance remain open |
| M8d3b inverse SDK workflow | Official client, fresh inverse evidence/admission/issuance, native broker and actual SQL restore; lost target reply and query-only Node-process restart after stop/expiry | Bounded one-contract workflow; multi-contract families, independent whole-saga, inverse restore/crash and deployed acceptance remain open |
| M8d3a conditional SQL inverse | Immutable protected snapshot, actual original-result barrier, separate applicability evaluator, compound target and native adapter/query | M8d3b supplies the bounded SDK and M8d3c bounded compound evidence; multi-contract families, inverse crash/restore and independent/deployed acceptance remain open |
| M8d2b2 fresh inverse authority | Fresh verified inverse inputs/Cedar admission, mandatory signed binding, atomic original held spend and claim/dispatch/recovery; permanent compensation mode | One exact contract per paired service; actual target/barrier, complete multi-node saga evidence and M8d3/M8e acceptance remain open |
| M8d2b2a paired controls | Explicit immutable fresh-domain topology, exact per-action installation, shared resource fences, legacy refusal and permanent physical-domain stop | RFC 0047 adds a separate fresh inverse authority opt-in; target qualification remains open |
| M8d2b1 inverse prerequisites | Protected signed inverse CTD/contract, original committed forward history, independent target barrier and applicability, bounded native CAS journal and shipping CLI | Evidence only. M8d2b2 fresh inverse control/admission/issuance/spend/claim/dispatch; M8d3 actual target/barrier and complete independent saga acceptance |
| M8d2a native forward DAG | Explicit fresh-root profile, all planned leaf costs held before admission, signed committed predecessor gates in native authority CAS, complete issued-leaf replay and native CLI/SDK qualification | M8d2b inverse-specific contract, fresh compensation authority/deadlines/barrier; M8d3 actual inverse/late-effects/failures/independent saga evidence |
| M8d1 durable saga observations | Protected DAG, permanent saga/root/operation identities, query-only original authorization/attempt/outcome reconciliation, blocked inverse intent and bounded journal; native concurrency/fault/CLI checks | M8d2 native dependency/fresh compensation authority; M8d3 actual inverse target, late effects/partial failure and independent saga evidence; no complete saga runner claim |
| M8c3 static hierarchy history | Audited fresh-root profile, atomic child-cost/issuance history, native signed refinement without refunds, complete independently pinned all-leaf admission and budget replay, native fault/CLI/SDK qualification | Bounded static graph/history; dynamic delegation, saga/drain, independent peers and deployment acceptance remain open |
| M8c2 static hierarchy | Signed nonexecutable composite skeleton, protected parent assignments, independently admitted leaf bindings, atomic child-cost/issuance and lineage checks at claim/dispatch; native SDK and operator checks | One fixed leaf contract; audited history/refinement requires M8c3; dynamic delegation and accepted deployment remain open |
| M8c1 A2A root views | Explicit extension activation, immutable reader ACL and atomic scoped root/parent views; pinned native client and shipping control enrollment/withdrawal/restart | M8c2/M8c3 supply static hierarchical execution/history; full A2A peers, independent interoperability and enterprise acceptance remain open |
| M8b2 budget history and refinement | v0.2 hash-linked allocation/fence/issuance/claim/dispatch/stop history, original-attempt native receipt refinement and independently pinned reserved-lineage replay; shipping recovery/audit CLIs and SDK workflow | Bounded history/observer/custody limits; dynamic delegation/full A2A peers/saga/compensation/drain and enterprise acceptance |
| M8b1 native reserved leaf | Fixed-cost fenced allocation, signed binding/seal, original-attempt claim and active-root dispatch comparisons; shipping CLIs and native SDK reply-loss/restart qualification | M8b2 adds versioned history/refinement; dynamic delegation/full A2A peers/saga/compensation/drain and accepted writer/physical deployment remain open |
| M1 RFC structure | RFCs 0001–0045; separate admission/issuance, administration and retained-status carriage | Owners, review decisions, operation lookup/outcome schemas and acceptance |
| M2a library prerequisite | Typed certificate constraints; pinned local schemas; role/tenant checks; atomic operation-wide issuance; real-etcd concurrency, rebinding, consumption and stale-policy tests | Library verification complete; service permissions still require M2b/M2c |
| M2b input verification, policy and services | Signed input chain; pinned Cedar/rules; durable certificate/chain retention; authenticated native admission/issuance; issuer-owned IDs/nonces and resource fences | Operator-approved policy/provider pins; production trust lifecycle and target qualification remain open |
| M2c control implementation | Separate authenticated signed policy/registry/install/revoke/query service; expected revisions; native gateway acknowledgement/renewal; installed scope/trust/freshness and revocation CAS in admission, allocation, issuance, claim and dispatch; native combined-path/race tests | Draft owner acceptance; multi-component coverage, production enrollment/RBAC, legacy migration, counter bootstrap and restore qualification |
| M6b2 fresh SQL leaf path | RFC 0025 named CTD/schema binding, explicit gateway adapter, official SDK fresh admission/issuance, native one-shot broker and real SQL commit; discarded target reply resolves through M4 query and Node restart preserves attempt | M6c combined SQL crash/restore/incident qualification; production provisioning, writer/bypass and owner acceptance remain open |
| M6b1 native PostgreSQL target | RFC 0024 authenticated target/query, fixed local SQL driver with COMMIT acknowledgement, independent grant/token checks and adapter client; actual SQL/mTLS and shipping restart | RFC 0025 supplies the fresh SQL leaf path; enterprise target/provider/restore/owner acceptance remains open |
| M6a PostgreSQL storage prerequisite | RFC 0023 closed reservation records; actual SQL conditional effect and retained outcome; row-version/fence/incarnation guards, root/attempt/grant deduplication and read-only lookup | M6b1 supplies target/query; RFC 0025 connects runtime/agent integration; approved target/identity contracts and full M6 pilot acceptance remain open |
| M5c3 signed identity refresh | Signed snapshots and protected exact head checked each exchange; remembered epoch/digest; closed role/realm/source checks; shipping live actor rotation without restart | Approved publisher, independent durable head/floor custody, replica delivery/clock/atomic storage guarantees and enterprise provisioning/target acceptance |
| M5c2 native broker/reference token | Closed native mTLS RFC 8693 form; exact gateway; original permit before one mint; independently verified reference target token; client/disconnect/fault and shipping restart checks | Actual approved provider refresh/custody and target enforcement; production managed/witness/RBAC/bypass acceptance |
| M5c1 pinned provider verification | Shared admission delegation; Ed25519 subject/ES256 JWT-SVID actor signatures; exact role/domain keys and registration; bounded atomic monotone trust refresh; key retirement/token/workload withdrawal; real-etcd broker composition | Actual approved providers/provisioning, protected refresh and independent epoch custody, cross-replica revocation delivery, native mint and actual target credential enforcement |
| M5b broker authorization | Existing one-resource leaf; independent signed grant and provider identity binding; original undispatched claim; current control/revocation CAS; immutable one-shot permit; native etcd faults | Approved provider verification/mint integration, actual target token scope, custody and production RBAC |
| M5a identity/replay | Shared atomic bounded DPoP consumption; exact subject/workload/scope registration; shipping service bindings and native restart/fault cases | Registration migration, real AS/SVID rotation, approved broker integration, production RBAC/custody and deployed bypass tests |
| M4c3 owned incidents and delivery | Retained owner/deadline and incident events; ordered verified acceptance progress; collector/process faults; shipping continuous polling | Production routing/handoff, token/identity rotation, combined managed/witness deployment, receipt pagination and latency/scale |
| M4c2 restore quarantine | Independent write-ahead reservation, local atomic head, empty operator enrollment, stale/pending refusal and separate native witness tests | Pending repair, existing-state migration, combined managed crash coverage, production RBAC/custody and independent physical failure domains |
| M4c1 process termination | Nine actual gateway/worker SIGKILL/restart cases; test-owned mTLS transaction barriers; atomic fenced software target; original attempt and receipt reuse, zero extra claims/exchanges/dispatches | M4c2 supplies bounded quarantine; managed crash/renewal coverage, full admission lineage through kills, real target durability, host/power failure, production identity/custody and independent peers |
| M4b4 operation control bindings | Atomic admission/issuance/claim/dispatch snapshot retention; governance head CAS; separate observer assertion and offline phase replay; renewal/same-clock revocation/negative carriage tests | M4c1 supplies bounded process-kill qualification; stale-backup restore fencing and observer deployment/RBAC/custody and clock trust, pagination, incidents and independent-peer acceptance |
| M4b3 governance and key history | Atomic immutable governance events; separate observer checkpoint bound to lineage; closed public historical approvals; native acknowledgement renewal/recreated service and approved issuer change; separate offline verifier | M4b4 supplies observer-attested per-transition comparisons; trusted observer deployment/clock/custody, pagination, hard-crash/restore/incident qualification |
| M4b2 signed admission lineage | Closed retained proposal/CTD/manifest/witness/certificate/grant/outcome export; public historical trust; signed-time freshness, Cedar and issuer checks; separate offline CLI; signed tenancy and explicit missing links | M4b3 supplies observer-attested governance history; M4b4 supplies observed control CAS bindings; authenticated journal/fences, original runtime authentication, target proof, wider crash/restore/incident qualification |
| M4b1 retained delivery and acknowledgement | Separate native authenticated collector; retained receipt/evidence checks; ordered immutable signed acknowledgements; bounded delivery/lookup client; duplicate/lost-reply/recreated collector cases | M4b2 supplies signed admission lineage; M4b3 supplies observed governance/key history; M4b4 supplies observed control CAS bindings; automatic delivery/incident handling, gateway/target kill matrix and restore fencing |
| M4a retained journal and outcomes | Atomic recorded execution context and claim/dispatch/terminal history; query-only indexed worker; pre-dispatch CAS seal; signed OutcomeService receipts; independent grant/receipt-chain verifier | M4b1 supplies bounded retained report/ack; M4b2 supplies signed admission lineage; M4b3 supplies observed governance/key history; M4b4 supplies observed control CAS bindings; gateway/target kill matrix, incident deadlines and restore fencing |
| M3b operation lookup and client faults | Authenticated signed-proposal historical lookup; lost issuer/provider replies; failed grant persistence; query-only restart after expiry/revocation | Full M3: real providers, power loss, crash-owner locks, retained identity/key history and restored-authority qualification |
| M3a live client and replay/status | Node Agent Adapter with real official MCP client; shared delegation audience; fresh native admission/issuance; retained grant/attempt status; original ID resolution; lost-reply and expired/revoked status after client restart | Real providers and broader persistence/deployment qualification |

The trusted legacy issuance API remains available for the existing fixture path.
M2a does not turn it into a certificate-gated service. See
[the control lifecycle verification record](../results/verification/rfc-m2-control-2026-10-11/README.md)
for fresh results. The earlier disk block is resolved. The input-chain/RFC
checkpoint is `733febf`; the Cedar/certificate checkpoint is `3a90308`.
`kf-control` produces live certificates/grants under the bounded
[HTTP draft](rfcs/0006-leaf-control-http.md). `kf-governance` now supplies the
[M2c lifecycle](rfcs/0007-enforcement-control-http.md), with native gateway
acknowledgements and serialization against issuance/claim/dispatch.
The bounded [M3a client/status increment](rfcs/0008-agent-replay-and-status.md) now
connects an actual client, aligns delegation and resolves original attempts.
The bounded [M3b operation-status increment](rfcs/0009-operation-status.md) now
resolves missing local grants and ambiguous issuer/provider replies. [M4a](rfcs/0010-outcome-recovery.md) now delivers bounded signed outcomes and
query-only recovery. [M4b1](rfcs/0011-outcome-report-http.md) adds authenticated retained
receipt delivery and signed acknowledgement/lookup. [M4b2](rfcs/0012-admission-lineage.md)
adds signed admission lineage and historical offline verification. [M4b3](rfcs/0013-control-history.md)
adds immutable governance events and observer-attested historical membership. [M4b4](rfcs/0014-operation-control-bindings.md) adds atomic operation-bound snapshots
and observer-attested control comparisons. [M4c1](rfcs/0015-process-crash-qualification.md) adds bounded process termination
and conserved query-only restart. [M4c2](RESTORE_QUARANTINE.md) adds a write-ahead
restore witness and stale/pending quarantine. [M4c3](OUTCOME_SUPERVISION.md) adds durable owned deadlines and ordered automatic delivery. [M5a](SHARED_AUTHENTICATION.md) adds shared replay and identity registration. [M5b](BROKER_AUTHORIZATION.md) adds one-shot broker authorization. Next is M5c approved provider/enterprise qualification; wider reporting/scheduling and
crash/restore qualification remain open;
wider provider/persistence gates remain open.
The full M3 release gate remains open; see the
[client verification](../results/verification/rfc-m3-agent-2026-10-11/README.md).

Deliver a complete single-action path, qualify one recoverable enterprise deployment, then demonstrate independently implemented protocol peers and coordinated workflows. Preserve fail-closed authority, consumed unknown attempts and truthful target guarantees throughout.

## Scope and estimates

Use the current one-resource mock profile to prove live admission/issuance. The first real target should be a **PostgreSQL-backed conditional reservation/update**, owned by a protected target service. This aligns with the white paper's reservation step and offers a verifiable transaction and durable operation lookup. Physical Kubernetes drain follows as a separately qualified asynchronous action.

The first SQL action should have a defined single-resource predicate. If policy depends on a shared capacity budget or other writers, M8's reservation and complete-predicate coverage become prerequisites for that deployment. A database alone does not create adapter fencing/outcome semantics.

Co-locate compatible policy/registry/admission/issuance/evidence roles in one control-plane deployment, with a protected gateway/adapter and shared ledger. Preserve distinct administrator, provider, issuer, agent and executor permissions and signing keys. Nine roles need not become nine microservices.

Estimates are **focused engineer-weeks**, including implementation and acceptance evidence. They assume existing identity infrastructure, a target owner, CI and an isolated environment. A plausible team is two Rust/backend engineers, one platform/integration engineer and part-time security/resource/application owners. These are planning ranges, not measured commitments; re-estimate after M0. Enrollment, hardware and procurement can dominate calendar time.

## Milestone overview

| Milestone | Concrete outcome | Dependencies | Effort | Accountable owner |
| --- | --- | --- | --- | --- |
| M0 | Claim inventory, active profile index and reproducible baseline | This review | 1–2 | Technical lead |
| M1 | Versioned service/wire contracts, especially Enforcement Control | M0 | 2–3 | Protocol lead + security |
| M2 | Rust policy/registry/admission and atomic independent issuer | M1 | 5–8 | Control-plane lead |
| M3 | Real Agent Adapter; fresh admission-to-mock execution; stable status/replay | M2 | 3–5 | Application integration lead |
| M4 | Crash recovery, outcome worker, signed receipts and verifiable trace | M1; integrate with M3 | 4–6 | Runtime/SRE lead |
| M5 | Enterprise identity, credential lifecycle and deployment custody | M1; integrate with M3 | 4–6 | Security/platform lead |
| M6 | Real SQL target and accepted enterprise pilot/cutover | M3, M4, M5 | 5–8 | Resource + deployment owners |
| M7 | Policy-required canonical human review and admission leases | M2, M4, M5 | 3–5 | Evidence/security lead |
| M8 | Shared reservations, delegation, saga recovery and governed drain | M6; M7 when review required | 7–12 | Authority/workflow lead |
| M9 | Independent exchange, second runtime/target and release conformance | M6 leaf profile; M8 coordination profile | 4–7 | Protocol/release lead |

M0–M6 total **24–38 engineer-weeks**; all milestones total **38–62 engineer-weeks**. M4/M5 can proceed alongside M2/M3 after contract agreement. Extra staffing does not divide the critical path linearly.

```mermaid
flowchart LR
  M0[M0 Baseline] --> M1[M1 Protocol contracts]
  M1 --> M2[M2 Admission and issuer]
  M2 --> M3[M3 Live agent path]
  M1 --> M4[M4 Recovery and receipts]
  M1 --> M5[M5 Enterprise trust]
  M3 --> M6[M6 Real-target pilot]
  M4 --> M6
  M5 --> M6
  M2 --> M7[M7 Review and leases]
  M4 --> M7
  M5 --> M7
  M6 --> M8[M8 Coordination and drain]
  M7 -. when required .-> M8
  M6 --> M9[M9 Independent conformance]
  M8 -. coordination profile .-> M9
```

## M0 — Reproducible baseline and claim inventory

**Code/evidence:** provision a pinned Rust toolchain and run the active workspace with real three-member etcd and required official MCP SDK. Reproduce paper tests separately without overwriting published results. Add supported toolchain/OS checks, including the declared Rust minimum or revise it with evidence. Record source/tool versions, dependency hashes, commands, skips and raw logs.

**Protocol/documentation:** label `docs/protocol.md` as the legacy Python v0.1 guide. Publish an active profile index with accepted record, transport, guard and completion variants. Map every manuscript capability to an owner, code, acceptance case and milestone; keep frozen/current/historical evidence distinct.

**Exit:** another developer reproduces the declared baseline without accidental optional skips. Every claim has a pinned source and scope. Retained Rust results remain clearly identified as retained.

## M1 — Implementable contracts for all six interfaces

**Code:** introduce typed service requests/responses, validators and role/scoped trust administration. Separate execution, administrative and evidence permissions. Define durable operation/attempt lookup types without exposing issuer/publication methods to agents.

**Protocol:** specify machine-readable HTTP/RPC bindings for Governance, Runtime Admission, Enforcement Control, Evidence, Execution status and Outcome. Fix caller permissions, version negotiation, closed payloads, signing domains, key history, errors, expected versions, idempotency, clock uncertainty, cancellation and unknown states. Specify the custom RFC 8693 grant/digest/attempt fields, server-side claimed-attempt validation and subject/workload downscoping.

Prioritize **Enforcement Control**: authenticated `install`, expected installed version, policy/descriptor/key/grant/revocation scope, acknowledgements of actual installed version/coverage and stale-state refusal. Retain shared authoritative etcd as the first claim/revocation substrate. Installed caches never authorize local redemption when quorum is unavailable; an acknowledgement cannot cancel an already dispatched effect.

Freeze the supported methods, authentication and transport for the pinned MCP revision. Specify status usable after grant expiry under current caller authorization. Define optional reference-store publication/retrieval ACLs and retention.

**Exit:** positive/negative vectors and authorization tests cover every leaf-profile operation; wrong-scope/rollback installs refuse and acknowledgement coverage is truthful. New records or changed signed meanings require a new proposed version/supplement. Preserve frozen v0.9 bytes and do not reuse a schema ID for changed semantics.

## M2 — Rust admission and independent atomic issuance

**Code:** implement Policy Authority/Resource Registry functions for one action, then Admission Controller and Grant Authority services. Co-location is allowed with distinct permissions/keys. Add typed semantic validation for signed proposals, CTDs, manifests, evidence and certificates against pinned local schemas. Verify signer roles, identity/delegation, action/incarnation, descriptor/parameter digests, current policy/ownership and approved constraints.

Use satisfied/violated/unknown obligations. Emit a certificate only when required evidence is satisfied and policy permits. Integrate one engine first, preferably Cedar to reuse paper behavior; use server-constructed verified inputs and deny on diagnostics. Qualify OPA as a later interchangeable implementation.

The issuer verifies the complete proposal/certificate/constraint chain and intersects audience, guard, completion, lifetime and evidence validity. Atomically deduplicate one admitted operation/budget using an independently derived issuance key. Repeated valid requests return the persisted issuance; conflicting bindings refuse. New caller request/root IDs cannot multiply allowance. Retain deduplication through the replay/outcome horizon. Only the authority service chooses/publishes roots, generations, nonces and fences.

**Protocol:** implement authorized publish/register/revoke and install/acknowledgement. Explicit grant/root/scope revocation should not require fabricated grant-shaped policy updates. Define retryable issuance responses without reopening authority.

**Exit:** live services produce schema-valid signed certificates/grants. Missing, expired, unknown or contradictory required evidence cannot admit. Wrong-role signatures, broadened constraints, old descriptors and evaluation diagnostics refuse. Concurrent issuer replicas receiving one admission with different request/root IDs produce one persisted allowance. Revocation races issuance/claim/final dispatch obey the declared serialization contract.

## M3 — Live Agent Adapter and correct replay/status correlation

**Code:** integrate one actual supported harness/client workflow. Authenticate workload/delegated subject; freeze proposals; validate negotiated remediation and trusted admission endpoints; obtain fresh evidence, certificate and grant; retry the unchanged action with fresh DPoP proofs. Preserve stable operation identity and expose denied, missing-evidence, pending and unknown states faithfully.

Correct the `NonceConsumed` path to return or resolve the original persisted attempt. Resolve ambiguous claim replies similarly. Expose scope-authorized query-only status by operation/grant/attempt identity without requiring a still-executable grant. Current authorization controls disclosure; status never dispatches. New RPC IDs do not create authority.

**Protocol:** finalize remediation expiry, changed-action/new-admission behavior, status result/error types, cancellation and safe retry rules under M1's binding.

**Exit — first release gate:** a real client performs discovery → remediation → fresh evidence → admission → issuance → exact call → mock receipt without fixture grants. Identity/parameter changes require new admission. Lost-response retry resolves the original attempt. Repeated status and expired-grant status cause **zero additional claims, credential exchanges or target mutations**. Unsupported clients cannot bypass the pilot target.

## M4 — Crash recovery, signed outcomes and independent reconstruction

**Code:** persist signed authorization links, adapter/version, identity/correlation context, dispatch intent, target operation references and observations. Replace an overwritten status-only outbox with retained transition/report records where required. Add a supervised worker that discovers stranded `claimed` and unknown attempts, with atomic transitions and safe multi-worker ownership.

Distinguish provably undispatched work from possible sends using durable facts and the adapter's contract. Query authoritative status; insufficient evidence remains consumed unknown. Time, cancellation, missing status or process death cannot prove no effect. Do not implicitly redispatch/refund.

Produce signed KF-JSON Receipts; implement idempotent Outcome reporting/acknowledgement, target queriers, contradictory-evidence retention, bounded polling and owned escalation deadlines. Preserve actual target evidence: gateway signatures do not become target-signed commit proof. Add an offline verifier for proposal → evidence → certificate → grant → claim/dispatch → outcome, with missing links explicit.

**Protocol:** specify recovery transitions, report identity/order, terminal/pending/unknown semantics, retention/key history and late-effect/no-effect barriers. Define authority-preserving quiesce/restore. Initially, consumed allowance can remain held indefinitely; safe restoration/compensation needs additional proven contracts.

**Exit:** kill/restart before/after claim, dispatch authorization, target commit and receipt persistence. Duplicate workers/reports do not duplicate effects. Lost commit replies resolve authoritatively or remain consumed unknown with an incident. Stale backups are fenced/quarantined before execution resumes. A separate verifier reconstructs retained lineage.

### M4c crash and restore qualification

1. **M4c1 — Process termination (bounded slice delivered):** controlled child-process barriers before
   and after claim, dispatch authorization, target reply and receipt persistence.
   [Nine shipping-binary tests](PROCESS_CRASH_RECOVERY.md) kill and restart the
   gateway/worker in unmanaged fixture mode. Recover the original attempt with
   zero additional claims, credential exchanges or target dispatches; retain an
   explicit unknown outcome where authoritative query cannot resolve it.
2. **M4c2 — Restore quarantine (bounded slice delivered):** [RFC 0016](rfcs/0016-restore-quarantine.md)
   and the [write-ahead gate](RESTORE_QUARANTINE.md) reserve every mutating transaction
   in an independently retained witness, then stamp local state atomically. Empty
   enrollment and latest-head checks refuse stale backups, pending reservations and
   missing witnesses. Tests preserve consumed roots/fences using separate software
   clusters. Pending repair, live migration and production failure domains remain open.
3. **M4c3 — Owned incidents and delivery (bounded slice delivered):** [RFC 0017](rfcs/0017-outcome-supervision.md)
   and [supervision](OUTCOME_SUPERVISION.md) retain an operator-enrolled owner, first
   unknown deadline and immutable incident events. Ordered delivery verifies signed
   collector acknowledgements and resumes exact progress after faults. Native tests
   include shipping supervisor SIGKILL/restart and continuous polling. External
   routing/handoff, managed witness integration and production guarantees remain open.

## M5 — Enterprise identity, credential lifecycle and custody

**M5a — Identity/replay prerequisites (bounded slice delivered):** [RFC 0018](rfcs/0018-shared-authentication.md)
and [shared authentication](SHARED_AUTHENTICATION.md) implement optional durable
DPoP consumption and exact subject/workload/scope registration with fail-closed
replica, restart and fault comparisons. This is a software prerequisite;
real authorization-server/SVID provisioning, rotation and enterprise deployment
acceptance still require independently approved infrastructure.

**M5b — Broker authorization prerequisite (bounded slice delivered):**
[RFC 0019](rfcs/0019-broker-authorization.md) and the [trusted broker library](BROKER_AUTHORIZATION.md)
independently validate signed grant, verified provider identity, original claimed
attempt and fixed target, with one immutable authorization CAS before minting.

**M5c1 — Pinned verification prerequisite (bounded slice delivered):**
[RFC 0020](rfcs/0020-pinned-exchange-identities.md) and [exchange identities](EXCHANGE_IDENTITIES.md)
verify the existing subject-token signature and ES256 JWT-SVID actor with approved
role/domain keys, shared canonical delegation, atomic monotone trust replacement,
freshness bounds and explicit registration/token withdrawal. Software keys and
a real-etcd original-claim composition qualify the library.

**M5c2 — Native broker/reference credential (bounded slice delivered):**
[RFC 0021](rfcs/0021-broker-token-http.md) and [native broker](BROKER_TOKEN_SERVICE.md)
connect the shipped RFC 8693 client to verified gateway mTLS, the original one-shot
permit and one mint invocation. A separately signed reference target token is
independently checked for actual scope, attempt and expiry before reply. Generated
keys and native unmanaged tests qualify this software path; real target effects
and approved provider deployment remain open.

**M5c3 — Signed identity refresh (bounded slice delivered):**
[RFC 0022](rfcs/0022-identity-refresh.md) and [signed refresh](IDENTITY_REFRESH.md)
reload authenticated snapshots against a protected exact head on every exchange.
Role/realm signatures, remembered epoch/digest and retained startup floor checks
refuse stale/inconsistent sources. The shipping broker rotates actor trust without
restarting. Publisher administration, independent durable custody and real provider
acceptance remain open.

Next is **M5c — Approved providers and enterprise qualification**. Implement the
actual provider verification/mint integration and qualify the approved AS,
SVID and target contracts. [Required inputs and acceptance evidence for M5c–M9](ENTERPRISE_QUALIFICATION.md)
are explicit; fixture-only checks cannot close these gates.

**Code:** integrate one real authorization server with controlled issuer/audience/algorithm policy, key rollover and subject-to-workload authorization. Integrate SPIFFE/SPIRE or equivalent administered SVID provisioning/rotation. Add shared atomic DPoP replay/nonce state with bounded retention and fail-closed outages. Keep process-local replay only for its declared profile.

Implement broker-side grant/attempt validation and one real target credential binding. Verify effective target scope/audience/lifetime through the provider's actual token/introspection contract where applicable, retaining final validity checks. Separate issuer/gateway/recovery identities and least-privilege ledger roles so the gateway cannot self-issue. Support secret/certificate/etcd-token renewal and operational key custody.

If reference carriage is needed, implement authorized immutable publication/retrieval, ACLs, rate/concurrency caps, retention and audit. Otherwise keep it disabled for the pilot.

**Deployment/protocol:** supply a supported isolation package, protected service identity/configuration, fixed egress/target access and native shell/file/socket/SDK bypass tests. Declare separately administered break-glass writers. Document rotation, clock uncertainty, TLS termination and actual intermediary/header budgets.

**Exit:** real identity/broker services work end to end. Rotation, revoked workload, cross-replica/restart proof replay, provider outage, overbroad token and exhausted validity refuse unsafe dispatch. Agents/descendants cannot obtain equivalent target credentials, access privileged sockets, tamper with the gateway or invoke alternate mutation paths. Production etcd TLS/RBAC is tested.

## M6 — Real SQL adapter and accepted enterprise pilot

**Delivered software increments:** M6a atomic SQL storage, M6b1 authenticated
native target/query, M6b2 fresh signed leaf composition and **M6c bounded failure
qualification**. [RFC 0026](rfcs/0026-sql-failure-qualification.md) and the
[qualification guide](SQL_FAILURE_QUALIFICATION.md) compose eleven fresh SQL
cases with shipping gateway/broker/target/recovery/supervisor kills, witnessed
stale/pending refusal, owned incident escalation and retained signed collector
acknowledgements. The required regression passes 260 Rust tests and eleven SQL
storage groups. Original attempts, receipts, nonces and SQL fences survive the
observed failures with no additional mint or mutation. Earlier evidence remains
immutable. Pending-witness repair and physical/stale SQL restore remain open.

**M6d1 — SQL enrollment prerequisite (bounded slice delivered):**
[RFC 0027](rfcs/0027-postgres-enrollment.md) and [the operator guide](POSTGRES_ENROLLMENT.md)
add one shared runtime/catalog preflight for standalone function-only SQL logins.
Column grants and NOINHERIT/SET ROLE bypasses, PUBLIC/delegation rights, database ownership/
CREATE, admin/replication flags and missing/crossed function grants refuse before
resource access. Native `--check-database` checks both roles without a listener or
probe mutation; `--check` remains offline. Required regression: 263 Rust tests and
eleven SQL storage groups. This is catalog observation under trusted administrator
custody, not production authentication/OS isolation or permanent certification.

**M6d2a — SQL file custody and peer fixture (bounded slice delivered):**
[RFC 0028](rfcs/0028-postgres-custody.md) and [the guide](POSTGRES_CUSTODY.md) add
explicit descriptor-relative loading of the target's five local files, UID/mode/
link/path bounds and native `--check-custody`. TLS/service construction consumes
verified bytes; legacy loading remains unqualified. The disposable required SQL
run uses actual peer authentication, private socket mode, exact target maps and
anchored fixture-only enrollment maps with refusal/reload probes. Verification:
269 Rust tests / 40 binaries and fifteen SQL storage/peer groups. This is same-UID
mechanics; no independently administered service account or OS containment proof.

**M6d2b transport prerequisite delivered:** [RFC 0029](rfcs/0029-postgres-peer-transport.md)
pins the connected PostgreSQL server kernel UID before SQL bytes and reuses that
stream, with protected socket path/mode snapshots. Correct/incorrect native pins
are tested. Separate Linux accounts/bypass probes are wired into CI; their actual
execution, all-service material custody/rotation and deployed acceptance remain open.

**M6d3a restore/budget prerequisite delivered:** [RFC 0030](rfcs/0030-postgres-restore-rehearsal.md)
rehearses an actual stale logical SQL dump under an application connection fence,
retains the external original commit as lost/unresolved with zero redispatches,
rotates incarnation and measures sixteen fresh storage operations/queries under
an explicit local p95 budget. No existing service resumes; physical restore,
accepted CTD/control cutover, retention and owner decisions remain open.

**Remaining — M6d2b/M6d3 deployed qualification:** qualify separate OS/service
accounts, protected socket/server identity and exact peer administration, ACL/mount/
namespace policy, remaining service loaders, file/key/token rotation and launcher
integrity. Run actual agent/descendant socket/file/shell/SDK bypass attempts. M6d3
must establish independent retention/restore procedures, budgets and owner acceptance
on an approved isolated target. Track M5c provider acceptance alongside M6 and
preserve software evidence separately.

**Code:** replace mock parameter binding with closed CTD-driven action validation/mapping. Supply adapter `describe`, `dispatch` and authoritative `query`. Use fixed target/query/executable definitions rather than caller-controlled SQL or routing.

Implement a PostgreSQL transaction checking declared incarnation/version/fence, applying the effect and retaining attempt/grant/result correlation atomically. Define fence allocation for the covered writer set. Target-side attempt deduplication/retention are resource guarantees, not consequences of an etcd claim. Qualify the ledger/target transaction boundary with M4.

**Protocol:** freeze action, parameter schema, guard, completion, idempotency and outcome contracts with truthful Level A scope. Apply versioning rules when parameters/contracts change. Define actual writer coverage, revocation behavior and evidence. Report only reservation/update completion until physical drain is implemented.

**Exit — enterprise pilot gate:** validate concurrent writers, state changes, deletion/recreation, lost responses, delayed exchange, partitions, target restart and stale restore on a real isolated target. Independent query confirms actual commit. Deployed bypass tests pass. If shared-budget policy applies, M8 is also required.

Deployment/security/SRE/resource owners accept scope, writer coverage, trust, retention, incident deadlines, on-call and cost records. Set workload budgets before measuring admission/issuance/claim/exchange/target/query latency, human queue time, false refusals, unresolved age and support effort.

Use observe → isolated governed pilot → accepted privilege cutover. Production cutover requires rehearsed abort/upgrade/restore/exit preserving consumed roots and key histories. Observation alone makes no enforcement claim.

## M7 — Policy-required canonical review and non-authorizing leases

**M7a verifier/state prerequisite delivered:** [RFC 0031](rfcs/0031-review-consumption.md)
implements narrow original-byte ES256 verification and atomic real-etcd challenge/
counter consumption. Synthetic signatures qualify replay, counter, revocation and
substitution refusal. Hardware profiles refuse. Browser rendering/ceremony,
enrollment and frozen HITL carriage remain unfinished. RFCs 0034/0035 now add
reviewed evidence and static leases to the native service path.

**M7b native integration delivered:** [RFC 0034](rfcs/0034-native-review-evidence.md)
and [operator guide](NATIVE_REVIEW.md) add a protected native provider, canonical
plain-text rendering, software assertion completion and signed generic Evidence.
Opt-in admission/issuer rules require current active enrollment and the exact
consumed challenge in their authority transactions, including retries and fence
allocation. Native composition, revocation races and shipping SIGKILL/restart are
qualified. Browser display/ceremony, physical enrollment/attestation and hardware-bound
profiles remain open.

**M7c native static leases delivered:** [RFC 0035](rfcs/0035-static-admission-leases.md)
and [operator guide](STATIC_ADMISSION_LEASES.md) add exact-proposal prevalidation,
retained frozen lease/static records, fresh JIT evidence and active membership
generations compared in admission/allocation/issuance. Leases provide no execution
authority. Competing replicas, immutable retries, membership/review withdrawal,
Cedar denial and shipping lost-reply SIGKILL/restart are qualified. Protected
browser/hardware and accepted provider/membership/custody lifecycle remain open.

**M7d1 historical audit integration delivered:** [RFC 0036](rfcs/0036-leased-authorization-lineage.md)
and [operator guide](LEASED_AUTHORIZATION_LINEAGE.md) add closed v0.2 lineage/history /
control-binding carriage. Admission/issuance retain original membership/cache
comparisons atomically. Independent verifiers recompute static input and signer /
generation cache identity and full historical admission/issuance. Export after
withdrawal/replacement, tampering/version refusal and shipping offline CLIs are
qualified. v0.1 schemas and legacy bytes remain unchanged. Observer/ledger/clock
trust and membership/review lifecycle history remain explicit limits.

**M7d2 Node client integration delivered:** [RFC 0037](rfcs/0037-agent-static-lease-workflow.md)
and [operator guide](AGENT_STATIC_LEASES.md) add approved lease/provider stage pins,
static-only preparation, durable original-cache reuse and fresh JIT collection.
Native SDK/mTLS/etcd tests qualify separate Node processes and loss boundaries.
The adapter persists a permanent authority-start marker before admission; later
retries are query-only, including when status says unissued/unclaimed. Existing
non-lease records retain their conservative recovery. Physical store/lock recovery,
leased SQL pilot, hardware and enterprise acceptance remain open.

**M8b1 delivered:** native fixed-cost leaf grants and claims now bind the RFC 0032
reservation state. **M8b2 delivered:** [versioned reserved history and native
original-attempt outcome refinement](RESERVED_HISTORY.md), retaining allowances.
M8c1 now supplies authenticated scoped A2A root views. M8c2 supplies bounded static
hierarchical authority. M8c3 supplies its opt-in complete history/refinement;
M8d durable saga/compensation follows.
Review requirements still depend on the independently approved deployment profile;
M7 physical ceremony and accepted provider/membership/custody remain open.

**Remaining ceremony and deployment work:** provide protected browser rendering, actual ceremony, approved enrollment/attestation and membership/provider lifecycle, hardware policy and deployed custody/revocation delivery. Software fixtures remain test-only. Frozen HitlWitness carriage needs its own qualified integration; generic reviewed evidence does not claim that hardware profile.

**Exit:** physical enrolled-authenticator ceremony works; wrong RP/origin/rendering, substitution, missing UV, replay, expiry, revoked enrollment and unsupported hardware/backup policy refuse. Replicas/restarts permit one challenge consumption. Expired underlying evidence blocks admission despite a present lease.

This milestone is required before any pilot claims hardware-bound review. A no-human-review leaf profile may ship after M6 with that scope explicit.

## M8 — Shared reservations, A2A delegation and saga/drain recovery

**M8a capacity-state prerequisite delivered:** [RFC 0032](rfcs/0032-coordination-reservations.md)
implements atomic operation allocation, narrowed scope, separate forward/compensation
budgets and consumed unknown holding. Composite parents cannot consume; real-etcd
last-slot/nested/replay/stop tests qualify the library. These records create no
execution grant. M8b1 adds the separate native leaf integration below.

**M8b1 native reserved leaf delivered:** [RFC 0038](rfcs/0038-native-reserved-leaf.md)
and the [operator guide](NATIVE_RESERVED_LEAF.md) define create-only approved
fixed-cost scope, allocation in the fence transaction, issuer-signed retained
bindings/seals and unknown consumption in the original claim transaction. Dispatch
compares the active budget root again. Library parent/consume/refinement bypasses
refuse after sealing; missing configuration cannot bypass the required marker.
Real-etcd contention and four stop races, native TLS/DPoP official SDK restart
and shipping operator/offline CLIs qualify this software slice. Frozen execution
grants remain one-resource leaves.

**M8b2 delivered:** [RFC 0039](rfcs/0039-reserved-history-refinement.md) and the
[history guide](RESERVED_HISTORY.md) add explicit reserved leaf v0.2 enrollment,
hash-linked snapshot history in each authority transaction, exact allocated fences
and issuer-grant matching, native signed-receipt refinement and a separately
versioned reserved-lineage wrapper/offline verifier. History replay checks scope,
costs, conservation, original attempts, phase order and stop; observer/ledger and
inner runtime/governance gaps remain explicit. Both allowances stay held after
reported commit or pre-dispatch proven no effect. v0.1 stays unchanged; no upgrade,
refund, replacement or compensation authority is introduced. Complete required
software checks include receipt/dispatch/stop races, missing/corrupt/exhausted
history, shipping recovery/offline CLIs and native SDK composition.

**M8c1 delivered — authenticated root-reference views:** [RFC 0040](rfcs/0040-a2a-root-resolution.md)
adds explicit A2A 1.0 extension activation, a capability fragment for an existing
peer, create-only/permanently withdrawable reader ACLs, atomic scoped root/parent
views and a pinned native HTTPS client. The shipping control service exposes the
opt-in read endpoint and operator lifecycle commands. Twelve required native tests
include hierarchy/unknown/stopped scope checks, changed task IDs without capacity
writes, identity/activation/client negatives, replica replay and process restart.
Native reserved v0.2 history/held costs/original attempts remain unchanged.
[Verification](../results/verification/rfc-m8-a2a-root-2026-10-14/README.md):
343 Rust tests / 46 binaries, 18 SQL groups, 32 Python tests and both Node vectors.
This supplies disclosure only: no child grant, allocation, core A2A task service
or independent interoperability claim.

**M8c2 delivered — bounded static hierarchical authority:** [RFC 0041](rfcs/0041-static-hierarchical-leaf-authority.md)
and the [operator guide](HIERARCHICAL_LEAF_AUTHORITY.md) enroll an immutable signed
nonexecutable composite skeleton. Protected subject/workload assignments select a
narrower parent for each independently admitted leaf. One native transaction
retains child cost, grant/root/issuance and a separately versioned signed parent
binding. An earlier retained resource fence consumes no hierarchical capacity.
Claim/dispatch compare original lineage, active root and the original attempt.
Native stop is permanent; known outcomes leave both budgets held/unknown. The
frozen grant format still refuses parent/saga variants. Fifteen new test groups
and expanded shipping control CLI checks qualify real-etcd managed authority,
parallel parents/last-slot contention, stop races, native recovery, offline CLI and
official SDK normal/lost-reply/restart.
[Verification](../results/verification/rfc-m8-hierarchical-leaf-2026-10-14/README.md):
358 Rust tests / 46 binaries, 18 SQL groups, 32 Python tests and both Node vectors.
This supports one fixed executable contract with at most 16 static composites;
the original 0.1 profile holds unknown without complete history. RFC 0042 below
adds that history for a separate fresh-root audited profile; dynamic delegation
remains open.

**M8c3 delivered — audited static hierarchy:** [RFC 0042](rfcs/0042-hierarchical-history.md)
and the [operator guide](HIERARCHICAL_HISTORY.md) add explicit fresh-root audited
0.2 enrollment and a separate hierarchical-lineage wrapper. Genesis retains the
signed skeleton; child cost, issuance and its original-fence history event share
one transaction. Native signed receipts refine original leaves after dispatch or
an atomic pre-send barrier without refunding either allowance. Complete offline
replay verifies every issued leaf's original admission inputs/certificate/policy /
grant/binding, including unclaimed leaves, under independent hierarchy/role /
observer pins. History exhaustion reserves the final stop slot; missing/corrupt
records fail closed. Fourteen new test groups cover contention, history faults,
semantic substitutions, multiple workloads/reversed fence order, recovery/CLI and
official SDK normal/lost-reply/query-only restart; operator lifecycle tests now
also enroll the audited hierarchy.
[Verification](../results/verification/rfc-m8-hierarchical-history-2026-10-14/README.md):
372 Rust tests / 46 binaries, 18 SQL groups, 32 Python tests and both Node vectors.
The bounded static hierarchy software increment is complete. Dynamic parent
creation, branch lifecycle and wider executable contracts need a later live
delegation profile. Production custody, writer/predicate and independent peer
acceptance remain open.

**M8d1 delivered — durable query-first saga observation:** [RFC 0043](rfcs/0043-durable-saga-observation.md)
and the [operator guide](SAGA_OBSERVATION.md) add a protected bounded DAG,
create-only saga/root/operation identity markers and a durable observation journal.
Native signed authorization/outcome proofs retain original grants and attempts;
partial, unknown and pre-send no-effect classifications conserve held capacity.
Operator compensation requests remain blocked, even after a committed forward
effect, pending fresh inverse admission/applicability and accepted late-effect
barriers. `kf-saga` supplies TLS operator check/enroll/status/reconcile/history /
intent commands. Eleven test groups qualify restart, concurrent observers,
receipt/stop races, original identities, dependency diagnostics, history faults,
full 128-event exhaustion and shipping CLI processes.
[Verification](../results/verification/rfc-m8-saga-observation-2026-10-14/README.md):
383 Rust tests / 47 binaries, 18 SQL groups, 32 Python tests and both Node vectors.
This is a query-only prerequisite. It enforces no native DAG dependency or inverse
execution and reserves no exclusive whole-DAG capacity. Existing frozen grants
continue refusing saga fields.

**M8d2a delivered — native forward-saga authority:** [RFC 0044](rfcs/0044-native-forward-saga.md)
adds a separate fresh-root compound profile. Enrollment holds every planned leaf's
fixed costs; admission, fence/issuance/reuse, claim and dispatch require original
signed committed predecessor outcomes and matching audited state. Every proof read
joins the actual authority CAS. Signed bindings pin the immutable DAG; separate
history replays all issued admissions and predecessor ordering with held unissued
nodes. Native tests include parallel/chain progress, ambiguous/no-effect refusal,
missing-proof and stop races, shipping operator/offline CLIs and official SDK
normal/lost-reply/restart. [Verification](../results/verification/rfc-m8-saga-forward-2026-10-15/README.md)
records 394 Rust tests / 47 binaries, 18 SQL groups, 32 Python tests and both Node
vectors. This bounded software prerequisite has no inverse-capable contract,
autonomous runner or complete independent saga acceptance.

**M8d2b1 delivered — inverse contract and proof qualification:** [RFC 0045](rfcs/0045-inverse-contract-qualification.md)
pins a separately signed inverse CTD, original signed baseline/one-version-step
restore semantics, exact inverse identity/policy, held cost and deadline. Complete
original committed forward history plus separate target-barrier/applicability
signatures qualify only nonauthorizing evidence. Native pre-issuance enrollment,
original proof/history CAS, immutable bounded journal and shipping `kf-compensation`
checks do not allocate, spend, issue or execute compensation.
[Verification](../results/verification/rfc-m8-inverse-qualification-2026-10-15/README.md):
404 Rust tests / 48 binaries, 18 SQL groups, 32 Python tests and both Node vectors.
Synthetic signatures establish no physical barrier or independent deployment.

**M8d2b2a delivered — paired action control prerequisite:** [RFC 0046](rfcs/0046-paired-action-domain.md)
and the [operator guide](PAIRED_ACTION_DOMAINS.md) enroll a fresh immutable physical
resource/domain topology with two separately installed exact action controls. A
legacy sentinel prevents silent adoption. Every selected native transaction
compares the complete topology; authority transitions also compare a permanent
shared stop. Operation and resource-fence indices retain their common namespace.
Original signed forward-saga proofs and query-only recovery continue through the
new layout. The inverse lane alone remains nonexecuting; RFC 0047 separately adds fresh
authority. A second reservation cannot manufacture compensation capacity. [Verification](../results/verification/rfc-m8-paired-control-2026-10-15/README.md)
records 414 Rust tests / 49 binaries, 18 SQL groups, 32 Python tests and both Node
vectors, including ten new native/configuration/CLI/proof test groups.

**M8d2b2 delivered — bounded fresh compensation authority:** [RFC 0047](rfcs/0047-native-compensation-authority.md)
and the [operator guide](NATIVE_COMPENSATION_AUTHORITY.md) connect fresh independently
verified inverse inputs/evidence/Cedar admission to a mandatory issuer-signed
compound binding. Native issuance retains one original held spend atomically;
claim and dispatch revalidate the exact original proof, mode, controls and deadline.
Permanent compensation mode serializes against forward claims and dispatch.
Original signed query-only recovery refines committed/pre-send no-effect while
failed/partial/unknown outcomes stay held. The shared resource fence counter is
preserved; no refund or replacement operation is provided. This bounded profile
selects one exact inverse contract per paired service; multi-contract compensation
families and a complete independently verified multi-node runner remain open.

**M8d3a delivered — conditional SQL target/barrier:** [RFC 0048](rfcs/0048-postgres-compensation-target.md)
and the [operator guide](POSTGRES_COMPENSATION_TARGET.md) add a protected immutable
snapshot, actual one-row restore/version/fence CAS and original SQL outcome query.
The target signs a barrier only for the exact original committed forward effect;
a separate evaluator verifies it before signing applicability. The explicit native
adapter carries original ledger-bound proof and the broker credential. Local
checks include real SQL, native authority/broker, mTLS reply loss/restart, original
recovery after stop and shipping target/evaluator commands. Client vectors add
explicit inverse discovery/schema/contract/parameter refusal. [Verification](../results/verification/rfc-m8-sql-compensation-2026-10-15/README.md)
retains 428 Rust tests / 51 binaries, 26 SQL groups and 32 Python tests. No refund, mutation
retry or overwrite of a newer writer state is provided.

**M8d3b delivered — official SDK inverse composition:** the [workflow guide](COMPENSATION_AGENT_WORKFLOW.md)
qualifies fresh inverse evidence/admission/issuance through the official MCP client,
native broker and actual conditional SQL target. A lost target reply remains
unknown until original query recovery; separate Node processes after stop/expiry
query the same attempt without another mint/send. [Verification](../results/verification/rfc-m8-compensation-agent-2026-10-15/README.md)
retains 430 Rust tests / 51 binaries, 26 SQL groups, 32 Python tests and both Node
suites. Generated capacity labels and same-host signer custody remain fixtures.

**M8d3c delivered — complete bounded compound evidence:** [RFC 0049](rfcs/0049-compensation-lineage.md)
and the [audit guide](COMPENSATION_LINEAGE.md) add independently pinned complete
forward budget/authorization/outcome and inverse qualification/authority/outcome
verification for one selected contract. Protected native export compares all
original proof records in one bounded read CAS; the separate offline CLI rejects
omission, substituted identities, changed roles and histories. Reports preserve
partial/unresolved states. Local real-SQL tests include a two-node no-send outcome,
actual inverse commit, stop/expiry, held costs, re-signed semantic negatives and
receipt deletion racing the final export transaction.
[Verification](../results/verification/rfc-m8-compensation-lineage-2026-10-15/README.md)
retains 436 Rust tests / 52 binaries, 26 SQL groups and 32 Python tests. This is
local verification with independent trust pins, not an independently implemented
peer or deployment acceptance.

**M8d3d delivered — bounded inverse failure recovery:** [RFC 0050](rfcs/0050-inverse-failure-recovery.md)
and the [failure guide](COMPENSATION_FAILURE_RECOVERY.md) compose fresh inverse
native authority/broker with shipping target SIGKILL at a real SQL lock and after
COMMIT. Query-only recovery after actual expiry/shared stop retains the original
unknown or committed attempt, same receipt and held cost. A separate witness
quarantines a stopped authority-prefix rollback; exact latest restoration retains
complete compound evidence. This qualifies logical authority rollback with SQL
and witness intact, not physical inverse SQL restore or production acceptance.
[Verification](../results/verification/rfc-m8-inverse-failure-2026-10-16/README.md)
records the full required corpus and source pins.

**M8d3e delivered — bounded inverse SQL restore:** [RFC 0051](rfcs/0051-inverse-sql-restore.md)
and the [restore guide](COMPENSATION_SQL_RESTORE.md) use real pg_dump/pg_restore
and native consumed authority with the ledger/witness outside a fresh restored
SQL copy. All original application roles are fenced; only inverse query is
reopened after ACL tightening/incarnation rotation. Missing restored lookup
retains either original native uncertainty or the exact prior signed commit,
without refund/remint/resend. Complete historical lineage is distinct from the
restored live row. [Verification](../results/verification/rfc-m8-inverse-sql-restore-2026-10-16/README.md)
records the complete required corpus. Physical backup/cutover, accepted external
history/custody and fresh deployment enrollment remain open.

**M8c4 delivered — shared family authority:** [RFC 0052](rfcs/0052-family-authority.md)
and the [operator guide](FAMILY_AUTHORITY.md) add signed runtime branch delegation,
one shared protected budget across up to eight cataloged native contracts and
one-time whole-child preallocation. Every native authority CAS retains live
ancestor comparisons. Root/branch stop preserves held costs and original queries.
Native tests cover two child contracts, paired inverse recovery, last-slot
contention, four stop races, bounded history/corruption and shipping CLI operations.
Family export replays delegation/allocation history; aggregate execution lineage
and a multi-contract inverse runner remain separate work.

**M8c5 delivered — core A2A family coordination:** [RFC 0053](rfcs/0053-family-coordination-tasks.md)
and the [peer guide](A2A_FAMILY_TASKS.md) add actual v1 JSON-RPC card discovery,
SendMessage/GetTask/ListTasks/CancelTask and official SDK 1.0.1 exchange. Signed
commands retain stable native family operation identity despite changed message
IDs or a lost reply. Reads are scoped; process restart recovers original tasks.
Completed coordination is not a target effect or a child execution grant.
Independent authority implementations and full saga/drain acceptance remain open.

**M8d3f delivered — bounded native multi-contract saga:** [RFC 0054](FAMILY_SAGA_RUNTIME.md)
supplies global authority and complete aggregate evidence with the local qualification
limits stated above.

**Remaining M8d3:** wider multi-contract failure/crash and owner-command deployment
qualification, independent whole-saga acceptance
and physical inverse SQL storage restore/cutover, wider late-effect/process-loss/partial /
failed/unknown composition and deployed writer acceptance. Unknown forward effects cannot trigger an
inverse. M8e then adds separately accepted governed drain with explicit physical
limits. Enterprise/writer/physical and independent peer/release gates remain open.

**Code:** add atomic conflict-domain reservations and admitted-operation/child-allocation deduplication. Conserve free, allocated, consumed, unresolved and compensation allowances under one parent generation. Composite parents cannot execute/spend child allocations; transfer/replacement cannot reopen unresolved authority. Qualify multiple-resource/predicate profiles before accepting them.

M8c1 supplies extension advertisement fragments/activation and authenticated read-only root-reference resolution. M8c5 supplies the bounded core task peer and official client exchange; independent authority-peer acceptance remains open. M8c2 supplies native static compound child issuance. Task IDs/references are correlation, not authority; each child needs a narrower admitted grant. Demonstrate executable scope narrowing and refusal of widening.

Integrate durable orchestration, optionally Temporal, with stable operation identities and query-first recovery. Reserve compensation budget before forward execution. Registered inverses require known outcomes, fresh admission, accepted applicability and late-effect barriers where needed.

**M8e1 delivered — bounded native Level C drain:** [RFC 0055](KUBERNETES_DRAIN.md)
adds the protected controller and independent observer with actual local API/SQL
qualification. Acceptance alone is unresolved; PDB refusal holds the reservation;
only positive closed no-effect permits fresh original SQL restore.

**M8e2 remaining:** qualify shipping controller/gateway/SDK execution, actual API
reply loss and Pending SIGKILL/restart, absent closure versus late acceptance,
paused final-CAS stop races, deferred expiry, recreated UID and broader physical
evidence attacks.

**M8e3 remaining:** independently accepted custody/writers and production
maintenance, node-failure and SLO qualification. The local VM fixture establishes
software mechanics only. M8 remains incomplete.

Implement the paper's **separate Kubernetes drain** action: narrowly scoped credential, durable controller operation, cordon/eviction and authoritative observed completion. Declare Level C physical limits instead of inheriting SQL Level A. Account for schedulers, autoscalers, humans and other writers before broader availability claims. Uncordon does not restore evicted workloads.

**Exit:** last-slot competitors cannot both spend capacity under the complete declared writer/predicate boundary. Nested/parallel delegation conserves budgets. New A2A task IDs cannot duplicate child allocation. Crash, late effect, partial compensation and compensation failure remain explicit. Unknown forward effects never trigger blind retry, inverse execution or timer refunds.

Cross-cluster ownership/reservations require a further coordination/transfer profile; prefixes, regions and separate local transactions do not establish atomic global allocation.

## M9 — Independent interoperability and release conformance

**M9a runner prerequisite delivered:** [RFC 0033](rfcs/0033-release-conformance.md)
runs the required local corpus with immutable logs/source/tool pins and explicit
open gates. It refuses runtime skips and source changes. Independent wire peers,
a second runtime/target and reproduced release acceptance remain open.

**Code:** publish a conformance runner, negative/fault corpus and trace verifier. Add a second actual runtime adapter and target/credential binding. An independently implemented controller must exchange install/admission/issuance/status/outcome with Rust; another configuration of the same implementation is insufficient proof of independence.

**Protocol:** publish a proposed release with capability matrix, schemas, migration/key rules, security/operations assumptions and reproducible evidence. Test governed MCP/reference carriage through actual intermediaries and A2A peers for the coordination profile. List unsupported variants explicitly.

**Exit:** independent peers pass positive/negative wire exchange, stale install/revocation and lost-response tests. Upgrade/rotation/export/restore retain consumption and original signed history. Another implementer reproduces release evidence. Claims name exact runtimes, targets and protocol variants.

Comparative efficacy/performance requires a separately specified hardened PDP/PEP baseline with equivalent isolation, evidence, exact binding, coordination, guards and recovery. Report attempted, claimed, dispatched, committed, refused and unresolved populations separately. The retained contention matrix is not enterprise mutation-throughput evidence.

## First implementation backlog

1. M0 toolchain/required-mode reproduction and active/legacy protocol index.
2. M1 leaf service contract and operation/authorization model, prioritizing Enforcement Control and status.
3. Typed proposal/CTD/evidence/certificate validation and durable admitted-operation issuance key.
4. Independently authorized admission/issuer/control endpoints with scoped revocation and version acknowledgement.
5. M3a retained grant/attempt resolution is delivered; M3b signed-proposal lookup now resolves missing local grants and lost issuer replies.
6. M3a Node live admission/issuance is delivered for the mock profile; M3b qualifies lost provider replies and failed grant persistence; real providers, power loss and restore remain open.
7. Recovery context/process-kill matrix alongside real identity/broker integration.

Each accepted gate updates the claim inventory with actual results, source/profile versions and owners. An incomplete gate leaves that capability unsupported; continue refusing inputs whose invariants have not been implemented.
