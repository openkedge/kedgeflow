# KedgeFlow Protocol Specifications

This directory contains versioned protocol specifications, normative schemas, and validation tooling for KedgeFlow.

## Principles

1. **Protocol First**: Protocol semantics are decoupled from any transport (in-process, HTTP/REST, gRPC, message queues) and programming language.
2. **Deterministic Schemas**: The canonical wire objects are defined by standard JSON Schemas (Draft 2020-12) located in this package.
3. **Bounded Reference Implementations**: The Rust gateway implements an explicitly restricted v0.9 execution profile; the Python package is a v0.1 local demo. Generic envelope verification alone is not complete admission or payload-schema validation.
4. **Offline Compatibility Vectors**: All normative signed envelopes, test keys, and compatibility fixtures are versioned under [`fixtures/`](../fixtures/).

## Specifications and Contracts

- **Complete Machine-Readable Contracts (v0.9 / KF-JSON-0.2)**:
  - Normative JSON Schema: [`kedgeflow.schema.json`](kedgeflow.schema.json) (Draft 2020-12, closed objects).
  - Validation Engine: [`validate.py`](validate.py) — verifies JSON Schema validity, Ed25519 signatures, RFC 8785 JCS canonicalization, and semantic bindings.
  - Cryptographic Primitives: [`profile.py`](profile.py) — domain-prefixed SHA-256 digests ($H(q)$, $H(E)$) and Ed25519 signing.
  - Schema Generator: [`build_schema.py`](build_schema.py).
  - Normative Fixtures Suite: [`../fixtures/`](../fixtures/) (see [`fixtures/README.md`](../fixtures/README.md)).
  - Optional Grant-Reference Transport: [`GRANT_REFERENCE_PROFILE.md`](GRANT_REFERENCE_PROFILE.md)
    (KF-GRANT-REF-0.1, copied verbatim from the frozen paper).
  - Frozen baseline and contract hashes: [`../docs/whitepaper/v0.9/FREEZE.json`](../docs/whitepaper/v0.9/FREEZE.json).
- **[v0.1 Specification](v0.1/protocol.md)**: Initial core protocol specifying `Proposal`, `AuthorityGrant`, `Guard`, `ExecutionReceipt`, and the lifecycle state machine.

The draft [admission-lineage supplement](drafts/admission-lineage-v0.1.schema.json)
and [RFC 0012](../docs/rfcs/0012-admission-lineage.md) add historical authorization
export/verification without changing frozen signed records.

The draft [control-history supplement](drafts/control-history-v0.1.schema.json)
and [RFC 0013](../docs/rfcs/0013-control-history.md) add observer-attested governance
retention and historical membership; no execution permission is inferred.

The draft [control-bindings supplement](drafts/control-bindings-v0.1.schema.json)
and [RFC 0014](../docs/rfcs/0014-operation-control-bindings.md) add atomic authority
transition snapshots and observer-attested offline control comparisons. Observer
custody, correct ledger operation and clock trust remain explicit assumptions.

## Running Conformance Verification

To run specification conformance checks against the complete fixture suite:

```bash
python spec/validate.py
python scripts/verify-whitepaper.py
```

or through pytest:

```bash
pytest tests/test_fixtures.py
```
