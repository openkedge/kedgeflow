package services

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"time"

	cedar "github.com/cedar-policy/cedar-go"
	"github.com/santhosh-tekuri/jsonschema/v6"
	kf "kedgeflow.local/prototype"
)

type State string

const (
	Satisfied State = "Satisfied"
	Violated  State = "Violated"
	Unknown   State = "Unknown"
)

type Assessment struct {
	ID     string `json:"obligation_id"`
	State  State  `json:"state"`
	Reason string `json:"reason"`
}
type AdmissionRequest struct {
	Proposal json.RawMessage            `json:"proposal"`
	Evidence map[string]json.RawMessage `json:"evidence"`
}
type AdmissionResponse struct {
	Decision         string           `json:"decision"`
	Code             string           `json:"code"`
	Obligations      []Assessment     `json:"obligations"`
	CedarDiagnostics cedar.Diagnostic `json:"cedar_diagnostics"`
	Certificate      json.RawMessage  `json:"certificate,omitempty"`
	Manifest         json.RawMessage  `json:"manifest,omitempty"`
}
type CapacityObservation struct {
	Known           bool   `json:"known"`
	AvailableSlots  int64  `json:"available_slots"`
	ResourceVersion string `json:"resource_version"`
}
type evidence struct {
	WID            string          `json:"wid"`
	ProviderID     string          `json:"provider_id"`
	Question       Ref             `json:"question_ref"`
	ProposalDigest string          `json:"proposal_digest"`
	StateScope     []kf.Resource   `json:"state_scope"`
	StateDigest    string          `json:"state_digest"`
	ResultSchema   Ref             `json:"result_schema"`
	Result         json.RawMessage `json:"result"`
	ObservedAt     int64           `json:"observed_at"`
	ExpiresAt      int64           `json:"expires_at"`
}
type descriptor struct {
	ID                    string          `json:"id"`
	Version               string          `json:"version"`
	Tenant                string          `json:"tenant"`
	Action                string          `json:"action"`
	ParameterSchema       json.RawMessage `json:"parameter_schema"`
	ParameterSchemaDigest string          `json:"parameter_schema_digest"`
	Rendering             struct {
		TemplateDigest        string `json:"template_digest"`
		ParameterSchemaDigest string `json:"parameter_schema_digest"`
	} `json:"rendering"`
	AdapterContract json.RawMessage `json:"adapter_contract"`
	Concurrency     struct {
		PredicateDescriptor json.RawMessage `json:"predicate_descriptor"`
	} `json:"concurrency"`
	OwnershipEpoch uint64 `json:"ownership_epoch"`
	Audience       string `json:"gateway_audience"`
}
type AdmissionConfig struct {
	Validator            *Validator
	Keys                 map[string]TrustKey
	Signer               Signer
	Auth                 kf.Authenticator
	CTD                  json.RawMessage
	PolicyID             string
	PolicyEpoch          uint64
	PolicySource         []byte
	RequiredScope        string
	CapacityProvider     string
	CapacityQuestion     Ref
	CapacityResultSchema Ref
	Review               *ReviewService
	MaxWitnessAge        time.Duration
	CertificateTTL       time.Duration
	Now                  func() time.Time
}
type AdmissionController struct {
	cfg              AdmissionConfig
	descriptor       descriptor
	descriptorDigest string
	policy           kf.Policy
	policies         *cedar.PolicySet
	parameters       *jsonschema.Schema
}

func NewAdmissionController(c AdmissionConfig) (*AdmissionController, error) {
	if c.Now == nil {
		c.Now = time.Now
	}
	if c.MaxWitnessAge <= 0 {
		c.MaxWitnessAge = 10 * time.Second
	}
	if c.CertificateTTL <= 0 {
		c.CertificateTTL = 30 * time.Second
	}
	if c.Review == nil || c.RequiredScope == "" || c.PolicyID == "" || c.PolicyEpoch == 0 || c.Review.cfg.PolicyEpoch != c.PolicyEpoch {
		return nil, errors.New("incomplete admission configuration")
	}
	var d descriptor
	dd, e := verify(c.CTD, "ctd", "ResourceRegistry", c.Keys, c.Validator, &d)
	if e != nil {
		return nil, e
	}
	parameterSchemaDigest, e := kf.Digest("parameter-schema", d.ParameterSchema)
	if e != nil || parameterSchemaDigest != d.ParameterSchemaDigest || d.Rendering.ParameterSchemaDigest != d.ParameterSchemaDigest {
		return nil, errors.New("CTD parameter schema digest mismatch")
	}
	if d.Rendering.TemplateDigest != rawHash([]byte(c.Review.cfg.Template)) {
		return nil, errors.New("CTD rendering template mismatch")
	}
	ps, e := cedar.NewPolicySetFromBytes("admission.cedar", c.PolicySource)
	if e != nil {
		return nil, e
	}
	// The policy digest covers the source and the implemented obligation profile;
	// changing either requires a newly published policy epoch/configuration.
	pd, e := digest("policy", map[string]any{"source": string(c.PolicySource), "profile": "KF-CAPACITY-ADMISSION-0.1", "scope": c.RequiredScope, "epoch": c.PolicyEpoch, "review_policy": c.Review.cfg.PolicyRef, "capacity_question": c.CapacityQuestion, "capacity_result_schema": c.CapacityResultSchema, "max_witness_age_ms": c.MaxWitnessAge.Milliseconds()})
	if e != nil {
		return nil, e
	}
	paramDoc, e := jsonschema.UnmarshalJSON(bytes.NewReader(d.ParameterSchema))
	if e != nil {
		return nil, e
	}
	compiler := jsonschema.NewCompiler()
	compiler.AssertFormat()
	if e = compiler.AddResource("urn:kedgeflow:capacity-parameters", paramDoc); e != nil {
		return nil, e
	}
	params, e := compiler.Compile("urn:kedgeflow:capacity-parameters")
	if e != nil {
		return nil, e
	}
	return &AdmissionController{c, d, dd, kf.Policy{ID: c.PolicyID, Epoch: c.PolicyEpoch, Digest: pd}, ps, params}, nil
}
func (a *AdmissionController) Policy() kf.Policy { return a.policy }
func (a *AdmissionController) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		reject(w, 405, "METHOD_NOT_ALLOWED")
		return
	}
	identity, err := checkedIdentity(a.cfg.Auth, r)
	if err != nil {
		reject(w, 401, "DUAL_IDENTITY_REQUIRED")
		return
	}
	var req AdmissionRequest
	if decodeBody(w, r, &req) != nil {
		reject(w, 400, "INVALID_REQUEST")
		return
	}
	resp, err := a.Admit(req, identity)
	if err != nil {
		reject(w, 400, "INVALID_BINDING")
		return
	}
	send(w, 200, resp)
}
func (a *AdmissionController) Admit(req AdmissionRequest, id kf.Identity) (AdmissionResponse, error) {
	resp := AdmissionResponse{Decision: "defer", Code: "NEEDS_EVIDENCE", Obligations: []Assessment{}}
	var q Proposal
	qd, err := verify(req.Proposal, "proposal", "AgentAdapter", a.cfg.Keys, a.cfg.Validator, &q)
	if err != nil {
		return resp, err
	}
	now := a.cfg.Now().UnixMilli()
	db, err := canonical(q.Delegation)
	if err != nil {
		return resp, err
	}
	delegationDigest, err := kf.Digest("delegation", db)
	if err != nil {
		return resp, err
	}
	if q.Subject != id.Subject || q.WorkloadID != id.WorkloadID || q.Delegation.DPoPJKT != id.DPoPJKT || delegationDigest != id.DelegationDigest || !id.Scopes[a.cfg.RequiredScope] || q.Delegation.ExpiresAt <= now || q.CreatedAt > now+5000 {
		return resp, errors.New("proposal dual identity mismatch")
	}
	if q.Action.ID != a.descriptor.Action || q.Action.Version != a.descriptor.Version || q.Action.Digest != a.descriptorDigest || q.Tenant != a.descriptor.Tenant || len(q.Resources) != 1 || len(q.BaselineState) != 1 || q.Resources[0] != q.BaselineState[0].Resource || string(q.Workflow) != "null" || len(q.Dependencies) != 0 {
		return resp, errors.New("unsupported descriptor, resource or workflow")
	}
	var adapter struct {
		GuardScope     []string `json:"guard_scope"`
		CompletionMode string   `json:"completion_mode"`
	}
	if json.Unmarshal(a.descriptor.AdapterContract, &adapter) != nil || len(adapter.GuardScope) != 1 || adapter.GuardScope[0] != q.Resources[0].ID || q.RequestedCompletion != adapter.CompletionMode {
		return resp, errors.New("resource not in registered adapter scope")
	}
	var registeredPredicate struct {
		Clauses []struct {
			Kind     string      `json:"kind"`
			Resource kf.Resource `json:"resource"`
		} `json:"clauses"`
	}
	if json.Unmarshal(a.descriptor.Concurrency.PredicateDescriptor, &registeredPredicate) != nil || len(registeredPredicate.Clauses) != 1 || registeredPredicate.Clauses[0].Kind != "version_eq" || registeredPredicate.Clauses[0].Resource != q.Resources[0] {
		return resp, errors.New("resource not in registered predicate scope")
	}
	params, e := jsonschema.UnmarshalJSON(bytes.NewReader(q.Parameters))
	if e != nil || a.parameters.Validate(params) != nil {
		return resp, errors.New("parameters violate CTD")
	}
	var args struct {
		Slots       int64  `json:"slots"`
		OrderID     string `json:"order_id"`
		OperationID string `json:"operation_id"`
	}
	if json.Unmarshal(q.Parameters, &args) != nil || args.Slots < 1 {
		return resp, errors.New("unsupported capacity parameters")
	}
	pd, _ := kf.Digest("parameters", q.Parameters)
	identityFacts := map[string]any{"subject": id.Subject, "workload_id": id.WorkloadID, "delegation_digest": delegationDigest, "proposal_digest": qd, "checked_at": now}
	identityDigest, _ := digest("identity_check", identityFacts)
	discharges := []map[string]any{}
	witnesses := []map[string]any{}
	expiry := now + a.cfg.CertificateTTL.Milliseconds()
	if q.Delegation.ExpiresAt < expiry {
		expiry = q.Delegation.ExpiresAt
	}
	if q.BaselineState[0].ExpiresAt < expiry {
		expiry = q.BaselineState[0].ExpiresAt
	}
	add := func(name string, state State, reason string, ref Ref, observed, end int64, jit bool) {
		resp.Obligations = append(resp.Obligations, Assessment{name, state, reason})
		if state != Satisfied {
			return
		}
		if end < expiry {
			expiry = end
		}
		stage := "static"
		if jit {
			stage = "jit"
		}
		predicateDigest, _ := digest("obligation", map[string]any{"profile": "KF-CAPACITY-ADMISSION-0.1", "obligation_id": name, "policy_digest": a.policy.Digest})
		discharges = append(discharges, map[string]any{"obligation_id": name, "predicate_digest": predicateDigest, "witness_refs": []Ref{ref}, "result": "satisfied", "stage": stage, "execution_relevant": jit, "observed_at": observed, "expires_at": end})
		witnesses = append(witnesses, map[string]any{"witness": ref, "obligation_id": name, "execution_relevant": jit, "expires_at": end})
	}
	add("identity", Satisfied, "verified subject/workload delegation", Ref{"identity:" + q.QID, "urn:kedgeflow:dual-identity-check:1.0", identityDigest}, now, expiry, false)
	capacityState := Unknown
	capacityReason := "missing fresh capacity witness"
	var capacityRef Ref
	var observed, end int64
	if raw, ok := req.Evidence["capacity"]; ok {
		var ev evidence
		ed, e := verify(raw, "evidence", "EvidenceProvider", a.cfg.Keys, a.cfg.Validator, &ev)
		if e != nil {
			return resp, e
		}
		if ev.ProviderID != a.cfg.CapacityProvider || ev.Question != a.cfg.CapacityQuestion || ev.ResultSchema != a.cfg.CapacityResultSchema || ev.ProposalDigest != qd || len(ev.StateScope) != 1 || ev.StateScope[0] != q.Resources[0] || ev.StateDigest != q.BaselineState[0].StateDigest {
			return resp, errors.New("capacity witness binding mismatch")
		}
		var result CapacityObservation
		var fields map[string]json.RawMessage
		_ = json.Unmarshal(ev.Result, &fields)
		if len(fields) != 3 || fields["known"] == nil || fields["available_slots"] == nil || fields["resource_version"] == nil {
			return resp, errors.New("capacity result schema mismatch")
		}
		d := json.NewDecoder(bytes.NewReader(ev.Result))
		d.DisallowUnknownFields()
		if d.Decode(&result) != nil || result.AvailableSlots < 0 || result.AvailableSlots > 9007199254740991 || result.ResourceVersion == "" {
			return resp, errors.New("capacity result schema mismatch")
		}
		observed, end = ev.ObservedAt, ev.ExpiresAt
		capacityRef = Ref{ev.WID, SchemaURL + "#/$defs/Evidence", ed}
		fresh := observed <= now && now-observed <= a.cfg.MaxWitnessAge.Milliseconds() && end > now && end > observed && q.BaselineState[0].ObservedAt <= now && q.BaselineState[0].ExpiresAt > now && q.BaselineState[0].ExpiresAt > q.BaselineState[0].ObservedAt && result.ResourceVersion == q.BaselineState[0].Version
		if fresh && result.Known {
			capacityState = Satisfied
			capacityReason = "capacity witness meets slot obligation"
			if result.AvailableSlots < args.Slots {
				capacityState = Violated
				capacityReason = "insufficient observed capacity"
			}
		} else {
			capacityReason = "unknown or stale capacity observation"
		}
	}
	add("capacity", capacityState, capacityReason, capacityRef, observed, end, true)
	reviewState := Unknown
	reviewReason := "missing proposal-bound human witness"
	var hr Ref
	var ht, endh int64
	if raw, ok := req.Evidence["review"]; ok {
		var hw HitlWitness
		hd, e := verify(raw, "hitl_witness", "EvidenceProvider", a.cfg.Keys, a.cfg.Validator, &hw)
		if e != nil {
			return resp, e
		}
		e = a.cfg.Review.CheckWitness(hw, q, qd, pd, a.policy.Epoch)
		if e != nil {
			return resp, e
		}
		hr = Ref{hw.WID, SchemaURL + "#/$defs/HitlWitness", hd}
		ht, endh = hw.VerifiedAt, hw.ExpiresAt
		if endh > now {
			reviewState = Satisfied
			reviewReason = "verified canonical WebAuthn review"
			if hw.Approval.Verdict == "reject" {
				reviewState = Violated
				reviewReason = "reviewer rejected proposal"
			}
		}
	}
	add("review", reviewState, reviewReason, hr, ht, endh, false)
	for key := range req.Evidence {
		if key != "capacity" && key != "review" {
			return resp, fmt.Errorf("unsupported obligation %s", key)
		}
	}
	all := true
	for _, v := range resp.Obligations {
		if v.State == Violated {
			resp.Decision = "deny"
			resp.Code = "OBLIGATION_VIOLATED"
		}
		if v.State != Satisfied {
			all = false
		}
	}
	// Cedar evaluates entitlement over independently verified static inputs.
	// Ternary evidence is evaluated above: Unknown is never mapped to false or
	// silently interpreted as a satisfied/violated Cedar context predicate.
	decision, diag := cedar.Authorize(a.policies, nil, cedar.Request{Principal: cedar.NewEntityUID("KedgeFlow::Subject", cedar.String(q.Subject.Iss+"|"+q.Subject.Sub)), Action: cedar.NewEntityUID("KedgeFlow::Action", cedar.String(q.Action.ID)), Resource: cedar.NewEntityUID("KedgeFlow::Resource", cedar.String(q.Resources[0].ID)), Context: cedar.NewRecord(cedar.RecordMap{"workload": cedar.String(q.WorkloadID), "scope": cedar.String(a.cfg.RequiredScope), "identity": cedar.True, "policyEpoch": cedar.Long(a.policy.Epoch)})})
	resp.CedarDiagnostics = diag
	if len(diag.Errors) > 0 {
		resp.Decision = "deny"
		resp.Code = "POLICY_EVALUATION_ERROR"
		return resp, nil
	}
	if decision != cedar.Allow {
		resp.Decision = "deny"
		resp.Code = "POLICY_DENIED"
		return resp, nil
	}
	if !all {
		return resp, nil
	}
	if expiry <= now {
		return resp, errors.New("no valid admission interval")
	}
	manifestPayload := map[string]any{"mid": "manifest:" + q.QID, "proposal_digest": qd, "policy": a.policy, "witnesses": witnesses, "assembled_at": now}
	manifest, err := a.cfg.Signer.Sign("manifest", manifestPayload)
	if err != nil {
		return resp, err
	}
	manifestDigest, _ := kf.Digest("manifest", manifest)
	var pred map[string]any
	if json.Unmarshal(a.descriptor.Concurrency.PredicateDescriptor, &pred) != nil {
		return resp, errors.New("invalid registry predicate")
	}
	clauses, ok := pred["clauses"].([]any)
	if !ok || len(clauses) != 1 {
		return resp, errors.New("unsupported registry predicate")
	}
	clause, ok := clauses[0].(map[string]any)
	if !ok || clause["kind"] != "version_eq" {
		return resp, errors.New("unsupported registry guard")
	}
	clause["resource"] = q.Resources[0]
	clause["expected_version"] = q.BaselineState[0].Version
	constraints := map[string]any{"action": q.Action, "resources": q.Resources, "parameters_digest": pd, "predicate_descriptor": pred, "adapter_contract": a.descriptor.AdapterContract, "audience": a.descriptor.Audience, "max_attempts": 1, "expires_at": expiry, "saga_budget": nil}
	constraintDigest, _ := digest("constraints", constraints)
	omd, _ := digest("obligation_manifest", []string{"identity", "capacity", "review"})
	certPayload := map[string]any{"cid": "certificate:" + q.QID, "proposal_digest": qd, "delegation_digest": delegationDigest, "subject": q.Subject, "workload_id": q.WorkloadID, "policy": a.policy, "ownership_epoch": a.descriptor.OwnershipEpoch, "descriptor_digest": a.descriptorDigest, "obligation_manifest_digest": omd, "evidence_manifest_digest": manifestDigest, "discharges": discharges, "constraints": constraints, "constraint_digest": constraintDigest, "lease_digest": nil, "admitted_at": now, "expires_at": expiry}
	cert, err := a.cfg.Signer.Sign("certificate", certPayload)
	if err != nil {
		return resp, err
	}
	if err = a.cfg.Validator.Validate(cert); err != nil {
		return resp, err
	}
	if err = a.cfg.Validator.Validate(manifest); err != nil {
		return resp, err
	}
	resp.Decision = "admit"
	resp.Code = "ADMITTED"
	resp.Certificate = cert
	resp.Manifest = manifest
	return resp, nil
}
