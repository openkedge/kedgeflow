package main

import (
	"crypto/ed25519"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"encoding/pem"
	"flag"
	"log"
	"net/http"
	"net/url"
	"os"
	"strings"
	"sync"
	"time"

	kf "kedgeflow.local/prototype"
	"kedgeflow.local/services"
)

type keyConfig struct {
	KeyID     string `json:"key_id"`
	Role      string `json:"role"`
	OwnerID   string `json:"owner_id"`
	PublicKey string `json:"public_key_base64"`
}
type config struct {
	Listen               string                `json:"listen"`
	ExternalBase         string                `json:"external_base"`
	Certificate          string                `json:"certificate"`
	PrivateKey           string                `json:"private_key"`
	WorkloadCA           string                `json:"workload_ca"`
	SchemaPath           string                `json:"schema_path"`
	CTDPath              string                `json:"ctd_path"`
	PolicyPath           string                `json:"policy_path"`
	PolicyID             string                `json:"policy_id"`
	PolicyEpoch          uint64                `json:"policy_epoch"`
	TemplatePath         string                `json:"template_path"`
	OIDCIssuer           string                `json:"oidc_issuer"`
	OIDCPublicKey        string                `json:"oidc_public_key_base64"`
	TokenAudience        string                `json:"token_audience"`
	Keys                 []keyConfig           `json:"keys"`
	AdmissionKeyID       string                `json:"admission_key_id"`
	AdmissionKeyFile     string                `json:"admission_key_file"`
	ReviewKeyID          string                `json:"review_key_id"`
	ReviewKeyFile        string                `json:"review_key_file"`
	RequiredScope        string                `json:"required_scope"`
	CapacityProvider     string                `json:"capacity_provider"`
	CapacityQuestion     services.Ref          `json:"capacity_question"`
	CapacityResultSchema services.Ref          `json:"capacity_result_schema"`
	ReviewProvider       string                `json:"review_provider"`
	ReviewPolicy         services.Ref          `json:"review_policy"`
	RPID                 string                `json:"rp_id"`
	Origin               string                `json:"origin"`
	AllowedReviewers     []kf.Subject          `json:"allowed_reviewers"`
	Enrollments          []services.Enrollment `json:"enrollments"`
	HardwareRequired     bool                  `json:"hardware_bound_required"`
	AttestationRequired  bool                  `json:"attestation_required"`
}

func read(path string) []byte {
	b, e := os.ReadFile(path)
	if e != nil {
		log.Fatal(e)
	}
	return b
}
func public(s string) ed25519.PublicKey {
	b, e := base64.StdEncoding.DecodeString(s)
	if e != nil || len(b) != 32 {
		log.Fatal("expected 32-byte Ed25519 public key base64")
	}
	return b
}
func signer(id, path string) services.Signer {
	block, _ := pem.Decode(read(path))
	if block == nil {
		log.Fatal("expected PKCS8 private key PEM")
	}
	k, e := x509.ParsePKCS8PrivateKey(block.Bytes)
	if e != nil {
		log.Fatal(e)
	}
	private, ok := k.(ed25519.PrivateKey)
	if !ok {
		log.Fatal("signing key must be Ed25519")
	}
	return services.Signer{KeyID: id, PrivateKey: private}
}

type routeAuth struct {
	mu     sync.Mutex
	config config
	routes map[string]*kf.DualAuthenticator
}

func (a *routeAuth) Authenticate(r *http.Request) (kf.Identity, error) {
	a.mu.Lock()
	auth, ok := a.routes[r.URL.Path]
	if !ok {
		auth = &kf.DualAuthenticator{Issuer: a.config.OIDCIssuer, Audience: a.config.TokenAudience, ExternalURL: a.config.ExternalBase + r.URL.Path, IssuerKey: public(a.config.OIDCPublicKey)}
		a.routes[r.URL.Path] = auth
	}
	a.mu.Unlock()
	return auth.Authenticate(r)
}
func main() {
	path := flag.String("config", "", "trusted service configuration JSON")
	flag.Parse()
	if *path == "" {
		flag.Usage()
		os.Exit(2)
	}
	var c config
	dec := json.NewDecoder(strings.NewReader(string(read(*path))))
	dec.DisallowUnknownFields()
	if e := dec.Decode(&c); e != nil {
		log.Fatal(e)
	}
	u, e := url.Parse(c.ExternalBase)
	if e != nil || u.Scheme != "https" || u.Host == "" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || u.Path != "" || c.TokenAudience == "" {
		log.Fatal("external_base must be an HTTPS origin; token_audience required")
	}
	validator, e := services.LoadValidator(c.SchemaPath)
	if e != nil {
		log.Fatal(e)
	}
	keys := map[string]services.TrustKey{}
	for _, k := range c.Keys {
		if _, ok := keys[k.KeyID]; ok {
			log.Fatal("duplicate trust key")
		}
		keys[k.KeyID] = services.TrustKey{Role: k.Role, OwnerID: k.OwnerID, PublicKey: public(k.PublicKey)}
	}
	admissionSigner := signer(c.AdmissionKeyID, c.AdmissionKeyFile)
	reviewSigner := signer(c.ReviewKeyID, c.ReviewKeyFile)
	keys[c.AdmissionKeyID] = services.TrustKey{Role: "AdmissionController", PublicKey: admissionSigner.PrivateKey.Public().(ed25519.PublicKey)}
	keys[c.ReviewKeyID] = services.TrustKey{Role: "EvidenceProvider", OwnerID: c.ReviewProvider, PublicKey: reviewSigner.PrivateKey.Public().(ed25519.PublicKey)}
	template := services.CanonicalTemplate
	if c.TemplatePath != "" {
		template = string(read(c.TemplatePath))
	}
	auth := &routeAuth{config: c, routes: map[string]*kf.DualAuthenticator{}}
	review, e := services.NewReviewService(services.ReviewConfig{Validator: validator, Keys: keys, Signer: reviewSigner, Auth: auth, ProviderID: c.ReviewProvider, PolicyEpoch: c.PolicyEpoch, PolicyRef: c.ReviewPolicy, Template: template, RPID: c.RPID, Origin: c.Origin, AllowedReviewers: c.AllowedReviewers, Enrollments: c.Enrollments, HardwareRequired: c.HardwareRequired, AttestationRequired: c.AttestationRequired})
	if e != nil {
		log.Fatal(e)
	}
	admission, e := services.NewAdmissionController(services.AdmissionConfig{Validator: validator, Keys: keys, Signer: admissionSigner, Auth: auth, CTD: read(c.CTDPath), PolicyID: c.PolicyID, PolicyEpoch: c.PolicyEpoch, PolicySource: read(c.PolicyPath), RequiredScope: c.RequiredScope, CapacityProvider: c.CapacityProvider, CapacityQuestion: c.CapacityQuestion, CapacityResultSchema: c.CapacityResultSchema, Review: review})
	if e != nil {
		log.Fatal(e)
	}
	cert, e := tls.LoadX509KeyPair(c.Certificate, c.PrivateKey)
	if e != nil {
		log.Fatal(e)
	}
	pool := x509.NewCertPool()
	if !pool.AppendCertsFromPEM(read(c.WorkloadCA)) {
		log.Fatal("invalid workload CA")
	}
	server := &http.Server{Addr: c.Listen, Handler: services.NewMux(admission, review), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second, IdleTimeout: 30 * time.Second, TLSConfig: &tls.Config{MinVersion: tls.VersionTLS13, ClientAuth: tls.RequireAndVerifyClientCert, ClientCAs: pool, Certificates: []tls.Certificate{cert}}}
	log.Printf("bounded admission/HITL services listening on %s; no grant issuing or resource mutation", c.Listen)
	log.Fatal(server.ListenAndServeTLS("", ""))
}
