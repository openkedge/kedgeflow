// Package services implements a bounded, single-resource admission/review slice.
// Its certificates are evidence of admission, never execution grants.
package services

import (
	"bytes"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"

	"github.com/santhosh-tekuri/jsonschema/v6"
	kf "kedgeflow.local/prototype"
)

const SchemaURL = "https://kedgeflow.dev/spec/v0.9/kedgeflow.schema.json"

var definitions = map[string]string{"proposal": "Proposal", "ctd": "ConsequentialToolDescriptor", "certificate": "AdmissionCertificate", "evidence": "Evidence", "hitl_witness": "HitlWitness", "manifest": "WitnessManifest"}

type TrustKey struct {
	Role      string
	OwnerID   string
	PublicKey ed25519.PublicKey
}
type Signer struct {
	KeyID      string
	PrivateKey ed25519.PrivateKey
}

// Validator uses the actual closed v0.9 schema rather than accepting arbitrary
// claims alongside signed payloads. It resolves only a local schema resource.
type Validator struct{ root *jsonschema.Schema }

func LoadValidator(path string) (*Validator, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	doc, err := jsonschema.UnmarshalJSON(bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	c := jsonschema.NewCompiler()
	c.AssertFormat()
	if err = c.AddResource(SchemaURL, doc); err != nil {
		return nil, err
	}
	s, err := c.Compile(SchemaURL)
	if err != nil {
		return nil, err
	}
	return &Validator{s}, nil
}
func (v *Validator) Validate(raw []byte) error {
	if _, err := kf.Canonical(raw); err != nil {
		return err
	}
	x, err := jsonschema.UnmarshalJSON(bytes.NewReader(raw))
	if err != nil {
		return err
	}
	return v.root.Validate(x)
}
func canonical(v any) ([]byte, error) {
	b, e := json.Marshal(v)
	if e != nil {
		return nil, e
	}
	return kf.Canonical(b)
}
func rawHash(b []byte) string { h := sha256.Sum256(b); return hex.EncodeToString(h[:]) }
func digest(kind string, v any) (string, error) {
	b, e := canonical(v)
	if e != nil {
		return "", e
	}
	return kf.Digest(kind, b)
}
func signedInput(e kf.Envelope) ([]byte, error) {
	b, err := canonical(map[string]any{"profile": e.Profile, "kind": e.Kind, "schema": e.Schema, "key_id": e.KeyID, "payload": e.Payload})
	if err != nil {
		return nil, err
	}
	return append([]byte("KedgeFlow/"+kf.Profile+"\x00"), b...), nil
}
func (s Signer) Sign(kind string, payload any) (json.RawMessage, error) {
	def, ok := definitions[kind]
	if !ok || len(s.PrivateKey) != ed25519.PrivateKeySize {
		return nil, errors.New("invalid signer/kind")
	}
	p, err := canonical(payload)
	if err != nil {
		return nil, err
	}
	e := kf.Envelope{Profile: kf.Profile, Kind: kind, Schema: SchemaURL + "#/$defs/" + def, KeyID: s.KeyID, Payload: p}
	b, err := signedInput(e)
	if err != nil {
		return nil, err
	}
	e.Signature = base64.RawURLEncoding.EncodeToString(ed25519.Sign(s.PrivateKey, b))
	return canonical(e)
}
func verify(raw []byte, kind, role string, keys map[string]TrustKey, validator *Validator, out any) (string, error) {
	if validator == nil {
		return "", errors.New("schema validator absent")
	}
	if err := validator.Validate(raw); err != nil {
		return "", err
	}
	var e kf.Envelope
	if err := json.Unmarshal(raw, &e); err != nil {
		return "", err
	}
	key, ok := keys[e.KeyID]
	if !ok || key.Role != role || e.Kind != kind || e.Profile != kf.Profile {
		return "", errors.New("untrusted role or kind")
	}
	if role == "EvidenceProvider" {
		var payload struct {
			ProviderID string `json:"provider_id"`
		}
		if json.Unmarshal(e.Payload, &payload) != nil || key.OwnerID == "" || key.OwnerID != payload.ProviderID {
			return "", errors.New("evidence provider key ownership mismatch")
		}
	}
	input, err := signedInput(e)
	if err != nil {
		return "", err
	}
	sig, err := base64.RawURLEncoding.DecodeString(e.Signature)
	if err != nil || len(key.PublicKey) != 32 || !ed25519.Verify(key.PublicKey, input, sig) {
		return "", errors.New("invalid signature")
	}
	if err = json.Unmarshal(e.Payload, out); err != nil {
		return "", err
	}
	if kind == "proposal" {
		return digest(kind, map[string]any{"schema": e.Schema, "payload": e.Payload})
	}
	return kf.Digest(kind, raw)
}

type Proposal struct {
	QID        string     `json:"qid"`
	Tenant     string     `json:"tenant"`
	Subject    kf.Subject `json:"subject"`
	WorkloadID string     `json:"workload_id"`
	Delegation struct {
		AccessTokenDigest   string   `json:"access_token_digest"`
		DPoPJKT             string   `json:"dpop_jkt"`
		AuthorizationServer string   `json:"authorization_server"`
		TokenAudience       string   `json:"token_audience"`
		Scopes              []string `json:"scopes"`
		ExpiresAt           int64    `json:"expires_at"`
	} `json:"delegation"`
	Intent        string            `json:"intent"`
	Action        kf.Action         `json:"action"`
	Resources     []kf.Resource     `json:"resources"`
	Parameters    json.RawMessage   `json:"parameters"`
	Dependencies  []json.RawMessage `json:"dependencies"`
	BaselineState []struct {
		Resource    kf.Resource `json:"resource"`
		Version     string      `json:"version"`
		StateDigest string      `json:"state_digest"`
		ObservedAt  int64       `json:"observed_at"`
		ExpiresAt   int64       `json:"expires_at"`
	} `json:"baseline_state"`
	RequestedCompletion string          `json:"requested_completion"`
	CreatedAt           int64           `json:"created_at"`
	Workflow            json.RawMessage `json:"workflow"`
}
type Ref struct {
	ID     string `json:"id"`
	Schema string `json:"schema"`
	Digest string `json:"digest"`
}
type Approval struct {
	ProposalDigest   string     `json:"proposal_digest"`
	PolicyEpoch      uint64     `json:"policy_epoch"`
	Reviewer         kf.Subject `json:"reviewer"`
	TemplateDigest   string     `json:"rendering_template_digest"`
	RenderedDigest   string     `json:"rendered_digest"`
	ParametersDigest string     `json:"parameters_digest"`
	ReviewedAt       int64      `json:"reviewed_at"`
	ExpiresAt        int64      `json:"expires_at"`
	Verdict          string     `json:"verdict"`
	Nonce            string     `json:"nonce"`
	RPID             string     `json:"rp_id"`
}
type AuthenticatorPolicy struct {
	PolicyRef           Ref  `json:"policy_ref"`
	EnrollmentRef       Ref  `json:"enrollment_ref"`
	HardwareRequired    bool `json:"hardware_bound_required"`
	AttestationRequired bool `json:"attestation_required"`
	Approved            bool `json:"approved_authenticator"`
}
type HitlWitness struct {
	WID                 string              `json:"wid"`
	Subject             kf.Subject          `json:"subject"`
	Approval            Approval            `json:"approval"`
	ChallengeDigest     string              `json:"challenge_digest"`
	RPID                string              `json:"rp_id"`
	Origin              string              `json:"origin"`
	CredentialID        string              `json:"credential_id"`
	UserPresent         bool                `json:"user_present"`
	UserVerified        bool                `json:"user_verified"`
	AuthenticatorPolicy AuthenticatorPolicy `json:"authenticator_policy"`
	AssertionRef        Ref                 `json:"assertion_ref"`
	AssertionDigest     string              `json:"assertion_digest"`
	SignCount           uint32              `json:"sign_count"`
	VerificationResult  string              `json:"verification_result"`
	VerifiedAt          int64               `json:"verified_at"`
	ExpiresAt           int64               `json:"expires_at"`
	ProviderID          string              `json:"provider_id"`
}

func decodeBody(w http.ResponseWriter, r *http.Request, out any) error {
	b, err := io.ReadAll(http.MaxBytesReader(w, r.Body, 1<<20))
	if err != nil {
		return err
	}
	if _, err = kf.Canonical(b); err != nil {
		return err
	}
	d := json.NewDecoder(bytes.NewReader(b))
	d.DisallowUnknownFields()
	if err = d.Decode(out); err != nil {
		return err
	}
	var extra any
	if d.Decode(&extra) != io.EOF {
		return errors.New("trailing JSON")
	}
	return nil
}
func send(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}
func reject(w http.ResponseWriter, status int, code string) {
	send(w, status, map[string]string{"error": code})
}
func checkedIdentity(auth kf.Authenticator, r *http.Request) (kf.Identity, error) {
	if auth == nil {
		return kf.Identity{}, errors.New("authentication absent")
	}
	return auth.Authenticate(r)
}
func randomID() string {
	b := make([]byte, 32)
	if _, e := io.ReadFull(rand.Reader, b); e != nil {
		panic(fmt.Sprintf("entropy unavailable: %v", e))
	}
	return base64.RawURLEncoding.EncodeToString(b)
}
