# KedgeFlow bounded admission and HITL services

This executable reference slice implements an Admission Controller and a WebAuthn-verifying HITL Evidence Provider. It signs the paper's `KF-JSON-0.2` `AdmissionCertificate`, `WitnessManifest`, and `HitlWitness` envelopes. A certificate does **not** authorize execution: the independent Grant Authority and Execution Gateway must still allocate and claim a conserved grant.

The supported admission profile is `KF-CAPACITY-ADMISSION-0.1`: one registered `capacity.reserve` action, one resource incarnation, a fresh capacity observation, an authorized user/workload delegation, a canonical human witness, a `version_eq` predicate, and a CTD parameter schema. Dependencies and saga workflow bindings are rejected. The controller neither issues grants nor dispatches mutations. Its observations do not lock external state; the resource adapter must enforce the admitted version at commit.

## Run and verify

Go 1.24 or newer is required. Dependencies are pinned in `go.mod`/`go.sum`; the local `replace` imports the sibling gateway's JCS, digest, identity, and signed-envelope types.

```sh
cd acp/services
go test -race -v ./...
go vet ./...
go build ./cmd/kf-services
go run ./cmd/kf-services -config service-config.json
```

Tests generate fresh software Ed25519/P-256 authenticator keys. They verify actual WebAuthn assertion signatures over `authenticatorData || SHA256(clientDataJSON)`, the ternary outcomes, Cedar forbid/diagnostic handling, proposal/template/policy substitution, replay races, missing UV, unenrolled credentials, and refusal of software credentials under the hardware profile. An HTTP test exercises challenge → verified witness → signed certificate through the actual handlers. It injects the caller authentication function; it does not claim a physical authenticator ceremony or an enterprise identity-provider integration.

The final verification run is preserved in [raw race-test output](results/raw-race-tests.txt) and the [vet execution record](results/vet.txt). The race run used `go test -race -count=1 -v ./...` and exited successfully; `go vet ./...` exited successfully with no diagnostics.

`cmd/kf-services` reads trusted configuration and runs HTTPS with TLS 1.3 and required, verified client certificates. It uses the sibling prototype's bounded dual authenticator: a pinned Ed25519 issuer access token, DPoP request proof, verified SPIFFE URI SAN, request audience, and local reviewer/permission policy. Tokens must be audience-bound to these KedgeFlow service endpoints. This is independent of core MCP access authorization. Each request needs a fresh DPoP proof whose `htu` is `external_base` plus the exact route path. This authenticator profile does not implement OIDC discovery, arbitrary algorithms, a replicated DPoP replay cache, or the SPIFFE Workload API/SPIRE lifecycle.

## HTTP contract

| Endpoint | Input / result |
|---|---|
| `POST /hitl/challenge` | `{ "proposal": <signed Proposal envelope>, "verdict": "approve" or "reject" }`. Returns `review_id`, exact server-owned `approval`, deterministic `rendered` UTF-8 bytes, and `public_key` WebAuthn request options. |
| `GET /hitl/review/{id}` | An authenticated, HTML-escaped rendering of the same bytes. The page has no agent summary, scripts, external assets, or mutation capability. |
| `POST /hitl/verify` | `{ "review_id": string, "assertion": { "id", "type": "public-key", "authenticatorData", "clientDataJSON", "signature", "userHandle": string or null } }`. Byte fields use unpadded base64url. Returns `{ "witness": <signed HitlWitness envelope> }`. |
| `POST /admission/admit` | `{ "proposal": <signed Proposal envelope>, "evidence": { "capacity": <signed Evidence envelope>, "review": <signed HitlWitness envelope> } }`. Missing evidence is allowed as input. Returns `decision`, `code`, ternary `obligations`, and Cedar diagnostics. Only `admit` includes a signed `certificate` and `manifest`. |
| `GET /healthz` | Service status and bounded admission profile identifier. The CLI still requires mTLS at the listener. |

Bodies are capped at 1 MiB. Unknown request properties, unknown evidence obligation names, invalid/duplicate JSON, unsigned/incorrect-role envelopes, provider-key impersonation, and CTD resource-scope escapes are rejected. Evidence signing keys are bound to their exact `provider_id`; a capacity provider cannot impersonate the HITL provider.

The capacity provider must publish an `Evidence` record bound to the exact proposal, registered question/result-schema references, resource incarnation and baseline state digest. Its result has exactly these fields:

```json
{"known":true,"available_slots":4,"resource_version":"241"}
```

`known:false`, missing evidence, expired or future observations, and mismatched state versions produce `Unknown` and `NEEDS_EVIDENCE`. A fresh known observation with insufficient slots produces `Violated` and denial. Fully satisfied obligations plus Cedar permission produce admission. Untrusted or substituted evidence is rejected rather than classified as a legitimate negative observation.

## Frozen policy and schema input profile

The actual upstream [Cedar Go authorizer](https://github.com/cedar-policy/cedar-go/tree/v1.8.0) is pinned to **v1.8.0**. The controller evaluates principal/action/resource identities and a server-constructed context with `workload: String`, `scope: String`, `identity: Boolean`, and `policyEpoch: Long`. It accepts no caller-supplied Cedar entities or context booleans. Capacity/review obligations are evaluated independently using `Satisfied`, `Violated`, and `Unknown`; Unknown is never converted into a false Cedar fact. `policy.cedar` is a complete policy for the fixture action/resource/workload.

Every Cedar evaluation diagnostic causes denial, including the case where Cedar's native skip-on-error behavior would otherwise return `Allow`. The policy digest covers the Cedar source, epoch, typed obligation profile, review policy, provider result/question contracts, and freshness bound. Changing these inputs requires publishing/reloading a new controlled policy configuration. This slice uses the engine parser plus a frozen typed request profile; it does not claim a general Cedar schema validator, policy-template support, online policy-authority replication, or formal correctness of arbitrary policy code.

The closed v0.9 schema is read locally from `acp/spec/kedgeflow.schema.json` and validated with [`jsonschema/v6`](https://github.com/santhosh-tekuri/jsonschema/tree/v6.0.2), pinned to **v6.0.2**. The separately signed CTD's parameter-schema digest and rendering-template digest are checked. Runtime schemas are compiled from the trusted CTD. Only the registered guard resource may appear in the certificate; dynamic expected versions can change without widening its resource scope.

## WebAuthn assurance boundary

The service constructs the exact canonical approval payload, including proposal digest, policy epoch, reviewer identity, template digest, rendered-byte digest, parameter digest, server time, expiry, verdict, nonce and RP ID. The browser's challenge is `base64url(SHA256(JCS(approval)))`. The witness records the plain hex challenge digest and verified assertion provenance; it does not pretend that WebAuthn directly signs arbitrary JSON. The service verifies challenge/type/origin, RP ID hash, UP/UV, supported flags, signature, enrolled key/subject, signature counter and one-time review session. It supports EdDSA and ES256 assertions and intentionally rejects authenticator extensions and cross-origin ceremonies. Bidirectional formatting controls are rejected by this bounded renderer.

Credential enrollment is **trusted administrator configuration derived from an external registrar**. There is no HTTP registration endpoint, no client-supplied trust flag, and no built-in attestation-chain verification. Hardware/attestation profiles require an approved external enrollment with the corresponding verified status, a referenced enrollment record, no `test_only` flag, and—under the device-bound profile—no backup-eligible assertion. Physical attestation validation, authenticator allowlists/revocation, trustworthy registrar operation, and browser ceremony/UI hardening must be supplied and assessed by the deployment. UV alone does not prove hardware binding. The software test enrollment cannot satisfy the hardware profile.

The HTTP page supplies the exact trusted rendering; a client converts `public_key.challenge` and `allowCredentials[].id` from base64url to byte arrays, calls `navigator.credentials.get`, and submits the actual response to `/hitl/verify`. Browser login/session integration and calling `navigator.credentials.get` are intentionally outside the service. A compromised renderer/browser can still misrepresent what the human sees; signatures prove challenge binding under the stated trusted-client assumptions, not human understanding.

Review sessions and signature counters are in memory and limited to one process. Restart discards outstanding challenges. A replicated deployment needs a shared atomic challenge-consumption/enrollment-counter store and bounded revocation synchronization. No live hardware assurance, cross-replica HITL guarantee, general saga recovery, or external commit guarantee is claimed by these tests.

## Trusted CLI configuration

All paths resolve from the process working directory. `service-config.json` is an operator-supplied JSON object with the following exact fields; the CLI rejects unknown fields and never accepts these through HTTP:

| Field | Type and meaning |
|---|---|
| `listen`, `external_base` | Listener address and externally verified HTTPS origin, with no path/query/fragment. |
| `certificate`, `private_key`, `workload_ca` | PEM TLS certificate/key and trusted workload CA paths. |
| `schema_path`, `ctd_path`, `policy_path`, `template_path` | Local v0.9 schema, signed CTD, Cedar source, optional deterministic UTF-8 template paths. Empty `template_path` selects `CanonicalTemplate`; its digest must match the CTD. |
| `policy_id`, `policy_epoch` | Policy identifier and positive integer epoch. |
| `oidc_issuer`, `oidc_public_key_base64`, `token_audience` | Exact issuer, pinned 32-byte Ed25519 issuer public key as standard base64, and service access-token audience. |
| `keys` | Array of `{ "key_id": string, "role": string, "owner_id": string, "public_key_base64": string }`. Required roles are `AgentAdapter`, `ResourceRegistry`, and capacity `EvidenceProvider`; evidence keys need their exact provider `owner_id`. |
| `admission_key_id`, `admission_key_file`, `review_key_id`, `review_key_file` | Separate role-specific Ed25519 PKCS8 signing-key identifiers and PEM paths. The CLI installs their corresponding verification keys. |
| `required_scope`, `capacity_provider` | Delegation scope and expected capacity provider identity. |
| `capacity_question`, `capacity_result_schema` | Published `{ "id", "schema", "digest" }` record references. Their digests bind the provider contract. |
| `review_provider`, `review_policy` | HITL provider identity and published review/authenticator-policy record reference. |
| `rp_id`, `origin` | WebAuthn RP ID and exact HTTPS browser origin, without trailing path. |
| `allowed_reviewers` | Array of `{ "iss", "sub" }` subject identities authorized for this profile. A reviewer may differ from the proposal's delegated subject. |
| `hardware_bound_required`, `attestation_required` | Booleans selecting the external enrollment assurance requirements. |
| `enrollments` | Trusted array of `{ "credential_id", "subject", "public_key_pem", "enrollment_ref", "approved", "hardware_verified", "attestation_verified", "test_only" }`. Credential IDs are unpadded base64url; public keys are PKIX Ed25519 or P-256 PEM. |

The supported deployment must protect configuration and signing keys, use separate role keys, register the actual browser RP/origin, and supply its authentic subject/workload and credential-enrollment services. The historical October schema examples are verification fixtures, not current credentials or live admission requests.
