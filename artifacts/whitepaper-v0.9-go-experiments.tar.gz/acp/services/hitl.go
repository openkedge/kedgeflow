package services

import (
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"html"
	"net/http"
	"net/url"
	"strings"
	"sync"
	"time"

	kf "kedgeflow.local/prototype"
)

const CanonicalTemplate = "KedgeFlow canonical review v1\nAction: {{action}}\nResources: {{resources}}\nParameters: {{parameters}}\nPolicy epoch: {{policy_epoch}}\nProposal digest: {{proposal_digest}}\n"

// Enrollment is an administrator-controlled result of an external credential
// registrar. HTTP callers cannot submit public keys, attestation status or these
// flags. TestOnly enrollment can never satisfy the hardware assurance profile.
// Registration/attestation-chain validation is outside this reference slice.
type Enrollment struct {
	ID                  string     `json:"credential_id"`
	Subject             kf.Subject `json:"subject"`
	PublicKeyPEM        string     `json:"public_key_pem"`
	Ref                 Ref        `json:"enrollment_ref"`
	Approved            bool       `json:"approved"`
	HardwareVerified    bool       `json:"hardware_verified"`
	AttestationVerified bool       `json:"attestation_verified"`
	TestOnly            bool       `json:"test_only"`
	publicKey           any
	signCount           uint32
}
type ReviewConfig struct {
	Validator           *Validator
	Keys                map[string]TrustKey
	Signer              Signer
	Auth                kf.Authenticator
	ProviderID          string
	PolicyEpoch         uint64
	PolicyRef           Ref
	Template            string
	RPID                string
	Origin              string
	AllowedReviewers    []kf.Subject
	Enrollments         []Enrollment
	HardwareRequired    bool
	AttestationRequired bool
	ChallengeTTL        time.Duration
	Now                 func() time.Time
}
type reviewSession struct {
	Approval       Approval
	Proposal       Proposal
	ProposalDigest string
	Rendered       string
	Used           bool
}
type ReviewService struct {
	cfg         ReviewConfig
	mu          sync.Mutex
	sessions    map[string]*reviewSession
	enrollments map[string]*Enrollment
}
type ChallengeRequest struct {
	Proposal json.RawMessage `json:"proposal"`
	Verdict  string          `json:"verdict"`
}
type ChallengeResponse struct {
	ReviewID  string         `json:"review_id"`
	Approval  Approval       `json:"approval"`
	Rendered  string         `json:"rendered"`
	PublicKey map[string]any `json:"public_key"`
}

// Assertion fields are the byte values returned by a real WebAuthn get()
// response, represented as unpadded base64url. This service supports EdDSA and
// ES256 assertion signatures and intentionally rejects authenticator extensions.
type Assertion struct {
	ID                string  `json:"id"`
	Type              string  `json:"type"`
	AuthenticatorData string  `json:"authenticatorData"`
	ClientDataJSON    string  `json:"clientDataJSON"`
	Signature         string  `json:"signature"`
	UserHandle        *string `json:"userHandle"`
}
type VerifyRequest struct {
	ReviewID  string    `json:"review_id"`
	Assertion Assertion `json:"assertion"`
}

func NewReviewService(c ReviewConfig) (*ReviewService, error) {
	if c.Now == nil {
		c.Now = time.Now
	}
	if c.Template == "" {
		c.Template = CanonicalTemplate
	}
	if c.ChallengeTTL <= 0 {
		c.ChallengeTTL = 2 * time.Minute
	}
	u, e := url.Parse(c.Origin)
	if e != nil || u.Scheme != "https" || u.User != nil || u.RawQuery != "" || u.Fragment != "" || u.Path != "" || c.RPID == "" || !(u.Hostname() == c.RPID || strings.HasSuffix(u.Hostname(), "."+c.RPID)) {
		return nil, errors.New("invalid review origin/RP ID")
	}
	if c.PolicyEpoch == 0 || c.ProviderID == "" || len(c.AllowedReviewers) == 0 {
		return nil, errors.New("incomplete review configuration")
	}
	for _, field := range []string{"action", "resources", "parameters", "policy_epoch", "proposal_digest"} {
		if strings.Count(c.Template, "{{"+field+"}}") != 1 {
			return nil, fmt.Errorf("template requires exactly one %s field", field)
		}
	}
	s := &ReviewService{cfg: c, sessions: map[string]*reviewSession{}, enrollments: map[string]*Enrollment{}}
	for _, en := range c.Enrollments {
		if _, ok := s.enrollments[en.ID]; ok {
			return nil, errors.New("duplicate enrollment")
		}
		if _, e = base64.RawURLEncoding.DecodeString(en.ID); e != nil {
			return nil, e
		}
		block, _ := pem.Decode([]byte(en.PublicKeyPEM))
		if block == nil {
			return nil, errors.New("enrollment requires PKIX public key PEM")
		}
		pk, e := x509.ParsePKIXPublicKey(block.Bytes)
		if e != nil {
			return nil, e
		}
		switch k := pk.(type) {
		case ed25519.PublicKey:
			if len(k) != 32 {
				return nil, errors.New("invalid Ed25519 credential")
			}
		case *ecdsa.PublicKey:
			if k.Curve != elliptic.P256() {
				return nil, errors.New("only ES256/P256 supported")
			}
		default:
			return nil, errors.New("unsupported credential algorithm")
		}
		en.publicKey = pk
		copied := en
		s.enrollments[en.ID] = &copied
	}
	return s, nil
}
func (s *ReviewService) authorized(subject kf.Subject) bool {
	for _, p := range s.cfg.AllowedReviewers {
		if p == subject {
			return true
		}
	}
	return false
}
func (s *ReviewService) render(q Proposal, qd string, epoch uint64) (string, error) {
	p, e := kf.Canonical(q.Parameters)
	if e != nil {
		return "", e
	}
	r, e := canonical(q.Resources)
	if e != nil {
		return "", e
	}
	// This bounded renderer rejects bidi formatting controls rather than letting
	// attacker-controlled JSON visually reorder labels or identifiers.
	a, e := canonical(q.Action)
	if e != nil {
		return "", e
	}
	for _, v := range string(append(append(p, r...), a...)) {
		if (v >= 0x202a && v <= 0x202e) || (v >= 0x2066 && v <= 0x2069) || v == 0x200e || v == 0x200f {
			return "", errors.New("bidirectional formatting control unsupported")
		}
	}
	return strings.NewReplacer("{{action}}", string(a), "{{resources}}", string(r), "{{parameters}}", string(p), "{{policy_epoch}}", fmt.Sprint(epoch), "{{proposal_digest}}", qd).Replace(s.cfg.Template), nil
}
func (s *ReviewService) Challenge(raw json.RawMessage, reviewer kf.Subject, verdict string) (ChallengeResponse, error) {
	var q Proposal
	qd, e := verify(raw, "proposal", "AgentAdapter", s.cfg.Keys, s.cfg.Validator, &q)
	if e != nil {
		return ChallengeResponse{}, e
	}
	if !s.authorized(reviewer) || (verdict != "approve" && verdict != "reject") {
		return ChallengeResponse{}, errors.New("reviewer or verdict unauthorized")
	}
	now := s.cfg.Now().UnixMilli()
	if q.Delegation.ExpiresAt <= now || q.CreatedAt > now+5000 {
		return ChallengeResponse{}, errors.New("expired proposal")
	}
	expiry := now + s.cfg.ChallengeTTL.Milliseconds()
	if q.Delegation.ExpiresAt < expiry {
		expiry = q.Delegation.ExpiresAt
	}
	text, e := s.render(q, qd, s.cfg.PolicyEpoch)
	if e != nil {
		return ChallengeResponse{}, e
	}
	pd, e := kf.Digest("parameters", q.Parameters)
	if e != nil {
		return ChallengeResponse{}, e
	}
	a := Approval{ProposalDigest: qd, PolicyEpoch: s.cfg.PolicyEpoch, Reviewer: reviewer, TemplateDigest: rawHash([]byte(s.cfg.Template)), RenderedDigest: rawHash([]byte(text)), ParametersDigest: pd, ReviewedAt: now, ExpiresAt: expiry, Verdict: verdict, Nonce: randomID(), RPID: s.cfg.RPID}
	b, e := canonical(a)
	if e != nil {
		return ChallengeResponse{}, e
	}
	h := sha256.Sum256(b)
	id := randomID()
	creds := []map[string]string{}
	s.mu.Lock()
	defer s.mu.Unlock()
	for rid, pending := range s.sessions {
		if pending.Used || pending.Approval.ExpiresAt <= now {
			delete(s.sessions, rid)
		}
	}
	if len(s.sessions) >= 10000 {
		return ChallengeResponse{}, errors.New("review session limit")
	}
	for _, en := range s.enrollments {
		if en.Subject == reviewer && en.Approved {
			creds = append(creds, map[string]string{"type": "public-key", "id": en.ID})
		}
	}
	if len(creds) == 0 {
		return ChallengeResponse{}, errors.New("no approved enrolled credential")
	}
	s.sessions[id] = &reviewSession{Approval: a, Proposal: q, ProposalDigest: qd, Rendered: text}
	return ChallengeResponse{id, a, text, map[string]any{"challenge": base64.RawURLEncoding.EncodeToString(h[:]), "rpId": s.cfg.RPID, "allowCredentials": creds, "userVerification": "required", "timeout": expiry - now}}, nil
}
func (s *ReviewService) Verify(req VerifyRequest, reviewer kf.Subject) (json.RawMessage, error) {
	s.mu.Lock()
	defer s.mu.Unlock()
	pending, ok := s.sessions[req.ReviewID]
	now := s.cfg.Now().UnixMilli()
	if !ok || pending.Used || pending.Approval.ExpiresAt <= now || pending.Approval.Reviewer != reviewer || !s.authorized(reviewer) {
		return nil, errors.New("review absent, expired, consumed or bound to another reviewer")
	}
	a := req.Assertion
	en, ok := s.enrollments[a.ID]
	if !ok || !en.Approved || en.Subject != reviewer || a.Type != "public-key" {
		return nil, errors.New("credential not enrolled for reviewer")
	}
	if (s.cfg.HardwareRequired && (!en.HardwareVerified || en.TestOnly)) || (s.cfg.AttestationRequired && (!en.AttestationVerified || en.TestOnly)) {
		return nil, errors.New("credential does not meet hardware/attestation policy")
	}
	client, e := base64.RawURLEncoding.DecodeString(a.ClientDataJSON)
	if e != nil {
		return nil, e
	}
	if _, e = kf.Canonical(client); e != nil {
		return nil, e
	}
	var cd struct {
		Type        string `json:"type"`
		Challenge   string `json:"challenge"`
		Origin      string `json:"origin"`
		CrossOrigin bool   `json:"crossOrigin"`
		TopOrigin   string `json:"topOrigin"`
	}
	// Browsers may add tokenBinding; its interpretation is not supported by
	// this bounded profile, and unexpected security fields cannot be ignored.
	d := json.NewDecoder(strings.NewReader(string(client)))
	d.DisallowUnknownFields()
	if d.Decode(&cd) != nil {
		return nil, errors.New("unsupported clientDataJSON")
	}
	ap, _ := canonical(pending.Approval)
	h := sha256.Sum256(ap)
	expected := base64.RawURLEncoding.EncodeToString(h[:])
	if cd.Type != "webauthn.get" || cd.Challenge != expected || cd.Origin != s.cfg.Origin || cd.CrossOrigin || cd.TopOrigin != "" {
		return nil, errors.New("challenge/origin/type mismatch")
	}
	ad, e := base64.RawURLEncoding.DecodeString(a.AuthenticatorData)
	if e != nil || len(ad) != 37 {
		return nil, errors.New("unsupported authenticatorData")
	}
	rp := sha256.Sum256([]byte(s.cfg.RPID))
	if !equalBytes(ad[:32], rp[:]) {
		return nil, errors.New("RP ID mismatch")
	}
	flags := ad[32]
	if flags&0x01 == 0 || flags&0x04 == 0 || flags&0xc0 != 0 || flags&0x22 != 0 {
		return nil, errors.New("user presence/verification or authenticator flags invalid")
	}
	if flags&0x10 != 0 && flags&0x08 == 0 {
		return nil, errors.New("invalid backup-state flags")
	}
	if s.cfg.HardwareRequired && flags&0x08 != 0 {
		return nil, errors.New("backup-eligible credential cannot meet device-bound policy")
	}
	count := binary.BigEndian.Uint32(ad[33:])
	if (count != 0 || en.signCount != 0) && count <= en.signCount {
		return nil, errors.New("credential signature counter did not advance")
	}
	sig, e := base64.RawURLEncoding.DecodeString(a.Signature)
	if e != nil {
		return nil, e
	}
	clientHash := sha256.Sum256(client)
	input := append(append([]byte{}, ad...), clientHash[:]...)
	valid := false
	switch pk := en.publicKey.(type) {
	case ed25519.PublicKey:
		valid = ed25519.Verify(pk, input, sig)
	case *ecdsa.PublicKey:
		hashed := sha256.Sum256(input)
		valid = ecdsa.VerifyASN1(pk, hashed[:], sig)
	}
	if !valid {
		return nil, errors.New("invalid authenticator assertion signature")
	}
	// userHandle is optional on credential-allow-list flows; if provided it must
	// be the configured stable issuer+subject identity encoded as UTF-8 bytes.
	if a.UserHandle != nil {
		u, e := base64.RawURLEncoding.DecodeString(*a.UserHandle)
		if e != nil || string(u) != reviewer.Iss+"|"+reviewer.Sub {
			return nil, errors.New("userHandle mismatch")
		}
	}
	assertionRaw, _ := canonical(a)
	assertionDigest := rawHash(assertionRaw)
	wid := "hitl:" + req.ReviewID
	witness := HitlWitness{WID: wid, Subject: reviewer, Approval: pending.Approval, ChallengeDigest: rawHash(ap), RPID: s.cfg.RPID, Origin: s.cfg.Origin, CredentialID: a.ID, UserPresent: true, UserVerified: true, AuthenticatorPolicy: AuthenticatorPolicy{PolicyRef: s.cfg.PolicyRef, EnrollmentRef: en.Ref, HardwareRequired: s.cfg.HardwareRequired, AttestationRequired: s.cfg.AttestationRequired, Approved: true}, AssertionRef: Ref{ID: wid + ":assertion", Schema: "urn:kedgeflow:webauthn-assertion:1.0", Digest: assertionDigest}, AssertionDigest: assertionDigest, SignCount: count, VerificationResult: "verified", VerifiedAt: now, ExpiresAt: pending.Approval.ExpiresAt, ProviderID: s.cfg.ProviderID}
	raw, e := s.cfg.Signer.Sign("hitl_witness", witness)
	if e != nil {
		return nil, e
	}
	if e = s.cfg.Validator.Validate(raw); e != nil {
		return nil, e
	}
	en.signCount = count
	pending.Used = true
	return raw, nil
}
func equalBytes(a, b []byte) bool {
	if len(a) != len(b) {
		return false
	}
	x := byte(0)
	for i := range a {
		x |= a[i] ^ b[i]
	}
	return x == 0
}
func (s *ReviewService) CheckWitness(w HitlWitness, q Proposal, qd, pd string, epoch uint64) error {
	if w.ProviderID != s.cfg.ProviderID || w.Approval.ProposalDigest != qd || w.Approval.ParametersDigest != pd || w.Approval.PolicyEpoch != epoch || w.Subject != w.Approval.Reviewer || !s.authorized(w.Subject) || w.RPID != s.cfg.RPID || w.Origin != s.cfg.Origin || !w.UserPresent || !w.UserVerified || w.VerificationResult != "verified" || w.ExpiresAt != w.Approval.ExpiresAt || w.VerifiedAt < w.Approval.ReviewedAt || w.VerifiedAt > s.cfg.Now().UnixMilli() {
		return errors.New("HITL witness binding mismatch")
	}
	text, e := s.render(q, qd, epoch)
	if e != nil {
		return e
	}
	ap, _ := canonical(w.Approval)
	if w.Approval.TemplateDigest != rawHash([]byte(s.cfg.Template)) || w.Approval.RenderedDigest != rawHash([]byte(text)) || w.ChallengeDigest != rawHash(ap) || w.AuthenticatorPolicy.PolicyRef != s.cfg.PolicyRef || w.AuthenticatorPolicy.HardwareRequired != s.cfg.HardwareRequired || w.AuthenticatorPolicy.AttestationRequired != s.cfg.AttestationRequired || !w.AuthenticatorPolicy.Approved {
		return errors.New("HITL rendering or enrollment policy mismatch")
	}
	s.mu.Lock()
	defer s.mu.Unlock()
	en, ok := s.enrollments[w.CredentialID]
	if !ok || en.Subject != w.Subject || en.Ref != w.AuthenticatorPolicy.EnrollmentRef || !en.Approved || (s.cfg.HardwareRequired && (!en.HardwareVerified || en.TestOnly)) || (s.cfg.AttestationRequired && (!en.AttestationVerified || en.TestOnly)) {
		return errors.New("HITL credential enrollment mismatch")
	}
	return nil
}
func (s *ReviewService) ChallengeHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		reject(w, 405, "METHOD_NOT_ALLOWED")
		return
	}
	id, e := checkedIdentity(s.cfg.Auth, r)
	if e != nil {
		reject(w, 401, "REVIEWER_AUTHENTICATION_REQUIRED")
		return
	}
	var req ChallengeRequest
	if decodeBody(w, r, &req) != nil {
		reject(w, 400, "INVALID_REQUEST")
		return
	}
	resp, e := s.Challenge(req.Proposal, id.Subject, req.Verdict)
	if e != nil {
		reject(w, 403, "REVIEW_CHALLENGE_REJECTED")
		return
	}
	send(w, 200, resp)
}
func (s *ReviewService) VerifyHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		reject(w, 405, "METHOD_NOT_ALLOWED")
		return
	}
	id, e := checkedIdentity(s.cfg.Auth, r)
	if e != nil {
		reject(w, 401, "REVIEWER_AUTHENTICATION_REQUIRED")
		return
	}
	var req VerifyRequest
	if decodeBody(w, r, &req) != nil {
		reject(w, 400, "INVALID_REQUEST")
		return
	}
	resp, e := s.Verify(req, id.Subject)
	if e != nil {
		reject(w, 403, "WEBAUTHN_ASSERTION_REJECTED")
		return
	}
	send(w, 200, map[string]any{"witness": resp})
}
func (s *ReviewService) RenderHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != "GET" {
		reject(w, 405, "METHOD_NOT_ALLOWED")
		return
	}
	id, e := checkedIdentity(s.cfg.Auth, r)
	if e != nil {
		reject(w, 401, "REVIEWER_AUTHENTICATION_REQUIRED")
		return
	}
	reviewID := r.PathValue("id")
	s.mu.Lock()
	pending, ok := s.sessions[reviewID]
	if !ok || pending.Used || pending.Approval.Reviewer != id.Subject || pending.Approval.ExpiresAt <= s.cfg.Now().UnixMilli() {
		s.mu.Unlock()
		reject(w, 404, "REVIEW_UNAVAILABLE")
		return
	}
	rendered := pending.Rendered
	s.mu.Unlock()
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'; base-uri 'none'")
	_, _ = fmt.Fprintf(w, "<!doctype html><html lang=\"en\"><meta charset=\"utf-8\"><title>KedgeFlow canonical review</title><h1>Review the exact proposed action</h1><pre>%s</pre></html>", html.EscapeString(rendered))
}
