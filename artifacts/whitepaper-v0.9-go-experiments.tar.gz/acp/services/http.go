package services

import "net/http"

func NewMux(admission *AdmissionController, review *ReviewService) *http.ServeMux {
	mux := http.NewServeMux()
	mux.Handle("POST /admission/admit", admission)
	mux.HandleFunc("POST /hitl/challenge", review.ChallengeHandler)
	mux.HandleFunc("POST /hitl/verify", review.VerifyHandler)
	mux.HandleFunc("GET /hitl/review/{id}", review.RenderHandler)
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, r *http.Request) {
		send(w, 200, map[string]string{"status": "ready", "profile": "KF-CAPACITY-ADMISSION-0.1"})
	})
	return mux
}
