package services

import (
	"bytes"
	"crypto/ecdsa"
	"crypto/ed25519"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/sha256"
	"crypto/x509"
	"encoding/base64"
	"encoding/binary"
	"encoding/json"
	"encoding/pem"
	"net/http"
	"net/http/httptest"
	"os"
	"sync"
	"testing"
	"time"

	kf "kedgeflow.local/prototype"
)

type harness struct {
	review            *ReviewService
	admission         *AdmissionController
	q                 json.RawMessage
	payload           map[string]any
	identity          kf.Identity
	adapter, capacity Signer
	credential        ed25519.PrivateKey
	credentialID      string
	now               time.Time
}

func mustSign(t *testing.T, s Signer, kind string, payload any) json.RawMessage {
	t.Helper()
	b, e := s.Sign(kind, payload)
	if e != nil {
		t.Fatal(e)
	}
	return b
}
func newHarness(t *testing.T, source string, hardware bool) *harness {
	t.Helper()
	v, e := LoadValidator("../spec/kedgeflow.schema.json")
	if e != nil {
		t.Fatal(e)
	}
	now := time.Unix(1800000000, 0)
	keys := map[string]TrustKey{}
	makeSigner := func(id, role, owner string) Signer {
		pub, priv, e := ed25519.GenerateKey(rand.Reader)
		if e != nil {
			t.Fatal(e)
		}
		keys[id] = TrustKey{role, owner, pub}
		return Signer{id, priv}
	}
	adapter := makeSigner("test-adapter", "AgentAdapter", "")
	registry := makeSigner("test-registry", "ResourceRegistry", "")
	capacity := makeSigner("test-capacity", "EvidenceProvider", "test-capacity")
	hitl := makeSigner("test-hitl", "EvidenceProvider", "test-hitl")
	admissionSigner := makeSigner("test-admission", "AdmissionController", "")
	loadPayload := func(path string) map[string]any {
		b, e := os.ReadFile(path)
		if e != nil {
			t.Fatal(e)
		}
		var env struct {
			Payload map[string]any `json:"payload"`
		}
		if json.Unmarshal(b, &env) != nil {
			t.Fatal("fixture JSON")
		}
		return env.Payload
	}
	ctd := loadPayload("../spec/examples/ctd.json")
	ctd["rendering"].(map[string]any)["template_digest"] = rawHash([]byte(CanonicalTemplate))
	ctdRaw := mustSign(t, registry, "ctd", ctd)
	ctdDigest, _ := kf.Digest("ctd", ctdRaw)
	q := loadPayload("../spec/examples/proposal.json")
	q["action"].(map[string]any)["digest"] = ctdDigest
	q["workflow"] = nil
	q["created_at"] = now.UnixMilli()
	delegation := q["delegation"].(map[string]any)
	delegation["expires_at"] = now.Add(time.Minute).UnixMilli()
	baseline := q["baseline_state"].([]any)[0].(map[string]any)
	baseline["observed_at"] = now.UnixMilli()
	baseline["expires_at"] = now.Add(time.Minute).UnixMilli()
	var proposal Proposal
	qb := mustSign(t, adapter, "proposal", q)
	if _, e = verify(qb, "proposal", "AgentAdapter", keys, v, &proposal); e != nil {
		t.Fatal(e)
	}
	dd, _ := digest("delegation", proposal.Delegation)
	identity := kf.Identity{Subject: proposal.Subject, WorkloadID: proposal.WorkloadID, DPoPJKT: proposal.Delegation.DPoPJKT, DelegationDigest: dd, Scopes: map[string]bool{"capacity.reserve": true}}
	credentialPub, credentialPriv, e := ed25519.GenerateKey(rand.Reader)
	if e != nil {
		t.Fatal(e)
	}
	publicDER, _ := x509.MarshalPKIXPublicKey(credentialPub)
	publicPEM := string(pem.EncodeToMemory(&pem.Block{Type: "PUBLIC KEY", Bytes: publicDER}))
	credentialID := base64.RawURLEncoding.EncodeToString([]byte("software-test-authenticator"))
	digestRef := func(id string) Ref { return Ref{id, "urn:kedgeflow:test:record:1.0", rawHash([]byte(id))} }
	auth := kf.AuthFunc(func(_ *http.Request) (kf.Identity, error) { return identity, nil })
	r, e := NewReviewService(ReviewConfig{Validator: v, Keys: keys, Signer: hitl, Auth: auth, ProviderID: "test-hitl", PolicyEpoch: 17, PolicyRef: digestRef("test-only-software-review"), Template: CanonicalTemplate, RPID: "review.example.org", Origin: "https://review.example.org", AllowedReviewers: []kf.Subject{identity.Subject}, HardwareRequired: hardware, AttestationRequired: hardware, Enrollments: []Enrollment{{ID: credentialID, Subject: identity.Subject, PublicKeyPEM: publicPEM, Ref: digestRef("test-only-credential-enrollment"), Approved: true, TestOnly: true}}, Now: func() time.Time { return now }})
	if e != nil {
		t.Fatal(e)
	}
	a, e := NewAdmissionController(AdmissionConfig{Validator: v, Keys: keys, Signer: admissionSigner, Auth: auth, CTD: ctdRaw, PolicyID: "capacity-policy", PolicyEpoch: 17, PolicySource: []byte(source), RequiredScope: "capacity.reserve", CapacityProvider: "test-capacity", CapacityQuestion: digestRef("capacity-question"), CapacityResultSchema: digestRef("capacity-result-schema"), Review: r, Now: func() time.Time { return now }})
	if e != nil {
		t.Fatal(e)
	}
	return &harness{r, a, qb, q, identity, adapter, capacity, credentialPriv, credentialID, now}
}
func (h *harness) assertion(t *testing.T, c ChallengeResponse, flags byte, count uint32) Assertion {
	t.Helper()
	client, _ := json.Marshal(map[string]any{"type": "webauthn.get", "challenge": c.PublicKey["challenge"], "origin": h.review.cfg.Origin, "crossOrigin": false})
	rp := sha256.Sum256([]byte(h.review.cfg.RPID))
	ad := append(append([]byte{}, rp[:]...), flags)
	ad = binary.BigEndian.AppendUint32(ad, count)
	ch := sha256.Sum256(client)
	input := append(append([]byte{}, ad...), ch[:]...)
	return Assertion{ID: h.credentialID, Type: "public-key", AuthenticatorData: base64.RawURLEncoding.EncodeToString(ad), ClientDataJSON: base64.RawURLEncoding.EncodeToString(client), Signature: base64.RawURLEncoding.EncodeToString(ed25519.Sign(h.credential, input))}
}
func (h *harness) witness(t *testing.T) json.RawMessage {
	t.Helper()
	c, e := h.review.Challenge(h.q, h.identity.Subject, "approve")
	if e != nil {
		t.Fatal(e)
	}
	w, e := h.review.Verify(VerifyRequest{c.ReviewID, h.assertion(t, c, 0x05, 1)}, h.identity.Subject)
	if e != nil {
		t.Fatal(e)
	}
	return w
}
func (h *harness) capacityWitness(t *testing.T, known bool, slots int, offset time.Duration) json.RawMessage {
	t.Helper()
	var q Proposal
	qd, e := verify(h.q, "proposal", "AgentAdapter", h.admission.cfg.Keys, h.admission.cfg.Validator, &q)
	if e != nil {
		t.Fatal(e)
	}
	p := map[string]any{"wid": "test-capacity-observation", "provider_id": "test-capacity", "provider_version": "1.0", "question_ref": h.admission.cfg.CapacityQuestion, "proposal_digest": qd, "state_scope": q.Resources, "state_digest": q.BaselineState[0].StateDigest, "result_schema": h.admission.cfg.CapacityResultSchema, "result": CapacityObservation{known, int64(slots), q.BaselineState[0].Version}, "observed_at": h.now.Add(offset).UnixMilli(), "expires_at": h.now.Add(time.Minute).UnixMilli(), "provenance_refs": []any{}, "exposure_domains": []string{"test-capacity-source"}}
	return mustSign(t, h.capacity, "evidence", p)
}
func TestAdmissionTernaryAndCedar(t *testing.T) {
	for _, tt := range []struct {
		name           string
		known          bool
		slots          int
		missing        bool
		offset         time.Duration
		decision, code string
	}{{"missing", false, 0, true, 0, "defer", "NEEDS_EVIDENCE"}, {"unknown", false, 4, false, 0, "defer", "NEEDS_EVIDENCE"}, {"violated", true, 0, false, 0, "deny", "OBLIGATION_VIOLATED"}, {"stale", true, 4, false, -time.Minute, "defer", "NEEDS_EVIDENCE"}, {"future", true, 4, false, time.Minute, "defer", "NEEDS_EVIDENCE"}, {"satisfied", true, 4, false, 0, "admit", "ADMITTED"}} {
		t.Run(tt.name, func(t *testing.T) {
			h := newHarness(t, `permit(principal, action, resource) when { context.identity && context.scope == "capacity.reserve" };`, false)
			ev := map[string]json.RawMessage{"review": h.witness(t)}
			if !tt.missing {
				ev["capacity"] = h.capacityWitness(t, tt.known, tt.slots, tt.offset)
			}
			resp, e := h.admission.Admit(AdmissionRequest{h.q, ev}, h.identity)
			if e != nil {
				t.Fatal(e)
			}
			if resp.Decision != tt.decision || resp.Code != tt.code {
				t.Fatalf("got %s %s", resp.Decision, resp.Code)
			}
			if resp.Decision == "admit" {
				if e = h.admission.cfg.Validator.Validate(resp.Certificate); e != nil {
					t.Fatal(e)
				}
			} else if len(resp.Certificate) != 0 {
				t.Fatal("non-admission minted certificate")
			}
		})
	}
	for _, policy := range []struct{ source, code string }{{`forbid(principal, action, resource);`, "POLICY_DENIED"}, {`permit(principal, action, resource); forbid(principal, action, resource) when { context.missing };`, "POLICY_EVALUATION_ERROR"}} {
		h := newHarness(t, policy.source, false)
		resp, e := h.admission.Admit(AdmissionRequest{h.q, map[string]json.RawMessage{"review": h.witness(t), "capacity": h.capacityWitness(t, true, 4, 0)}}, h.identity)
		if e != nil {
			t.Fatal(e)
		}
		if resp.Decision != "deny" || resp.Code != policy.code || len(resp.Certificate) != 0 {
			t.Fatalf("unsafe Cedar result %+v", resp)
		}
	}
}
func TestWebAuthnRejectsSubstitutionReplayAndWeakCredentials(t *testing.T) {
	for _, name := range []string{"challenge-substitution", "origin-substitution", "rp-substitution", "non-uv", "unknown-credential", "invalid-signature", "hardware-unenrolled", "proposal-substitution", "template-substitution", "policy-substitution"} {
		t.Run(name, func(t *testing.T) {
			h := newHarness(t, `permit(principal, action, resource);`, name == "hardware-unenrolled")
			c, e := h.review.Challenge(h.q, h.identity.Subject, "approve")
			if e != nil {
				t.Fatal(e)
			}
			a := h.assertion(t, c, 5, 1)
			switch name {
			case "challenge-substitution":
				c.PublicKey["challenge"] = "forged"
				a = h.assertion(t, c, 5, 1)
			case "origin-substitution":
				h.review.cfg.Origin = "https://evil.example.org"
			case "rp-substitution":
				h.review.cfg.RPID = "evil.example.org"
			case "non-uv":
				a = h.assertion(t, c, 1, 1)
			case "unknown-credential":
				a.ID = base64.RawURLEncoding.EncodeToString([]byte("unenrolled"))
			case "invalid-signature":
				a.Signature = base64.RawURLEncoding.EncodeToString(make([]byte, 64))
			case "proposal-substitution":
				h.review.sessions[c.ReviewID].Approval.ProposalDigest = rawHash([]byte("substituted proposal"))
			case "template-substitution":
				h.review.sessions[c.ReviewID].Approval.TemplateDigest = rawHash([]byte("substituted template"))
			case "policy-substitution":
				h.review.sessions[c.ReviewID].Approval.PolicyEpoch++
			}
			if _, e = h.review.Verify(VerifyRequest{c.ReviewID, a}, h.identity.Subject); e == nil {
				t.Fatal("accepted invalid WebAuthn witness")
			}
		})
	}
	h := newHarness(t, `permit(principal, action, resource);`, false)
	c, _ := h.review.Challenge(h.q, h.identity.Subject, "approve")
	req := VerifyRequest{c.ReviewID, h.assertion(t, c, 5, 1)}
	var wg sync.WaitGroup
	results := make(chan error, 8)
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); _, e := h.review.Verify(req, h.identity.Subject); results <- e }()
	}
	wg.Wait()
	close(results)
	success := 0
	for e := range results {
		if e == nil {
			success++
		}
	}
	if success != 1 {
		t.Fatalf("replay race accepted %d assertions", success)
	}
}
func TestRealES256Assertion(t *testing.T) {
	h := newHarness(t, `permit(principal, action, resource);`, false)
	priv, e := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if e != nil {
		t.Fatal(e)
	}
	h.review.enrollments[h.credentialID].publicKey = &priv.PublicKey
	c, _ := h.review.Challenge(h.q, h.identity.Subject, "approve")
	a := h.assertion(t, c, 5, 1)
	ad, _ := base64.RawURLEncoding.DecodeString(a.AuthenticatorData)
	cd, _ := base64.RawURLEncoding.DecodeString(a.ClientDataJSON)
	ch := sha256.Sum256(cd)
	input := append(ad, ch[:]...)
	messageHash := sha256.Sum256(input)
	sig, e := ecdsa.SignASN1(rand.Reader, priv, messageHash[:])
	if e != nil {
		t.Fatal(e)
	}
	a.Signature = base64.RawURLEncoding.EncodeToString(sig)
	if _, e = h.review.Verify(VerifyRequest{c.ReviewID, a}, h.identity.Subject); e != nil {
		t.Fatal(e)
	}
}
func TestAdmissionRejectsMutatedProposalAndProviderImpersonation(t *testing.T) {
	h := newHarness(t, `permit(principal, action, resource);`, false)
	w := h.witness(t)
	capacity := h.capacityWitness(t, true, 4, 0)
	h.payload["parameters"].(map[string]any)["order_id"] = "poisoned-after-review"
	changed := mustSign(t, h.adapter, "proposal", h.payload)
	if _, e := h.admission.Admit(AdmissionRequest{changed, map[string]json.RawMessage{"review": w, "capacity": capacity}}, h.identity); e == nil {
		t.Fatal("accepted post-review parameter substitution")
	}
	var ev kf.Envelope
	_ = json.Unmarshal(capacity, &ev)
	var payload map[string]any
	_ = json.Unmarshal(ev.Payload, &payload)
	payload["provider_id"] = "test-hitl"
	impersonated := mustSign(t, h.capacity, "evidence", payload)
	if _, e := h.admission.Admit(AdmissionRequest{h.q, map[string]json.RawMessage{"capacity": impersonated}}, h.identity); e == nil {
		t.Fatal("provider key impersonation accepted")
	}
	h.payload["resources"].([]any)[0].(map[string]any)["id"] = "unregistered-resource"
	h.payload["baseline_state"].([]any)[0].(map[string]any)["resource"].(map[string]any)["id"] = "unregistered-resource"
	outside := mustSign(t, h.adapter, "proposal", h.payload)
	if _, e := h.admission.Admit(AdmissionRequest{outside, map[string]json.RawMessage{}}, h.identity); e == nil {
		t.Fatal("CTD scope escape accepted")
	}
}
func TestServiceHTTPRoutes(t *testing.T) {
	h := newHarness(t, `permit(principal, action, resource);`, false)
	mux := NewMux(h.admission, h.review)
	server := httptest.NewServer(mux)
	defer server.Close()
	post := func(path string, body any) []byte {
		t.Helper()
		b, _ := json.Marshal(body)
		resp, e := http.Post(server.URL+path, "application/json", bytes.NewReader(b))
		if e != nil {
			t.Fatal(e)
		}
		defer resp.Body.Close()
		var raw json.RawMessage
		if json.NewDecoder(resp.Body).Decode(&raw) != nil {
			t.Fatal("response JSON")
		}
		if resp.StatusCode != 200 {
			t.Fatalf("HTTP %d: %s", resp.StatusCode, raw)
		}
		return raw
	}
	raw := post("/hitl/challenge", ChallengeRequest{h.q, "approve"})
	var c ChallengeResponse
	_ = json.Unmarshal(raw, &c)
	raw = post("/hitl/verify", VerifyRequest{c.ReviewID, h.assertion(t, c, 5, 1)})
	var v struct {
		Witness json.RawMessage `json:"witness"`
	}
	_ = json.Unmarshal(raw, &v)
	raw = post("/admission/admit", AdmissionRequest{h.q, map[string]json.RawMessage{"review": v.Witness, "capacity": h.capacityWitness(t, true, 4, 0)}})
	var decision AdmissionResponse
	_ = json.Unmarshal(raw, &decision)
	if decision.Decision != "admit" {
		t.Fatalf("HTTP service failed: %s", raw)
	}
}
