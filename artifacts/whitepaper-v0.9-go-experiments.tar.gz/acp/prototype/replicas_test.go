package kedgeflow

import (
	"context"
	clientv3 "go.etcd.io/etcd/client/v3"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"
	"time"
)

func TestTwoGatewayReplicaDoubleSpend(t *testing.T) {
	g, raw, v, id, td := fixture(t, "two-replicas")
	l := ledger(t, g, raw, v)
	target := &mockTarget{version: 1}
	up := httptest.NewServer(target)
	defer up.Close()
	broker := &testBroker{}
	client2, e := clientv3.New(clientv3.Config{Endpoints: clusterClient.Endpoints(), DialTimeout: time.Second})
	if e != nil {
		t.Fatal(e)
	}
	defer client2.Close()
	p1 := &Proxy{Verifier: v, Ledger: l, Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: broker, Adapter: &HTTPAdapter{up.Client(), up.URL, "mock-target", "target-read-token"}, Tools: map[string]ToolDescriptor{"node_drain": td}}
	p2 := *p1
	p2.Ledger = Ledger{Client: client2, Prefix: l.Prefix}
	body := requestBody("node_drain", `{"node":"node-a","expected_version":1}`)
	var wg sync.WaitGroup
	outcomes := make([]string, 2)
	for i, p := range []*Proxy{p1, &p2} {
		wg.Add(1)
		go func(i int, p *Proxy) { defer wg.Done(); outcomes[i] = errorMessage(call(p, body, HeaderGrant(raw))) }(i, p)
	}
	wg.Wait()
	success, consumed := 0, 0
	for _, outcome := range outcomes {
		if outcome == "" {
			success++
		}
		if outcome == "NONCE_CONSUMED" {
			consumed++
		}
	}
	target.mu.Lock()
	effects := target.effects
	target.mu.Unlock()
	if success != 1 || consumed != 1 || effects != 1 || broker.calls.Load() != 1 {
		t.Fatal(outcomes, effects, broker.calls.Load())
	}
	r, e := l.Client.Get(context.Background(), l.root(g))
	if e != nil || len(r.Kvs) != 1 {
		t.Fatal(e)
	}
	t.Log("REPLICAS independent etcd clients=2 signed grant redemptions=2 successful_claim_and_effect=1 NONCE_CONSUMED=1 credentials_minted=1")
}
