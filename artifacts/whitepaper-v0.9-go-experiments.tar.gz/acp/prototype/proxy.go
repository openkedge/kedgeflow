package kedgeflow

import (
	"context"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"sort"
	"strconv"
	"time"
)

const ProtocolVersion = "2026-07-28"
const MCPProfile = "KF-MCP-0.1"

type Identity struct {
	Subject                                            Subject
	WorkloadID, DPoPJKT, DelegationDigest, AccessToken string
	Scopes                                             map[string]bool
}
type Authenticator interface {
	Authenticate(*http.Request) (Identity, error)
}
type AuthFunc func(*http.Request) (Identity, error)

func (f AuthFunc) Authenticate(r *http.Request) (Identity, error) { return f(r) }

type ToolDescriptor struct {
	Name              string          `json:"name"`
	ReadOnly          bool            `json:"read_only"`
	RequiredScope     string          `json:"required_scope"`
	Action            Action          `json:"action"`
	Resource          Resource        `json:"resource"`
	ConflictDomain    string          `json:"conflict_domain"`
	AdapterContract   json.RawMessage `json:"adapter_contract"`
	PredicateID       string          `json:"predicate_id"`
	PredicateVersion  string          `json:"predicate_version"`
	VersionParameter  string          `json:"version_parameter"`
	FenceParameter    string          `json:"fence_parameter"`
	AdmissionEndpoint string          `json:"admission_endpoint"`
}
type CallParams struct {
	Name      string                     `json:"name"`
	Arguments json.RawMessage            `json:"arguments"`
	Meta      map[string]json.RawMessage `json:"_meta"`
}
type Request struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Method  string          `json:"method"`
	Params  CallParams      `json:"params"`
}
type VerifiedCall struct {
	Request     Request
	Grant       Grant
	Identity    Identity
	AttemptID   string
	Descriptor  ToolDescriptor
	GrantDigest string
	SignedGrant json.RawMessage
}
type TargetCredential struct {
	Token     string
	ExpiresAt time.Time
	Audience  string
}
type CredentialBroker interface {
	Exchange(context.Context, VerifiedCall) (TargetCredential, error)
}
type ResourceAdapter interface {
	Dispatch(context.Context, VerifiedCall, TargetCredential) (json.RawMessage, string, error)
	Read(context.Context, Request, Identity) (json.RawMessage, error)
}
type Proxy struct {
	Verifier      GrantVerifier
	Ledger        Ledger
	Auth          Authenticator
	Broker        CredentialBroker
	Adapter       ResourceAdapter
	Tools         map[string]ToolDescriptor
	Logger        *slog.Logger
	Timeout       time.Duration
	GrantResolver GrantResolver
}
type rpcError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
	Data    any    `json:"data,omitempty"`
}
type rpcResponse struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Result  json.RawMessage `json:"result,omitempty"`
	Error   *rpcError       `json:"error,omitempty"`
}
type RecordRef struct {
	ID     string `json:"id"`
	Schema string `json:"schema"`
	Digest string `json:"digest"`
}
type Obligation struct {
	ID          string    `json:"obligation_id"`
	Kind        string    `json:"kind"`
	Stage       string    `json:"stage"`
	Providers   []string  `json:"accepted_provider_classes"`
	QuestionRef RecordRef `json:"question_ref"`
	MaxAgeMS    int       `json:"max_age_ms"`
	Instruction string    `json:"instruction"`
}
type RemediationContract struct {
	ID                string       `json:"remediation_id"`
	Code              string       `json:"code"`
	ProposalDigest    *string      `json:"proposal_digest"`
	Action            Action       `json:"action"`
	ParametersDigest  string       `json:"parameters_digest"`
	Obligations       []Obligation `json:"obligations"`
	AdmissionEndpoint string       `json:"admission_endpoint"`
	Profile           string       `json:"profile"`
	GrantCarriage     string       `json:"grant_carriage"`
	ExpiresAt         int64        `json:"expires_at"`
	Retry             bool         `json:"retry_after_admission"`
}

func negotiated(m map[string]json.RawMessage) bool {
	var version string
	if json.Unmarshal(m["io.modelcontextprotocol/protocolVersion"], &version) != nil || version != ProtocolVersion {
		return false
	}
	var caps struct {
		Extensions map[string]json.RawMessage `json:"extensions"`
	}
	if json.Unmarshal(m["io.modelcontextprotocol/clientCapabilities"], &caps) != nil {
		return false
	}
	var k struct {
		Profile string `json:"profile"`
	}
	return json.Unmarshal(caps.Extensions["io.kedgeflow/governed-mcp"], &k) == nil && k.Profile == MCPProfile
}
func response(w http.ResponseWriter, id json.RawMessage, result json.RawMessage, code int, message string, data any) {
	w.Header().Set("Content-Type", "application/json")
	if len(id) == 0 {
		id = json.RawMessage("null")
	}
	r := rpcResponse{JSONRPC: "2.0", ID: id, Result: result}
	if code != 0 {
		r.Error = &rpcError{code, message, data}
		r.Result = nil
	}
	_ = json.NewEncoder(w).Encode(r)
}
func randomID() string {
	b := make([]byte, 18)
	if _, e := rand.Read(b); e != nil {
		panic(e)
	}
	return base64.RawURLEncoding.EncodeToString(b)
}
func (p *Proxy) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	raw, e := io.ReadAll(r.Body)
	if e != nil {
		response(w, nil, nil, -32600, "INVALID_REQUEST", nil)
		return
	}
	var req Request
	if e = strictJSON(raw, &req); e != nil || req.JSONRPC != "2.0" || len(req.ID) == 0 || string(req.ID) == "null" {
		response(w, nil, nil, -32600, "INVALID_REQUEST", nil)
		return
	}
	// Arrays/batches, notifications, streaming and session resumption are outside
	// this profile. Do not pass through operations unknown to enforcement.
	if req.Method != "tools/call" && req.Method != "tools/list" && req.Method != "server/discover" {
		response(w, req.ID, nil, -32601, "METHOD_NOT_SUPPORTED", nil)
		return
	}
	var version string
	if json.Unmarshal(req.Params.Meta["io.modelcontextprotocol/protocolVersion"], &version) != nil || len(req.Params.Meta["io.modelcontextprotocol/clientCapabilities"]) == 0 {
		response(w, req.ID, nil, -32602, "REQUIRED_PROTOCOL_METADATA", nil)
		return
	}
	if version != ProtocolVersion {
		response(w, req.ID, nil, -32022, "UNSUPPORTED_PROTOCOL_VERSION", nil)
		return
	}
	id, e := p.Auth.Authenticate(r)
	if e != nil {
		response(w, req.ID, nil, -32003, "IDENTITY_CONFLICT", nil)
		return
	}
	if req.Method == "server/discover" {
		extensions := map[string]any{"io.kedgeflow/governed-mcp": map[string]any{"profile": MCPProfile, "max_inline_grant_header_bytes": MaxInlineGrantHeader}}
		if p.GrantResolver != nil {
			extensions["io.kedgeflow/grant-reference"] = map[string]any{"profile": GrantReferenceProfile, "header": GrantReferenceHeader, "max_resolved_grant_bytes": MaxResolvedGrantBytes}
		}
		result := map[string]any{"resultType": "complete", "supportedVersions": []string{ProtocolVersion}, "capabilities": map[string]any{"tools": map[string]any{}, "extensions": extensions}, "_meta": map[string]any{"io.modelcontextprotocol/serverInfo": map[string]string{"name": "KedgeFlow prototype", "version": "0.9"}}}
		b, _ := json.Marshal(result)
		response(w, req.ID, b, 0, "", nil)
		return
	}
	if req.Method == "tools/list" {
		names := make([]string, 0)
		for name, tool := range p.Tools {
			if tool.RequiredScope != "" && id.Scopes[tool.RequiredScope] {
				names = append(names, name)
			}
		}
		sort.Strings(names)
		tools := make([]any, 0, len(names))
		for _, name := range names {
			tool := p.Tools[name]
			schema := map[string]any{"type": "object", "properties": map[string]any{}, "additionalProperties": false}
			if !tool.ReadOnly {
				schema["properties"] = map[string]any{"node": map[string]any{"type": "string", "const": tool.Resource.ID}, tool.VersionParameter: map[string]any{"type": "integer", "minimum": 1, "maximum": 9007199254740991}}
				schema["required"] = []string{"node", tool.VersionParameter}
			}
			tools = append(tools, map[string]any{"name": name, "description": "Registered KedgeFlow protected tool", "inputSchema": schema, "annotations": map[string]bool{"readOnlyHint": tool.ReadOnly}})
		}
		b, _ := json.Marshal(map[string]any{"resultType": "complete", "tools": tools, "ttlMs": 0, "cacheScope": "private"})
		response(w, req.ID, b, 0, "", nil)
		return
	}
	d, ok := p.Tools[req.Params.Name]
	if !ok {
		response(w, req.ID, nil, -32004, "UNREGISTERED_TOOL", nil)
		return
	}
	if d.RequiredScope == "" {
		response(w, req.ID, nil, -32004, "UNREGISTERED_AUTHORIZATION", nil)
		return
	}
	if !id.Scopes[d.RequiredScope] {
		response(w, req.ID, nil, -32003, "INSUFFICIENT_SCOPE", nil)
		return
	}
	if !d.ReadOnly && !negotiated(req.Params.Meta) {
		response(w, req.ID, nil, -32002, "KF_EXTENSION_NOT_NEGOTIATED", nil)
		return
	}
	if p.Logger != nil {
		p.Logger.Info("tool_call", "tool", d.Name, "read_only", d.ReadOnly)
	}
	ctx := r.Context()
	timeout := p.Timeout
	if timeout == 0 {
		timeout = 5 * time.Second
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	if d.ReadOnly {
		if len(req.Params.Arguments) == 0 {
			req.Params.Arguments = json.RawMessage("{}")
		}
		var readArgs map[string]json.RawMessage
		if strictJSON(req.Params.Arguments, &readArgs) != nil || readArgs == nil || len(readArgs) != 0 {
			response(w, req.ID, nil, -32602, "INVALID_READ_PARAMS", nil)
			return
		}
		if len(r.Header.Values("Mcp-KedgeFlow-Grant")) != 0 || len(r.Header.Values(GrantReferenceHeader)) != 0 {
			response(w, req.ID, nil, -32005, "UNEXPECTED_GRANT", nil)
			return
		}
		result, e := p.Adapter.Read(ctx, req, id)
		if e != nil {
			response(w, req.ID, nil, -32006, "READ_FAILED", nil)
			return
		}
		response(w, req.ID, result, 0, "", nil)
		return
	}
	argsDigest, e := Digest("parameters", req.Params.Arguments)
	if e != nil {
		response(w, req.ID, nil, -32602, "INVALID_PARAMS", nil)
		return
	}
	h := r.Header.Values("Mcp-KedgeFlow-Grant")
	refs := r.Header.Values(GrantReferenceHeader)
	if len(h) > 1 || len(refs) > 1 || len(h) != 0 && len(refs) != 0 {
		response(w, req.ID, nil, -32005, "GRANT_MISMATCH", nil)
		return
	}
	if len(h) == 0 && len(refs) == 0 {
		rem := RemediationContract{randomID(), "NEEDS_EVIDENCE", nil, d.Action, argsDigest, []Obligation{{"exact-admission", "policy", "static", []string{"AdmissionController"}, RecordRef{d.Action.ID, "https://kedgeflow.dev/spec/v0.9/questions/admission", d.Action.Digest}, 0, "Freeze an exact proposal and obtain admission under the current policy"}, {"state-witness", "state", "jit", []string{"ResourceAdapter"}, RecordRef{d.PredicateID, "https://kedgeflow.dev/spec/v0.9/questions/resource-version", d.Action.Digest}, 1000, "Acquire the required fresh resource-version witness"}}, d.AdmissionEndpoint, Profile, "Mcp-KedgeFlow-Grant", time.Now().Add(time.Minute).UnixMilli(), true}
		response(w, req.ID, nil, -32001, "NEEDS_EVIDENCE", rem)
		return
	}
	var grantRaw []byte
	if len(refs) == 1 {
		if p.GrantResolver == nil || !referenceNegotiated(req.Params.Meta) {
			response(w, req.ID, nil, -32002, "KF_REFERENCE_NOT_NEGOTIATED", nil)
			return
		}
		if !validGrantReference(refs[0]) {
			response(w, req.ID, nil, -32005, "GRANT_MISMATCH", nil)
			return
		}
		grantRaw, e = p.GrantResolver.Resolve(ctx, id, refs[0])
		if e != nil || len(grantRaw) == 0 || len(grantRaw) > MaxResolvedGrantBytes || ctx.Err() != nil {
			response(w, req.ID, nil, -32005, "GRANT_REFERENCE_UNAVAILABLE", nil)
			return
		}
	} else {
		if len(h[0]) > MaxInlineGrantHeader {
			response(w, req.ID, nil, -32005, "GRANT_HEADER_TOO_LARGE", nil)
			return
		}
		grantRaw, e = base64.RawURLEncoding.DecodeString(h[0])
	}
	if e != nil {
		response(w, req.ID, nil, -32005, "GRANT_MISMATCH", nil)
		return
	}
	g, gd, e := p.Verifier.Verify(grantRaw)
	if e != nil || len(refs) == 1 && gd != refs[0] {
		response(w, req.ID, nil, -32005, "GRANT_MISMATCH", nil)
		return
	}
	if e = bindCall(g, id, d, argsDigest, req.Params.Arguments); e != nil {
		response(w, req.ID, nil, -32005, "GRANT_MISMATCH", nil)
		return
	}
	a, e := p.Ledger.Claim(ctx, g, gd, randomID())
	if e != nil {
		if errors.Is(e, ErrNonceConsumed) {
			response(w, req.ID, nil, -32007, "NONCE_CONSUMED", nil)
			return
		}
		response(w, req.ID, nil, -32007, "ROOT_UNAVAILABLE_OR_CONSUMED", nil)
		return
	}
	call := VerifiedCall{req, g, id, a.ID, d, gd, grantRaw}
	// Bound credential work and target I/O to the remaining signed lifetime.
	// Cancellation cannot prove that a request already sent produced no effect.
	ctx, grantCancel := context.WithDeadline(ctx, time.UnixMilli(g.ExpiresAt))
	defer grantCancel()
	credential, e := p.Broker.Exchange(ctx, call)
	if e != nil || credential.Token == "" || !time.Now().Before(credential.ExpiresAt) {
		_ = p.finish(g, a, "not_dispatched")
		response(w, req.ID, nil, -32008, "CREDENTIAL_UNAVAILABLE", map[string]string{"attempt_id": a.ID})
		return
	}
	// A claim is not indefinite dispatch permission. Credential issuance must not
	// consume the remaining validity window; no dispatch follows expiry.
	if _, _, e = p.Verifier.Verify(grantRaw); e != nil {
		_ = p.finish(g, a, "not_dispatched")
		response(w, req.ID, nil, -32005, "GRANT_EXPIRED_AFTER_CLAIM", map[string]string{"attempt_id": a.ID})
		return
	}
	if e = p.Ledger.AuthorizeDispatch(ctx, g, gd, a.ID); e != nil {
		_ = p.finish(g, a, "not_dispatched")
		response(w, req.ID, nil, -32007, "AUTHORITY_CHANGED_BEFORE_DISPATCH", map[string]string{"attempt_id": a.ID})
		return
	}
	// The ledger round trip may also consume the final validity window.
	if _, _, e = p.Verifier.Verify(grantRaw); e != nil || ctx.Err() != nil || !time.Now().Before(credential.ExpiresAt) {
		_ = p.finish(g, a, "not_dispatched")
		response(w, req.ID, nil, -32005, "DISPATCH_VALIDITY_EXPIRED", map[string]string{"attempt_id": a.ID})
		return
	}
	result, status, e := p.Adapter.Dispatch(ctx, call, credential)
	if e != nil || status == "unknown" {
		_ = p.finish(g, a, "unknown")
		response(w, req.ID, nil, -32009, "OUTCOME_UNKNOWN", map[string]string{"attempt_id": a.ID})
		return
	}
	if status != "committed" && status != "state_guard_violation" {
		_ = p.finish(g, a, "unknown")
		response(w, req.ID, nil, -32009, "OUTCOME_UNKNOWN", map[string]string{"attempt_id": a.ID})
		return
	}
	if e = p.finish(g, a, status); e != nil {
		response(w, req.ID, nil, -32009, "OUTCOME_UNKNOWN", map[string]string{"attempt_id": a.ID})
		return
	}
	if status == "state_guard_violation" {
		response(w, req.ID, nil, -32010, "STATE_GUARD_VIOLATION", map[string]string{"attempt_id": a.ID})
		return
	}
	response(w, req.ID, result, 0, "", nil)
}
func bindCall(g Grant, id Identity, d ToolDescriptor, argsDigest string, args json.RawMessage) error {
	if g.Subject != id.Subject || g.WorkloadID != id.WorkloadID || g.DPoPJKT != id.DPoPJKT || g.DelegationDigest != id.DelegationDigest || g.ParametersDigest != argsDigest || g.Action != d.Action || g.Resources[0] != d.Resource || g.ConflictDomain != d.ConflictDomain {
		return errors.New("scope mismatch")
	}
	if !equalCanonical(g.AdapterContract, d.AdapterContract) {
		return errors.New("adapter mismatch")
	}
	var contract struct {
		Level       string          `json:"level"`
		Guard       string          `json:"guard_primitive"`
		Fence       string          `json:"fence_parameter"`
		Scope       []string        `json:"guard_scope"`
		Completion  string          `json:"completion_mode"`
		Commit      string          `json:"commit_point"`
		Idempotency json.RawMessage `json:"idempotency"`
	}
	if strictJSON(g.AdapterContract, &contract) != nil || contract.Level != "Level_A" || contract.Guard != "FencingToken" || contract.Fence != d.FenceParameter || len(contract.Scope) != 1 || contract.Scope[0] != d.Resource.ID || contract.Completion != "dispatch_bound" {
		return errors.New("unsupported adapter contract")
	}
	var fields map[string]json.RawMessage
	if strictJSON(args, &fields) != nil {
		return errors.New("arguments must be object")
	}
	if len(fields) != 2 {
		return errors.New("unsupported parameters")
	}
	var node string
	if json.Unmarshal(fields["node"], &node) != nil || node != d.Resource.ID {
		return errors.New("resource parameter mismatch")
	}
	var version uint64
	if json.Unmarshal(fields[d.VersionParameter], &version) != nil || version == 0 {
		return errors.New("version required")
	}
	predicate := map[string]any{"id": d.PredicateID, "version": d.PredicateVersion, "language": "kf-conjunction-v1", "clauses": []any{map[string]any{"kind": "version_eq", "resource": d.Resource, "expected_version": strconv.FormatUint(version, 10)}}}
	pb, e := marshalCanonical(predicate)
	if e != nil {
		return e
	}
	if !equalCanonical(g.PredicateDescriptor, pb) {
		return fmt.Errorf("unsupported or mismatched predicate")
	}
	return nil
}

func (p *Proxy) finish(g Grant, a Attempt, status string) error {
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	return p.Ledger.Finish(ctx, g, a, status)
}
