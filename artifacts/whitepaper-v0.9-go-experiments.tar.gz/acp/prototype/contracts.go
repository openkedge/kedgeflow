package kedgeflow

// This package is an executable reference slice, not a production gateway.
import (
	"bytes"
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"reflect"
	"time"
	"unicode/utf8"

	jcs "github.com/cyberphone/json-canonicalization/go/src/webpki.org/jsoncanonicalizer"
)

const Profile = "KF-JSON-0.2"
const GrantSchema = "https://kedgeflow.dev/spec/v0.9/kedgeflow.schema.json#/$defs/ExecutionGrant"

type Subject struct {
	Iss string `json:"iss"`
	Sub string `json:"sub"`
}
type Resource struct {
	ID          string `json:"id"`
	Incarnation string `json:"incarnation"`
}
type Action struct {
	ID      string `json:"id"`
	Version string `json:"version"`
	Digest  string `json:"digest"`
}
type Policy struct {
	ID     string `json:"id"`
	Epoch  uint64 `json:"epoch"`
	Digest string `json:"digest"`
}
type Grant struct {
	GID                    string          `json:"gid"`
	ProposalDigest         string          `json:"proposal_digest"`
	CertificateDigest      string          `json:"certificate_digest"`
	DelegationDigest       string          `json:"delegation_digest"`
	Subject                Subject         `json:"subject"`
	WorkloadID             string          `json:"workload_id"`
	DPoPJKT                string          `json:"dpop_jkt"`
	Action                 Action          `json:"action"`
	Resources              []Resource      `json:"resources"`
	ParametersDigest       string          `json:"parameters_digest"`
	Policy                 Policy          `json:"policy"`
	EvidenceManifestDigest string          `json:"evidence_manifest_digest"`
	ConstraintDigest       string          `json:"constraint_digest"`
	OwnershipEpoch         uint64          `json:"ownership_epoch"`
	PredicateDescriptor    json.RawMessage `json:"predicate_descriptor"`
	AdapterContract        json.RawMessage `json:"adapter_contract"`
	RootID                 string          `json:"root_id"`
	RootGeneration         uint64          `json:"root_generation"`
	ParentGrantDigest      *string         `json:"parent_grant_digest"`
	SagaBudget             json.RawMessage `json:"saga_budget"`
	ConflictDomain         string          `json:"conflict_domain"`
	Nonce                  string          `json:"nonce"`
	Fence                  uint64          `json:"fence"`
	Audience               string          `json:"audience"`
	IssuedAt               int64           `json:"issued_at"`
	ValidFrom              int64           `json:"valid_from"`
	ExpiresAt              int64           `json:"expires_at"`
	CompletionMode         string          `json:"completion_mode"`
}
type Envelope struct {
	Profile   string          `json:"profile"`
	Kind      string          `json:"kind"`
	Schema    string          `json:"schema"`
	KeyID     string          `json:"key_id"`
	Payload   json.RawMessage `json:"payload"`
	Signature string          `json:"signature"`
}
type unsignedEnvelope struct {
	Profile string          `json:"profile"`
	Kind    string          `json:"kind"`
	Schema  string          `json:"schema"`
	KeyID   string          `json:"key_id"`
	Payload json.RawMessage `json:"payload"`
}

func Canonical(raw []byte) ([]byte, error) {
	if !utf8.Valid(raw) {
		return nil, errors.New("non-UTF8 JSON")
	}
	// RFC reference implementation restricts the top level to object/array.
	// A singleton array permits canonicalizing any I-JSON value identically.
	b, e := jcs.Transform(append(append([]byte{'['}, raw...), ']'))
	if e != nil {
		return nil, e
	}
	return b[1 : len(b)-1], nil
}
func marshalCanonical(v any) ([]byte, error) {
	b, e := json.Marshal(v)
	if e != nil {
		return nil, e
	}
	return Canonical(b)
}
func Digest(kind string, raw []byte) (string, error) {
	b, e := Canonical(raw)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256(append([]byte("KedgeFlow/"+Profile+"/"+kind+"\x00"), b...))
	return hex.EncodeToString(h[:]), nil
}
func strictJSON(b []byte, v any) error {
	if _, e := Canonical(b); e != nil {
		return e
	}
	d := json.NewDecoder(bytes.NewReader(b))
	d.DisallowUnknownFields()
	if e := d.Decode(v); e != nil {
		return e
	}
	var extra any
	if e := d.Decode(&extra); e != io.EOF {
		return errors.New("trailing JSON")
	}
	return nil
}
func requiredFields(b []byte, v any) error {
	var m map[string]json.RawMessage
	if e := json.Unmarshal(b, &m); e != nil {
		return e
	}
	typ := reflect.TypeOf(v)
	for i := 0; i < typ.NumField(); i++ {
		name := typ.Field(i).Tag.Get("json")
		if _, ok := m[name]; !ok {
			return fmt.Errorf("required field missing: %s", name)
		}
	}
	return nil
}
func signatureInput(e Envelope) ([]byte, error) {
	b, err := marshalCanonical(unsignedEnvelope{e.Profile, e.Kind, e.Schema, e.KeyID, e.Payload})
	if err != nil {
		return nil, err
	}
	return append([]byte("KedgeFlow/"+Profile+"\x00"), b...), nil
}
func SignGrant(g Grant, keyID string, key ed25519.PrivateKey) ([]byte, error) {
	p, err := marshalCanonical(g)
	if err != nil {
		return nil, err
	}
	e := Envelope{Profile, "grant", GrantSchema, keyID, p, ""}
	b, err := signatureInput(e)
	if err != nil {
		return nil, err
	}
	e.Signature = base64.RawURLEncoding.EncodeToString(ed25519.Sign(key, b))
	return marshalCanonical(e)
}

type GrantVerifier struct {
	Keys     map[string]ed25519.PublicKey
	Audience string
	Now      func() time.Time
}

func (v GrantVerifier) Verify(raw []byte) (Grant, string, error) {
	var e Envelope
	var g Grant
	if err := strictJSON(raw, &e); err != nil {
		return g, "", err
	}
	if err := requiredFields(raw, e); err != nil {
		return g, "", err
	}
	if e.Profile != Profile || e.Kind != "grant" || e.Schema != GrantSchema {
		return g, "", errors.New("unsupported envelope")
	}
	k, ok := v.Keys[e.KeyID]
	if !ok {
		return g, "", errors.New("untrusted key")
	}
	b, err := signatureInput(e)
	if err != nil {
		return g, "", err
	}
	sig, err := base64.RawURLEncoding.DecodeString(e.Signature)
	if err != nil || !ed25519.Verify(k, b, sig) {
		return g, "", errors.New("bad signature")
	}
	if err = strictJSON(e.Payload, &g); err != nil {
		return g, "", err
	}
	if err = requiredFields(e.Payload, g); err != nil {
		return g, "", err
	}
	now := time.Now()
	if v.Now != nil {
		now = v.Now()
	}
	start := time.UnixMilli(g.ValidFrom)
	end := time.UnixMilli(g.ExpiresAt)
	issued := time.UnixMilli(g.IssuedAt)
	if g.ValidFrom < 0 || g.ExpiresAt > 9007199254740991 || !end.After(start) || issued.After(start) || now.Before(start) || !now.Before(end) {
		return g, "", errors.New("grant expired or not yet valid")
	}
	if g.Audience != v.Audience || g.GID == "" || g.RootID == "" || g.Nonce == "" || g.ConflictDomain == "" || g.RootGeneration == 0 || g.Fence == 0 || g.OwnershipEpoch == 0 || g.Policy.Epoch == 0 {
		return g, "", errors.New("invalid scope")
	}
	// This slice supports one resource and one action only. It cannot silently
	// execute delegation or a Saga record with incomplete conservation semantics.
	if g.ParentGrantDigest != nil || string(g.SagaBudget) != "null" || len(g.Resources) != 1 || g.CompletionMode != "dispatch_bound" {
		return g, "", errors.New("unsupported execution profile")
	}
	if g.Subject.Iss == "" || g.Subject.Sub == "" || g.WorkloadID == "" || g.DPoPJKT == "" {
		return g, "", errors.New("missing dual identity")
	}
	for _, n := range []uint64{g.RootGeneration, g.Fence, g.OwnershipEpoch, g.Policy.Epoch} {
		if n > 9007199254740991 {
			return g, "", errors.New("unsafe integer")
		}
	}
	for _, d := range []string{g.ProposalDigest, g.CertificateDigest, g.DelegationDigest, g.Action.Digest, g.ParametersDigest, g.Policy.Digest, g.EvidenceManifestDigest, g.ConstraintDigest} {
		if len(d) != 64 {
			return g, "", errors.New("invalid digest")
		}
		if _, err := hex.DecodeString(d); err != nil {
			return g, "", err
		}
	}
	d, err := Digest("grant", raw)
	return g, d, err
}
func HeaderGrant(raw []byte) string { return base64.RawURLEncoding.EncodeToString(raw) }
func equalCanonical(a, b []byte) bool {
	x, e := Canonical(a)
	if e != nil {
		return false
	}
	y, e := Canonical(b)
	return e == nil && bytes.Equal(x, y)
}
func requireEqual(a, b any) error {
	x, e := marshalCanonical(a)
	if e != nil {
		return e
	}
	y, e := marshalCanonical(b)
	if e != nil {
		return e
	}
	if !bytes.Equal(x, y) {
		return fmt.Errorf("binding mismatch")
	}
	return nil
}
