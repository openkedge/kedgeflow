package kedgeflow

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

type referenceResolverFunc func(context.Context, Identity, string) ([]byte, error)

func (f referenceResolverFunc) Resolve(ctx context.Context, id Identity, digest string) ([]byte, error) {
	return f(ctx, id, digest)
}

func referenceMTLSServer(t *testing.T, handler http.Handler) (*httptest.Server, *http.Client) {
	t.Helper()
	serverCert, clientCert, roots := testCertificates(t)
	s := httptest.NewUnstartedServer(handler)
	s.TLS = &tls.Config{Certificates: []tls.Certificate{serverCert}, ClientAuth: tls.RequireAndVerifyClientCert, ClientCAs: roots, MinVersion: tls.VersionTLS13}
	s.StartTLS()
	t.Cleanup(s.Close)
	client, err := NewMTLSHTTPClient(&tls.Config{Certificates: []tls.Certificate{clientCert}, RootCAs: roots})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(client.CloseIdleConnections)
	return s, client
}

func referenceRequestBody(t *testing.T, tool, args, profile string) []byte {
	t.Helper()
	var req Request
	if err := json.Unmarshal(requestBody(tool, args), &req); err != nil {
		t.Fatal(err)
	}
	var caps map[string]any
	if err := json.Unmarshal(req.Params.Meta["io.modelcontextprotocol/clientCapabilities"], &caps); err != nil {
		t.Fatal(err)
	}
	if profile != "" {
		caps["extensions"].(map[string]any)["io.kedgeflow/grant-reference"] = map[string]any{"profile": profile}
	}
	encoded, err := json.Marshal(caps)
	if err != nil {
		t.Fatal(err)
	}
	req.Params.Meta["io.modelcontextprotocol/clientCapabilities"] = encoded
	encoded, err = json.Marshal(req)
	if err != nil {
		t.Fatal(err)
	}
	return encoded
}

func referenceCall(p http.Handler, body []byte, headers http.Header) *httptest.ResponseRecorder {
	r := httptest.NewRequest(http.MethodPost, "https://gateway.test/mcp", bytes.NewReader(body))
	r.Header.Set("Authorization", "DPoP caller-access-secret")
	r.Header.Set("DPoP", "caller-proof-secret")
	r.Header.Set("Cookie", "caller-cookie-secret")
	r.Header.Set("X-Agent-Credential", "caller-credential-secret")
	for name, values := range headers {
		for _, v := range values {
			r.Header.Add(name, v)
		}
	}
	w := httptest.NewRecorder()
	p.ServeHTTP(w, r)
	return w
}

func referenceProxy(t *testing.T, g Grant, raw []byte, verifier GrantVerifier, id Identity, descriptor ToolDescriptor) (*Proxy, *testBroker, *mockTarget) {
	t.Helper()
	target := &mockTarget{version: 1}
	up := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if len(r.Header.Values(GrantReferenceHeader)) != 0 {
			target.mu.Lock()
			target.leaked = true
			target.mu.Unlock()
		}
		target.ServeHTTP(w, r)
	}))
	t.Cleanup(up.Close)
	broker := &testBroker{}
	p := &Proxy{Verifier: verifier, Ledger: ledger(t, g, raw, verifier), Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: broker, Adapter: &HTTPAdapter{up.Client(), up.URL, "mock-target", "target-read-token"}, Tools: map[string]ToolDescriptor{"node_drain": descriptor, "node_read": {Name: "node_read", ReadOnly: true, RequiredScope: "read"}}, Timeout: 5 * time.Second}
	return p, broker, target
}

func referenceAssertUnclaimed(t *testing.T, p *Proxy, g Grant, broker *testBroker, target *mockTarget) {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	nonce, err := p.Ledger.Client.Get(ctx, p.Ledger.nonce(g))
	if err != nil || len(nonce.Kvs) != 0 {
		t.Fatalf("refusal consumed nonce: records=%v err=%v", nonce, err)
	}
	root, err := p.Ledger.Client.Get(ctx, p.Ledger.root(g))
	if err != nil || len(root.Kvs) != 1 {
		t.Fatalf("root lookup: records=%v err=%v", root, err)
	}
	var state Root
	if err := json.Unmarshal(root.Kvs[0].Value, &state); err != nil || state.Status != "unclaimed" {
		t.Fatalf("refusal altered root: state=%+v err=%v", state, err)
	}
	if broker.calls.Load() != 0 {
		t.Fatal("refused reference reached credential broker")
	}
	target.mu.Lock()
	defer target.mu.Unlock()
	if target.effects != 0 || target.reads != 0 {
		t.Fatalf("refused reference reached target: effects=%d reads=%d", target.effects, target.reads)
	}
}

func TestHTTPSGrantResolverConfiguration(t *testing.T) {
	_, clientCert, roots := testCertificates(t)
	secure := func() *http.Client {
		return &http.Client{Timeout: time.Second, Transport: &http.Transport{TLSClientConfig: &tls.Config{Certificates: []tls.Certificate{clientCert}, RootCAs: roots, MinVersion: tls.VersionTLS13}}}
	}
	if _, err := NewHTTPSGrantResolver("https://resolver.test/grants/resolve", secure()); err != nil {
		t.Fatal(err)
	}
	for _, endpoint := range []string{"", "http://resolver.test/grants", "https://user:password@resolver.test/grants", "https://resolver.test/grants?caller=target", "https://resolver.test/grants?", "https://resolver.test/grants#fragment", "https:resolver.test/grants"} {
		t.Run("endpoint/"+endpoint, func(t *testing.T) {
			if _, err := NewHTTPSGrantResolver(endpoint, secure()); err == nil {
				t.Fatal("unsafe resolver endpoint accepted")
			}
		})
	}
	for _, name := range []string{"nil-client", "unbounded", "default-transport", "nil-tls", "insecure", "no-roots", "no-certificate", "tls12"} {
		t.Run("client/"+name, func(t *testing.T) {
			c := secure()
			switch name {
			case "nil-client":
				c = nil
			case "unbounded":
				c.Timeout = 0
			case "default-transport":
				c.Transport = nil
			case "nil-tls":
				c.Transport.(*http.Transport).TLSClientConfig = nil
			case "insecure":
				c.Transport.(*http.Transport).TLSClientConfig.InsecureSkipVerify = true
			case "no-roots":
				c.Transport.(*http.Transport).TLSClientConfig.RootCAs = nil
			case "no-certificate":
				c.Transport.(*http.Transport).TLSClientConfig.Certificates = nil
			case "tls12":
				c.Transport.(*http.Transport).TLSClientConfig.MinVersion = tls.VersionTLS12
			}
			if _, err := NewHTTPSGrantResolver("https://resolver.test/grants/resolve", c); err == nil {
				t.Fatal("unsafe resolver client accepted")
			}
		})
	}
}

func TestHTTPSGrantResolverMTLSAndRequesterScope(t *testing.T) {
	_, raw, verifier, id, _ := fixture(t, "resolver-scope")
	_, digest, err := verifier.Verify(raw)
	if err != nil {
		t.Fatal(err)
	}
	id.AccessToken = "caller-access-secret"
	var calls atomic.Int64
	s, client := referenceMTLSServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		if r.Method != http.MethodPost || r.URL.Path != "/pinned/resolve" || r.URL.RawQuery != "" {
			t.Errorf("lookup escaped pinned method/path: %s %s", r.Method, r.URL)
		}
		if r.TLS == nil || r.TLS.Version != tls.VersionTLS13 || len(r.TLS.VerifiedChains) == 0 {
			t.Error("resolver did not authenticate gateway using TLS 1.3 mTLS")
		}
		for _, name := range []string{"Authorization", "DPoP", "Cookie", "Mcp-KedgeFlow-Grant", GrantReferenceHeader, "X-Agent-Credential"} {
			if len(r.Header.Values(name)) != 0 {
				t.Errorf("caller credential/carriage forwarded in %s", name)
			}
		}
		if r.Header.Get("Content-Type") != "application/json" || r.Header.Get("Accept-Encoding") != "identity" {
			t.Error("lookup content/encoding contract missing")
		}
		body, err := io.ReadAll(r.Body)
		if err != nil {
			t.Error(err)
		}
		var query GrantReferenceQuery
		if err := strictJSON(body, &query); err != nil || query != (GrantReferenceQuery{digest, id.Subject, id.WorkloadID, id.DPoPJKT, id.DelegationDigest}) {
			t.Errorf("lookup requester scope mismatch: %+v err=%v", query, err)
		}
		if bytes.Contains(body, []byte(id.AccessToken)) {
			t.Error("caller access token disclosed in lookup body")
		}
		_, _ = w.Write(raw)
	}))
	resolver, err := NewHTTPSGrantResolver(s.URL+"/pinned/resolve", client)
	if err != nil {
		t.Fatal(err)
	}
	resolved, err := resolver.Resolve(context.Background(), id, digest)
	if err != nil || !bytes.Equal(resolved, raw) || calls.Load() != 1 {
		t.Fatalf("complete original envelope not preserved: equal=%v calls=%d err=%v", bytes.Equal(resolved, raw), calls.Load(), err)
	}
	for _, name := range []string{"subject", "workload", "proof-key", "delegation", "digest"} {
		t.Run("invalid/"+name, func(t *testing.T) {
			bad, reference := id, digest
			switch name {
			case "subject":
				bad.Subject.Sub = ""
			case "workload":
				bad.WorkloadID = ""
			case "proof-key":
				bad.DPoPJKT = ""
			case "delegation":
				bad.DelegationDigest = ""
			case "digest":
				reference = "https://caller-chosen.test/grants/" + digest
			}
			if _, err := resolver.Resolve(context.Background(), bad, reference); err == nil {
				t.Fatal("invalid lookup scope accepted")
			}
			if calls.Load() != 1 {
				t.Fatal("invalid scope reached pinned service")
			}
		})
	}
	// Constructor validation is not substituted for the server's real mTLS check.
	_, untrustedClient, _ := testCertificates(t)
	untrusted := *client
	transport := client.Transport.(*http.Transport).Clone()
	transport.TLSClientConfig = transport.TLSClientConfig.Clone()
	transport.TLSClientConfig.Certificates = []tls.Certificate{untrustedClient}
	untrusted.Transport = transport
	t.Cleanup(untrusted.CloseIdleConnections)
	badResolver, err := NewHTTPSGrantResolver(s.URL+"/pinned/resolve", &untrusted)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := badResolver.Resolve(context.Background(), id, digest); err == nil || calls.Load() != 1 {
		t.Fatal("untrusted client certificate reached resolver handler")
	}
}

func TestHTTPSGrantResolverResponseAndDeadlineBounds(t *testing.T) {
	_, _, _, id, _ := fixture(t, "resolver-bounds")
	digest := strings.Repeat("a", 64)
	for _, name := range []string{"exact-limit", "over-limit", "empty", "unavailable", "compressed", "redirect", "client-timeout", "parent-deadline", "internal-deadline"} {
		t.Run(name, func(t *testing.T) {
			var redirected atomic.Int64
			sink := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) { redirected.Add(1) }))
			t.Cleanup(sink.Close)
			s, client := referenceMTLSServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				switch name {
				case "exact-limit":
					_, _ = w.Write(bytes.Repeat([]byte("x"), MaxResolvedGrantBytes))
				case "over-limit":
					_, _ = w.Write(bytes.Repeat([]byte("x"), MaxResolvedGrantBytes+1))
				case "empty":
					return
				case "unavailable":
					http.Error(w, "not available", http.StatusServiceUnavailable)
				case "compressed":
					w.Header().Set("Content-Encoding", "gzip")
					_, _ = w.Write([]byte("compressed data is not an envelope"))
				case "redirect":
					http.Redirect(w, r, sink.URL+"/caller-token-sink", http.StatusTemporaryRedirect)
				case "client-timeout", "parent-deadline", "internal-deadline":
					// Drain the POST before waiting so net/http can detect peer
					// cancellation instead of holding an unread-body connection.
					_, _ = io.Copy(io.Discard, r.Body)
					<-r.Context().Done()
				}
			}))
			// Even an originally permissive client cannot redirect this lookup.
			client.CheckRedirect = func(*http.Request, []*http.Request) error { return nil }
			ctx := context.Background()
			if name == "client-timeout" {
				client.Timeout = 30 * time.Millisecond
			}
			if name == "parent-deadline" {
				var cancel context.CancelFunc
				ctx, cancel = context.WithTimeout(ctx, 30*time.Millisecond)
				defer cancel()
			}
			resolver, err := NewHTTPSGrantResolver(s.URL+"/resolve", client)
			if err != nil {
				t.Fatal(err)
			}
			started := time.Now()
			raw, err := resolver.Resolve(ctx, id, digest)
			elapsed := time.Since(started)
			if name == "exact-limit" {
				if err != nil || len(raw) != MaxResolvedGrantBytes {
					t.Fatalf("exact byte limit rejected: bytes=%d err=%v", len(raw), err)
				}
				return
			}
			if err == nil || len(raw) != 0 {
				t.Fatalf("unsafe response accepted: bytes=%d err=%v", len(raw), err)
			}
			if redirected.Load() != 0 {
				t.Fatal("resolver followed a caller-independent service redirect")
			}
			if (name == "client-timeout" || name == "parent-deadline") && elapsed > time.Second {
				t.Fatalf("shorter deadline ignored: %s", elapsed)
			}
			if name == "internal-deadline" && elapsed > 3*time.Second {
				t.Fatalf("lookup exceeded internal time budget: %s", elapsed)
			}
		})
	}
}

func TestProxyGrantReferenceNegotiationAndCarriage(t *testing.T) {
	for _, name := range []string{"no-reference-capability", "wrong-profile", "unknown-profile-field", "no-governed-capability", "resolver-disabled", "duplicate-reference", "duplicate-inline", "mixed", "mixed-empty-inline", "blank", "uri", "uppercase", "short", "whitespace", "comma-combined", "read-reference", "read-empty-reference"} {
		t.Run(name, func(t *testing.T) {
			g, raw, verifier, id, td := fixture(t, "ref-carriage-"+name)
			p, broker, target := referenceProxy(t, g, raw, verifier, id, td)
			_, digest, _ := verifier.Verify(raw)
			var lookups atomic.Int64
			p.GrantResolver = referenceResolverFunc(func(context.Context, Identity, string) ([]byte, error) { lookups.Add(1); return raw, nil })
			body := referenceRequestBody(t, "node_drain", `{"node":"node-a","expected_version":1}`, GrantReferenceProfile)
			headers := http.Header{GrantReferenceHeader: {digest}}
			want := "GRANT_MISMATCH"
			switch name {
			case "no-reference-capability":
				body = requestBody("node_drain", `{"node":"node-a","expected_version":1}`)
				want = "KF_REFERENCE_NOT_NEGOTIATED"
			case "wrong-profile":
				body = referenceRequestBody(t, "node_drain", `{"node":"node-a","expected_version":1}`, "KF-GRANT-REF-9.9")
				want = "KF_REFERENCE_NOT_NEGOTIATED"
			case "unknown-profile-field":
				body = bytes.Replace(body, []byte(`"profile":"KF-GRANT-REF-0.1"`), []byte(`"profile":"KF-GRANT-REF-0.1","extra":true`), 1)
				want = "KF_REFERENCE_NOT_NEGOTIATED"
			case "no-governed-capability":
				body = bytes.Replace(body, []byte(`"KF-MCP-0.1"`), []byte(`"KF-MCP-9.9"`), 1)
				want = "KF_EXTENSION_NOT_NEGOTIATED"
			case "resolver-disabled":
				p.GrantResolver = nil
				want = "KF_REFERENCE_NOT_NEGOTIATED"
			case "duplicate-reference":
				headers[GrantReferenceHeader] = []string{digest, digest}
			case "duplicate-inline":
				headers = http.Header{"Mcp-KedgeFlow-Grant": {HeaderGrant(raw), HeaderGrant(raw)}}
			case "mixed":
				headers["Mcp-KedgeFlow-Grant"] = []string{HeaderGrant(raw)}
			case "mixed-empty-inline":
				headers["Mcp-KedgeFlow-Grant"] = []string{""}
			case "blank":
				headers[GrantReferenceHeader] = []string{""}
			case "uri":
				headers[GrantReferenceHeader] = []string{"https://untrusted.test/" + digest}
			case "uppercase":
				headers[GrantReferenceHeader] = []string{strings.ToUpper(digest)}
			case "short":
				headers[GrantReferenceHeader] = []string{digest[:63]}
			case "whitespace":
				headers[GrantReferenceHeader] = []string{" " + digest}
			case "comma-combined":
				headers[GrantReferenceHeader] = []string{digest + "," + digest}
			case "read-reference", "read-empty-reference":
				body = referenceRequestBody(t, "node_read", `{}`, GrantReferenceProfile)
				want = "UNEXPECTED_GRANT"
				if name == "read-empty-reference" {
					headers[GrantReferenceHeader] = []string{""}
				}
			}
			w := referenceCall(p, body, headers)
			if got := errorMessage(w); got != want {
				t.Fatalf("got=%s want=%s body=%s", got, want, w.Body.String())
			}
			if lookups.Load() != 0 {
				t.Fatal("unnegotiated or ambiguous carriage reached resolver")
			}
			referenceAssertUnclaimed(t, p, g, broker, target)
		})
	}
}

func TestProxyGrantReferenceValidationBeforeClaim(t *testing.T) {
	for _, name := range []string{"wrong-digest", "wrong-subject", "wrong-workload", "wrong-proof-key", "wrong-delegation", "bad-signature", "expired", "wrong-audience", "parameter-drift", "resolver-error", "resolver-empty", "resolver-over-limit", "resolver-deadline"} {
		t.Run(name, func(t *testing.T) {
			g, raw, verifier, id, td, signer := fixtureWithKey(t, "ref-validation-"+name)
			p, broker, target := referenceProxy(t, g, raw, verifier, id, td)
			returned := append([]byte(nil), raw...)
			_, digest, _ := verifier.Verify(raw)
			lookupErr := error(nil)
			body := referenceRequestBody(t, "node_drain", `{"node":"node-a","expected_version":1}`, GrantReferenceProfile)
			switch name {
			case "wrong-digest":
				digest = strings.Repeat("f", 64)
			case "wrong-subject":
				id.Subject.Sub = "different-human"
			case "wrong-workload":
				id.WorkloadID = "spiffe://test/different-agent"
			case "wrong-proof-key":
				id.DPoPJKT = strings.Repeat("b", 43)
			case "wrong-delegation":
				id.DelegationDigest = strings.Repeat("b", 64)
			case "bad-signature":
				var env Envelope
				if err := json.Unmarshal(raw, &env); err != nil {
					t.Fatal(err)
				}
				env.Signature = strings.Repeat("A", 86)
				returned, _ = json.Marshal(env)
				digest, _ = Digest("grant", returned)
			case "expired", "wrong-audience":
				bad := g
				if name == "expired" {
					bad.IssuedAt = time.Now().Add(-2 * time.Minute).UnixMilli()
					bad.ValidFrom = bad.IssuedAt
					bad.ExpiresAt = time.Now().Add(-time.Minute).UnixMilli()
				} else {
					bad.Audience = "https://different-gateway.test/mcp"
				}
				var err error
				returned, err = SignGrant(bad, "issuer-test", signer)
				if err != nil {
					t.Fatal(err)
				}
				digest, _ = Digest("grant", returned)
			case "parameter-drift":
				body = referenceRequestBody(t, "node_drain", `{"node":"node-a","expected_version":2}`, GrantReferenceProfile)
			case "resolver-error":
				lookupErr = errors.New("reference service unavailable")
			case "resolver-empty":
				returned = nil
			case "resolver-over-limit":
				returned = bytes.Repeat([]byte("x"), MaxResolvedGrantBytes+1)
			case "resolver-deadline":
				p.Timeout = 30 * time.Millisecond
			}
			p.Auth = AuthFunc(func(*http.Request) (Identity, error) { return id, nil })
			var lookups atomic.Int64
			p.GrantResolver = referenceResolverFunc(func(ctx context.Context, caller Identity, reference string) ([]byte, error) {
				lookups.Add(1)
				if caller.Subject != id.Subject || caller.WorkloadID != id.WorkloadID || caller.DPoPJKT != id.DPoPJKT || caller.DelegationDigest != id.DelegationDigest || reference != digest {
					t.Error("proxy passed wrong authenticated requester/reference to resolver")
				}
				if name == "resolver-deadline" {
					<-ctx.Done()
					return raw, nil // A late full envelope must still be refused.
				}
				return returned, lookupErr
			})
			want := "GRANT_MISMATCH"
			if strings.HasPrefix(name, "resolver-") {
				want = "GRANT_REFERENCE_UNAVAILABLE"
			}
			w := referenceCall(p, body, http.Header{GrantReferenceHeader: {digest}})
			if got := errorMessage(w); got != want || lookups.Load() != 1 {
				t.Fatalf("got=%s want=%s lookups=%d body=%s", got, want, lookups.Load(), w.Body.String())
			}
			referenceAssertUnclaimed(t, p, g, broker, target)
		})
	}
}

func TestProxyGrantReferenceAndInlineShareConsumption(t *testing.T) {
	g, raw, verifier, id, td := fixture(t, "ref-inline-conservation")
	p, broker, target := referenceProxy(t, g, raw, verifier, id, td)
	_, digest, _ := verifier.Verify(raw)
	var lookups atomic.Int64
	p.GrantResolver = referenceResolverFunc(func(context.Context, Identity, string) ([]byte, error) { lookups.Add(1); return raw, nil })
	body := referenceRequestBody(t, "node_drain", `{"node":"node-a","expected_version":1}`, GrantReferenceProfile)
	if w := referenceCall(p, body, http.Header{GrantReferenceHeader: {digest}}); errorMessage(w) != "" {
		t.Fatal(w.Body.String())
	}
	// Negotiation is per request, even after a successful negotiated reference call.
	plain := requestBody("node_drain", `{"node":"node-a","expected_version":1}`)
	if w := referenceCall(p, plain, http.Header{GrantReferenceHeader: {digest}}); errorMessage(w) != "KF_REFERENCE_NOT_NEGOTIATED" || lookups.Load() != 1 {
		t.Fatalf("reference capability leaked across requests: %s lookups=%d", w.Body.String(), lookups.Load())
	}
	if w := referenceCall(p, plain, http.Header{"Mcp-KedgeFlow-Grant": {HeaderGrant(raw)}}); errorMessage(w) != "NONCE_CONSUMED" {
		t.Fatalf("inline transport reopened reference allowance: %s", w.Body.String())
	}
	if w := referenceCall(p, body, http.Header{GrantReferenceHeader: {digest}}); errorMessage(w) != "NONCE_CONSUMED" {
		t.Fatalf("reference transport replayed consumed allowance: %s", w.Body.String())
	}
	target.mu.Lock()
	defer target.mu.Unlock()
	if target.effects != 1 || target.leaked || broker.calls.Load() != 1 || lookups.Load() != 2 {
		t.Fatalf("effects=%d leaked=%v credentials=%d lookups=%d", target.effects, target.leaked, broker.calls.Load(), lookups.Load())
	}
}

func TestProxyLargeGrantReferenceMTLS(t *testing.T) {
	g, _, verifier, id, td, signer := fixtureWithKey(t, "ref-large-envelope")
	var contract map[string]any
	if err := json.Unmarshal(g.AdapterContract, &contract); err != nil {
		t.Fatal(err)
	}
	// commit_point is a typed string without the schema's bounded-ID limit.
	// It remains part of both the signed grant and exact registered descriptor.
	contract["commit_point"] = "mock atomic version+fence+mutation; " + strings.Repeat("bound adapter description. ", 450)
	encoded, err := json.Marshal(contract)
	if err != nil {
		t.Fatal(err)
	}
	g.AdapterContract, td.AdapterContract = encoded, encoded
	raw, err := SignGrant(g, "issuer-test", signer)
	if err != nil {
		t.Fatal(err)
	}
	_, digest, err := verifier.Verify(raw)
	if err != nil {
		t.Fatal(err)
	}
	if len(raw) <= MaxInlineGrantHeader || len(HeaderGrant(raw)) <= MaxInlineGrantHeader || len(raw) >= MaxResolvedGrantBytes {
		t.Fatalf("fixture does not exercise transport sizes: raw=%d inline=%d", len(raw), len(HeaderGrant(raw)))
	}
	p, broker, target := referenceProxy(t, g, raw, verifier, id, td)
	var lookups atomic.Int64
	s, client := referenceMTLSServer(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		lookups.Add(1)
		var query GrantReferenceQuery
		if err := json.NewDecoder(r.Body).Decode(&query); err != nil || query.GrantDigest != digest || query.Subject != id.Subject || query.WorkloadID != id.WorkloadID || query.DPoPJKT != id.DPoPJKT || query.DelegationDigest != id.DelegationDigest {
			t.Error("large grant lookup scope mismatch")
		}
		for _, header := range []string{"Authorization", "DPoP", "Cookie", GrantReferenceHeader, "Mcp-KedgeFlow-Grant", "X-Agent-Credential"} {
			if len(r.Header.Values(header)) != 0 {
				t.Errorf("incoming authority forwarded to reference store: %s", header)
			}
		}
		_, _ = w.Write(raw)
	}))
	p.GrantResolver, err = NewHTTPSGrantResolver(s.URL+"/grants/resolve", client)
	if err != nil {
		t.Fatal(err)
	}
	body := referenceRequestBody(t, "node_drain", `{"node":"node-a","expected_version":1}`, GrantReferenceProfile)
	if w := referenceCall(p, body, http.Header{"Mcp-KedgeFlow-Grant": {HeaderGrant(raw)}}); errorMessage(w) != "GRANT_HEADER_TOO_LARGE" {
		t.Fatalf("oversized inline envelope accepted: %s", w.Body.String())
	}
	referenceAssertUnclaimed(t, p, g, broker, target)
	if lookups.Load() != 0 {
		t.Fatal("inline rejection performed reference lookup")
	}
	if w := referenceCall(p, body, http.Header{GrantReferenceHeader: {digest}}); errorMessage(w) != "" {
		t.Fatalf("large complete reference grant refused: %s", w.Body.String())
	}
	target.mu.Lock()
	defer target.mu.Unlock()
	if target.effects != 1 || target.leaked || broker.calls.Load() != 1 || lookups.Load() != 1 {
		t.Fatalf("effects=%d leaked=%v credentials=%d lookups=%d", target.effects, target.leaked, broker.calls.Load(), lookups.Load())
	}
	t.Logf("GRANT_REFERENCE complete signed envelope raw_bytes=%d inline_header_bytes=%d; TLS13 mTLS lookup; exact binding and one claim/effect", len(raw), len(HeaderGrant(raw)))
}

func TestProxyGrantReferenceDiscoveryIsOptional(t *testing.T) {
	g, raw, verifier, id, td := fixture(t, "ref-discovery")
	p, _, _ := referenceProxy(t, g, raw, verifier, id, td)
	var req Request
	if err := json.Unmarshal(requestBody("node_drain", `{}`), &req); err != nil {
		t.Fatal(err)
	}
	req.Method = "server/discover"
	body, err := json.Marshal(req)
	if err != nil {
		t.Fatal(err)
	}
	for _, enabled := range []bool{false, true} {
		if enabled {
			p.GrantResolver = referenceResolverFunc(func(context.Context, Identity, string) ([]byte, error) {
				t.Fatal("discovery resolved a grant")
				return nil, nil
			})
		}
		w := referenceCall(p, body, nil)
		var response struct {
			Result struct {
				Capabilities struct {
					Extensions map[string]json.RawMessage `json:"extensions"`
				} `json:"capabilities"`
			} `json:"result"`
		}
		if err := json.Unmarshal(w.Body.Bytes(), &response); err != nil || errorMessage(w) != "" {
			t.Fatalf("discovery failed: %s err=%v", w.Body.String(), err)
		}
		if _, present := response.Result.Capabilities.Extensions["io.kedgeflow/grant-reference"]; present != enabled {
			t.Fatalf("reference advertised=%v configured=%v", present, enabled)
		}
		if enabled {
			var binding struct {
				Profile string `json:"profile"`
				Header  string `json:"header"`
				Limit   int    `json:"max_resolved_grant_bytes"`
			}
			if err := json.Unmarshal(response.Result.Capabilities.Extensions["io.kedgeflow/grant-reference"], &binding); err != nil || binding.Profile != GrantReferenceProfile || binding.Header != GrantReferenceHeader || binding.Limit != MaxResolvedGrantBytes {
				t.Fatalf("reference discovery contract mismatch: %+v err=%v", binding, err)
			}
		}
	}
}
