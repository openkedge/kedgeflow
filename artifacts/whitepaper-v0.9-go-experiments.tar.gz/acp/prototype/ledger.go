package kedgeflow

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
)

var ErrRefused = errors.New("authority transaction refused")
var ErrNonceConsumed = fmt.Errorf("nonce consumed: %w", ErrRefused)

type Ledger struct {
	Client *clientv3.Client
	Prefix string
}
type Root struct {
	Generation uint64 `json:"generation"`
	Fence      uint64 `json:"fence"`
	ActiveGID  string `json:"active_gid"`
	Status     string `json:"status"`
}
type Attempt struct {
	ID          string `json:"id"`
	GrantDigest string `json:"grant_digest"`
	RootID      string `json:"root_id"`
	Status      string `json:"status"`
	ClaimedAt   string `json:"claimed_at"`
}

func keyPart(s string) string                     { return base64.RawURLEncoding.EncodeToString([]byte(s)) }
func (l Ledger) domain(g Grant) string            { return l.Prefix + "/domains/" + keyPart(g.ConflictDomain) }
func (l Ledger) root(g Grant) string              { return l.domain(g) + "/roots/" + keyPart(g.RootID) }
func (l Ledger) grant(g Grant) string             { return l.root(g) + "/grants/" + keyPart(g.GID) }
func (l Ledger) nonce(g Grant) string             { return l.root(g) + "/nonces/" + keyPart(g.Nonce) }
func (l Ledger) outbox(g Grant, id string) string { return l.root(g) + "/outbox/" + keyPart(id) }
func expectedRoot(g Grant) Root                   { return Root{g.RootGeneration, g.Fence, g.GID, "unclaimed"} }
func value(v any) string {
	b, e := marshalCanonical(v)
	if e != nil {
		panic(e)
	}
	return string(b)
}

// PublishPolicy is an authority-side method. The proxy exposes no bootstrap,
// issue, policy, or replace endpoints. etcd ACLs MUST keep these writers trusted.
func (l Ledger) PublishPolicy(ctx context.Context, g Grant) error {
	pk, okey := l.domain(g)+"/policy", l.domain(g)+"/ownership"
	read, e := l.Client.Txn(ctx).Then(clientv3.OpGet(pk), clientv3.OpGet(okey)).Commit()
	if e != nil {
		return e
	}
	compares := []clientv3.Cmp{}
	pr := read.Responses[0].GetResponseRange()
	or := read.Responses[1].GetResponseRange()
	if len(pr.Kvs) == 0 {
		compares = append(compares, clientv3.Compare(clientv3.Version(pk), "=", 0))
	} else {
		var old Policy
		if json.Unmarshal(pr.Kvs[0].Value, &old) != nil || g.Policy.ID != old.ID || g.Policy.Epoch < old.Epoch || (g.Policy.Epoch == old.Epoch && g.Policy.Digest != old.Digest) {
			return ErrRefused
		}
		compares = append(compares, clientv3.Compare(clientv3.ModRevision(pk), "=", pr.Kvs[0].ModRevision))
	}
	if len(or.Kvs) == 0 {
		compares = append(compares, clientv3.Compare(clientv3.Version(okey), "=", 0))
	} else {
		old, e := strconv.ParseUint(string(or.Kvs[0].Value), 10, 64)
		if e != nil || g.OwnershipEpoch < old {
			return ErrRefused
		}
		compares = append(compares, clientv3.Compare(clientv3.ModRevision(okey), "=", or.Kvs[0].ModRevision))
	}
	t, e := l.Client.Txn(ctx).If(compares...).Then(clientv3.OpPut(pk, value(g.Policy)), clientv3.OpPut(okey, strconv.FormatUint(g.OwnershipEpoch, 10))).Commit()
	if e != nil {
		return e
	}
	if !t.Succeeded {
		return ErrRefused
	}
	return nil
}

// Issue requires a verified signed grant; authority owns the prefix. Fresh root
// allocation fails on existing root/nonce/grant. Never called from tools/call.
func (l Ledger) Issue(ctx context.Context, g Grant, digest string) error {
	r := l.root(g)
	t, err := l.Client.Txn(ctx).If(clientv3.Compare(clientv3.Version(r), "=", 0), clientv3.Compare(clientv3.Version(l.grant(g)), "=", 0), clientv3.Compare(clientv3.Version(l.nonce(g)), "=", 0), clientv3.Compare(clientv3.Value(l.domain(g)+"/policy"), "=", value(g.Policy)), clientv3.Compare(clientv3.Value(l.domain(g)+"/ownership"), "=", strconv.FormatUint(g.OwnershipEpoch, 10))).Then(clientv3.OpPut(r, value(expectedRoot(g))), clientv3.OpPut(l.grant(g), digest)).Commit()
	if err != nil {
		return err
	}
	if !t.Succeeded {
		return ErrRefused
	}
	return nil
}
func (l Ledger) Claim(ctx context.Context, g Grant, digest, attemptID string) (Attempt, error) {
	a := Attempt{attemptID, digest, g.RootID, "claimed", time.Now().UTC().Format(time.RFC3339Nano)}
	root := expectedRoot(g)
	root.Status = "claimed"
	ak := l.root(g) + "/attempts/" + keyPart(attemptID)
	t, err := l.Client.Txn(ctx).If(
		clientv3.Compare(clientv3.Value(l.root(g)), "=", value(expectedRoot(g))),
		clientv3.Compare(clientv3.Value(l.grant(g)), "=", digest),
		clientv3.Compare(clientv3.Version(l.nonce(g)), "=", 0),
		clientv3.Compare(clientv3.Version(ak), "=", 0),
		clientv3.Compare(clientv3.Version(l.outbox(g, attemptID)), "=", 0),
		clientv3.Compare(clientv3.Value(l.domain(g)+"/policy"), "=", value(g.Policy)),
		clientv3.Compare(clientv3.Value(l.domain(g)+"/ownership"), "=", strconv.FormatUint(g.OwnershipEpoch, 10)),
	).Then(clientv3.OpPut(l.root(g), value(root)), clientv3.OpPut(l.nonce(g), attemptID), clientv3.OpPut(ak, value(a)), clientv3.OpPut(l.outbox(g, attemptID), "claimed_not_dispatched")).Else(clientv3.OpGet(l.nonce(g))).Commit()
	if err != nil {
		return a, err
	}
	if !t.Succeeded {
		if len(t.Responses) > 0 && len(t.Responses[0].GetResponseRange().Kvs) > 0 {
			return a, ErrNonceConsumed
		}
		return a, ErrRefused
	}
	return a, nil
}

// Replace is a trusted authority transaction, only from an unclaimed root;
// races with Claim on the SAME root key. Consumed/unknown attempts cannot reset.
func (l Ledger) Replace(ctx context.Context, old, next Grant, nextDigest string) error {
	if old.RootID != next.RootID || old.ConflictDomain != next.ConflictDomain || next.RootGeneration != old.RootGeneration+1 || next.Fence <= old.Fence {
		return errors.New("invalid generation transition")
	}
	t, err := l.Client.Txn(ctx).If(clientv3.Compare(clientv3.Value(l.root(old)), "=", value(expectedRoot(old))), clientv3.Compare(clientv3.Version(l.nonce(old)), "=", 0), clientv3.Compare(clientv3.Version(l.grant(next)), "=", 0), clientv3.Compare(clientv3.Version(l.nonce(next)), "=", 0), clientv3.Compare(clientv3.Value(l.domain(next)+"/policy"), "=", value(next.Policy)), clientv3.Compare(clientv3.Value(l.domain(next)+"/ownership"), "=", strconv.FormatUint(next.OwnershipEpoch, 10))).Then(clientv3.OpPut(l.root(old), value(expectedRoot(next))), clientv3.OpPut(l.grant(next), nextDigest)).Commit()
	if err != nil {
		return err
	}
	if !t.Succeeded {
		return ErrRefused
	}
	return nil
}
func (l Ledger) Finish(ctx context.Context, g Grant, a Attempt, status string) error {
	if status != "committed" && status != "not_dispatched" && status != "unknown" && status != "state_guard_violation" {
		return fmt.Errorf("invalid outcome")
	}
	k := l.root(g) + "/attempts/" + keyPart(a.ID)
	before := value(a)
	a.Status = status
	t, err := l.Client.Txn(ctx).If(clientv3.Compare(clientv3.Value(k), "=", before)).Then(clientv3.OpPut(k, value(a)), clientv3.OpPut(l.outbox(g, a.ID), status)).Commit()
	if err != nil {
		return err
	}
	if !t.Succeeded {
		return ErrRefused
	}
	return nil
}

// AuthorizeDispatch rechecks policy and ownership immediately before dispatch.
// The remote physical effect is outside this transaction. Durable outbox state
// records uncertainty; recovery workers must query instead of blind redelivery.
func (l Ledger) AuthorizeDispatch(ctx context.Context, g Grant, digest, id string) error {
	r := expectedRoot(g)
	r.Status = "claimed"
	t, e := l.Client.Txn(ctx).If(clientv3.Compare(clientv3.Value(l.root(g)), "=", value(r)), clientv3.Compare(clientv3.Value(l.grant(g)), "=", digest), clientv3.Compare(clientv3.Value(l.nonce(g)), "=", id), clientv3.Compare(clientv3.Value(l.domain(g)+"/policy"), "=", value(g.Policy)), clientv3.Compare(clientv3.Value(l.domain(g)+"/ownership"), "=", strconv.FormatUint(g.OwnershipEpoch, 10)), clientv3.Compare(clientv3.Value(l.outbox(g, id)), "=", "claimed_not_dispatched")).Then(clientv3.OpPut(l.outbox(g, id), "dispatch_authorized")).Commit()
	if e != nil {
		return e
	}
	if !t.Succeeded {
		return ErrRefused
	}
	return nil
}
func (l Ledger) Status(ctx context.Context, g Grant, id string) (Attempt, error) {
	r, err := l.Client.Get(ctx, l.root(g)+"/attempts/"+keyPart(id))
	if err != nil {
		return Attempt{}, err
	}
	if len(r.Kvs) != 1 {
		return Attempt{}, errors.New("unknown attempt")
	}
	var a Attempt
	err = json.Unmarshal(r.Kvs[0].Value, &a)
	return a, err
}
