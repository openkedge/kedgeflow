package kedgeflow

import (
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestMCPCompleteResultIsNotEnterpriseCommit(t *testing.T) {
	for _, name := range []string{"missing_terminal_receipt", "mismatched_terminal_receipt", "tool_error", "asynchronous_result"} {
		t.Run(name, func(t *testing.T) {
			g, raw, v, id, td := fixture(t, "terminal-"+name)
			l := ledger(t, g, raw, v)
			broker := &testBroker{}
			target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				var req Request
				b, _ := io.ReadAll(r.Body)
				_ = json.Unmarshal(b, &req)
				result := map[string]any{"resultType": "complete", "content": []any{}, "isError": false}
				if name == "mismatched_terminal_receipt" {
					result["structuredContent"] = map[string]any{"kedgeflow_terminal_receipt": MockTerminalReceipt{"wrong-attempt", g.ProposalDigest, g.Resources[0], g.Fence, "committed", 2}}
				}
				if name == "tool_error" {
					result["isError"] = true
				}
				if name == "asynchronous_result" {
					result["resultType"] = "accepted"
				}
				rb, _ := json.Marshal(result)
				response(w, req.ID, rb, 0, "", nil)
			}))
			defer target.Close()
			p := &Proxy{Verifier: v, Ledger: l, Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: broker, Adapter: &HTTPAdapter{target.Client(), target.URL, "mock-target", "target-read-token"}, Tools: map[string]ToolDescriptor{"node_drain": td}}
			body := requestBody("node_drain", `{"node":"node-a","expected_version":1}`)
			if w := call(p, body, HeaderGrant(raw)); errorMessage(w) != "OUTCOME_UNKNOWN" {
				t.Fatal("inferred commit from MCP result", w.Body.String())
			}
			if w := call(p, body, HeaderGrant(raw)); errorMessage(w) != "NONCE_CONSUMED" {
				t.Fatal("unknown restored grant", w.Body.String())
			}
			if broker.calls.Load() != 1 {
				t.Fatal("unknown caused credential retry")
			}
		})
	}
}
