package kedgeflow

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/base64"
	"encoding/pem"
	"errors"
	"math/big"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"sync/atomic"
	"testing"
	"time"
)

func writeResult(name string, b []byte) error {
	_ = os.MkdirAll("results", 0755)
	return os.WriteFile("results/"+name, b, 0644)
}
func testCertificates(t *testing.T) (tls.Certificate, tls.Certificate, *x509.CertPool) {
	t.Helper()
	pub, priv, _ := ed25519.GenerateKey(rand.Reader)
	now := time.Now()
	ca := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "test-ca"}, NotBefore: now.Add(-time.Minute), NotAfter: now.Add(time.Hour), IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign}
	der, e := x509.CreateCertificate(rand.Reader, ca, ca, pub, priv)
	if e != nil {
		t.Fatal(e)
	}
	caCert, _ := x509.ParseCertificate(der)
	pool := x509.NewCertPool()
	pool.AddCert(caCert)
	leaf := func(serial int64, client bool) tls.Certificate {
		pk, sk, _ := ed25519.GenerateKey(rand.Reader)
		usage := x509.ExtKeyUsageServerAuth
		if client {
			usage = x509.ExtKeyUsageClientAuth
		}
		c := &x509.Certificate{SerialNumber: big.NewInt(serial), Subject: pkix.Name{CommonName: "gateway"}, NotBefore: now.Add(-time.Minute), NotAfter: now.Add(time.Hour), ExtKeyUsage: []x509.ExtKeyUsage{usage}, KeyUsage: x509.KeyUsageDigitalSignature, DNSNames: []string{"localhost"}, IPAddresses: []net.IP{net.ParseIP("127.0.0.1")}}
		d, e := x509.CreateCertificate(rand.Reader, c, caCert, pk, priv)
		if e != nil {
			t.Fatal(e)
		}
		kb, _ := x509.MarshalPKCS8PrivateKey(sk)
		crt, e := tls.X509KeyPair(pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: d}), pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: kb}))
		if e != nil {
			t.Fatal(e)
		}
		return crt
	}
	return leaf(2, false), leaf(3, true), pool
}
func TestRFC8693ExchangeMTLSAndGrantBoundary(t *testing.T) {
	g, raw, v, id, td := fixture(t, "token-exchange")
	l := ledger(t, g, raw, v)
	_, gd, _ := v.Verify(raw)
	a, e := l.Claim(context.Background(), g, gd, "broker-attempt")
	if e != nil {
		t.Fatal(e)
	}
	c := VerifiedCall{Request: Request{}, Grant: g, Identity: id, AttemptID: a.ID, Descriptor: td, GrantDigest: gd, SignedGrant: raw}
	serverCert, clientCert, roots := testCertificates(t)
	calls := 0
	s := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls++
		if r.TLS == nil || len(r.TLS.VerifiedChains) == 0 {
			t.Error("mTLS not verified")
		}
		if e := r.ParseForm(); e != nil {
			t.Error(e)
		}
		if r.Form.Get("grant_type") != "urn:ietf:params:oauth:grant-type:token-exchange" || r.Form.Get("subject_token") != id.AccessToken || r.Form.Get("actor_token") != "trusted-workload-assertion" || r.Form.Get("audience") != "mock-target" || r.Form.Get("scope") != "node.drain" || r.Form.Get("kedgeflow_attempt_id") != a.ID {
			t.Error("exchange binding failed")
		}
		gb, e := base64.RawURLEncoding.DecodeString(r.Form.Get("kedgeflow_grant"))
		if e != nil {
			t.Error(e)
		}
		verified, d, e := v.Verify(gb)
		if e != nil || d != gd || verified.GID != g.GID || r.Form.Get("kedgeflow_grant_digest") != gd {
			t.Error("signed grant extension mismatch")
		}
		status, e := l.Status(r.Context(), g, a.ID)
		if e != nil || status.Status != "claimed" {
			t.Error("unclaimed exchange")
		}
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"access_token":"target-scoped-token","issued_token_type":"urn:ietf:params:oauth:token-type:access_token","token_type":"Bearer","expires_in":60,"scope":"node.drain"}`))
	}))
	s.TLS = &tls.Config{Certificates: []tls.Certificate{serverCert}, ClientAuth: tls.RequireAndVerifyClientCert, ClientCAs: roots, MinVersion: tls.VersionTLS13}
	s.StartTLS()
	defer s.Close()
	client, e := NewMTLSHTTPClient(&tls.Config{Certificates: []tls.Certificate{clientCert}, RootCAs: roots})
	if e != nil {
		t.Fatal(e)
	}
	b := &RFC8693Broker{Endpoint: s.URL, TargetAudience: "mock-target", TargetScope: "node.drain", Client: client, WorkloadAssertion: func(_ context.Context, workload string) (string, error) {
		if workload != id.WorkloadID {
			t.Fatal("wrong actor workload")
		}
		return "trusted-workload-assertion", nil
	}}
	credential, e := b.Exchange(context.Background(), c)
	if e != nil || credential.Token != "target-scoped-token" || credential.Audience != "mock-target" || calls != 1 {
		t.Fatal(credential, e, calls)
	}
	if _, e = NewMTLSHTTPClient(&tls.Config{InsecureSkipVerify: true, Certificates: []tls.Certificate{clientCert}, RootCAs: roots}); e == nil {
		t.Fatal("insecure broker config accepted")
	}
	missing := c
	missing.SignedGrant = nil
	if _, e = b.Exchange(context.Background(), missing); e == nil {
		t.Fatal("unbound exchange accepted")
	}
	if calls != 1 {
		t.Fatal("invalid exchange reached issuer")
	}
	t.Log("TOKEN_EXCHANGE verified mutual TLS; distinct audience/scope token; signed grant and claimed-attempt AS extension; insecure TLS and missing grant rejected")
}

// The clock advances at controlled protocol boundaries, without sleeping or
// depending on TLS/server scheduling. It is safe to advance from an issuer.
type brokerTestClock struct{ millis atomic.Int64 }

func newBrokerTestClock(now time.Time) *brokerTestClock {
	c := &brokerTestClock{}
	c.millis.Store(now.UnixMilli())
	return c
}
func (c *brokerTestClock) Now() time.Time { return time.UnixMilli(c.millis.Load()) }
func (c *brokerTestClock) Advance(d time.Duration) {
	c.millis.Add(d.Milliseconds())
}

func testRFC8693Broker(t *testing.T, handler http.Handler, now func() time.Time) *RFC8693Broker {
	t.Helper()
	serverCert, clientCert, roots := testCertificates(t)
	s := httptest.NewUnstartedServer(handler)
	s.TLS = &tls.Config{Certificates: []tls.Certificate{serverCert}, ClientAuth: tls.RequireAndVerifyClientCert, ClientCAs: roots, MinVersion: tls.VersionTLS13}
	s.StartTLS()
	t.Cleanup(s.Close)
	client, e := NewMTLSHTTPClient(&tls.Config{Certificates: []tls.Certificate{clientCert}, RootCAs: roots})
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(client.CloseIdleConnections)
	return &RFC8693Broker{Endpoint: s.URL, TargetAudience: "mock-target", TargetScope: "node.drain", Client: client, Now: now, WorkloadAssertion: func(context.Context, string) (string, error) {
		return "trusted-workload-assertion", nil
	}}
}

const brokerTestTokenResponse = `{"access_token":"target-scoped-token","issued_token_type":"urn:ietf:params:oauth:token-type:access_token","token_type":"Bearer","expires_in":60,"scope":"node.drain"}`

func TestRFC8693ExchangeRejectsOversizedResponse(t *testing.T) {
	g, raw, v, id, td := fixture(t, "oversized-exchange")
	_, gd, err := v.Verify(raw)
	if err != nil {
		t.Fatal(err)
	}
	// A valid JSON prefix plus whitespace fills the previous read limit. An
	// invalid suffix beyond that boundary must not become an accepted token.
	body := brokerTestTokenResponse + strings.Repeat(" ", 65536-len(brokerTestTokenResponse)) + "untrusted-tail"
	b := testRFC8693Broker(t, http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		_, _ = w.Write([]byte(body))
	}), nil)
	credential, err := b.Exchange(context.Background(), VerifiedCall{Grant: g, Identity: id, Descriptor: td, GrantDigest: gd, SignedGrant: raw})
	if err == nil || credential.Token != "" {
		t.Fatal("oversized token response accepted", err)
	}
}

func TestRFC8693ExchangeConservativeLifetime(t *testing.T) {
	for _, tc := range []struct {
		name        string
		grantLife   time.Duration
		latency     time.Duration
		timeout     time.Duration
		wantRefused bool
	}{
		{"latency_reduces_local_lifetime", 3 * time.Minute, 4 * time.Second, 0, false},
		{"latency_consumes_token_lifetime", 3 * time.Minute, time.Minute, 2 * time.Minute, true},
		{"latency_expires_grant", 3 * time.Minute, 3 * time.Minute, 4 * time.Minute, true},
		{"upper_expiry_bound_crosses_grant", 61 * time.Second, 2 * time.Second, 0, true},
		{"latency_consumes_exchange_budget", 3 * time.Minute, 5 * time.Second, 0, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			g, _, v, id, td, key := fixtureWithKey(t, "broker-life-"+tc.name)
			clock := newBrokerTestClock(time.Now())
			started := clock.Now()
			g.ExpiresAt = started.Add(tc.grantLife).UnixMilli()
			v.Now = clock.Now
			raw, e := SignGrant(g, "issuer-test", key)
			if e != nil {
				t.Fatal(e)
			}
			_, gd, e := v.Verify(raw)
			if e != nil {
				t.Fatal(e)
			}
			c := VerifiedCall{Grant: g, Identity: id, AttemptID: "broker-life-attempt", Descriptor: td, GrantDigest: gd, SignedGrant: raw}
			var exchanges atomic.Int64
			b := testRFC8693Broker(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				exchanges.Add(1)
				clock.Advance(tc.latency)
				w.Header().Set("Content-Type", "application/json")
				_, _ = w.Write([]byte(brokerTestTokenResponse))
			}), clock.Now)
			b.ExchangeTimeout = tc.timeout
			credential, e := b.Exchange(context.Background(), c)
			if tc.wantRefused {
				if e == nil || credential.Token != "" {
					t.Fatal("late/broader credential returned", credential, e)
				}
			} else if e != nil || credential.Token != "target-scoped-token" || !credential.ExpiresAt.Equal(started.Add(time.Minute)) {
				t.Fatal("latency extended usable credential lifetime", credential, e)
			}
			if exchanges.Load() != 1 {
				t.Fatal("exchange was retried", exchanges.Load())
			}
		})
	}
}

func TestRFC8693ExchangeDeadlineBudget(t *testing.T) {
	for _, tc := range []struct {
		name      string
		timeout   time.Duration
		grantLife time.Duration
		budget    time.Duration
		parent    bool
	}{
		{"default", 0, time.Minute, 5 * time.Second, false},
		{"configured", time.Second, time.Minute, time.Second, false},
		{"grant_remaining", 5 * time.Second, 3 * time.Second, 3 * time.Second, false},
		{"parent_deadline", 5 * time.Second, time.Minute, time.Second, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			g, _, v, id, td, key := fixtureWithKey(t, "broker-budget-"+tc.name)
			clock := newBrokerTestClock(time.Now())
			g.ExpiresAt = clock.Now().Add(tc.grantLife).UnixMilli()
			v.Now = clock.Now
			raw, e := SignGrant(g, "issuer-test", key)
			if e != nil {
				t.Fatal(e)
			}
			_, gd, e := v.Verify(raw)
			if e != nil {
				t.Fatal(e)
			}
			b := testRFC8693Broker(t, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
				t.Error("deadline inspection should not call issuer")
			}), clock.Now)
			b.ExchangeTimeout = tc.timeout
			ctx := context.Background()
			var parentDeadline time.Time
			if tc.parent {
				parentDeadline = time.Now().Add(tc.budget)
				var cancel context.CancelFunc
				ctx, cancel = context.WithDeadline(ctx, parentDeadline)
				defer cancel()
			}
			var deadline time.Time
			b.WorkloadAssertion = func(ctx context.Context, _ string) (string, error) {
				var ok bool
				deadline, ok = ctx.Deadline()
				if !ok {
					t.Error("assertion acquisition has no exchange deadline")
				}
				return "", errors.New("stop after deadline inspection")
			}
			before := time.Now()
			_, _ = b.Exchange(ctx, VerifiedCall{Grant: g, Identity: id, Descriptor: td, GrantDigest: gd, SignedGrant: raw})
			after := time.Now()
			if tc.parent {
				if !deadline.Equal(parentDeadline) {
					t.Fatal("parent deadline broadened", deadline, parentDeadline)
				}
			} else if deadline.Before(before.Add(tc.budget)) || deadline.After(after.Add(tc.budget)) {
				t.Fatal("incorrect exchange budget", deadline, before, after, tc.budget)
			}
		})
	}
}

func TestRFC8693ExchangeRefusesBeforeHTTP(t *testing.T) {
	for _, name := range []string{"expired_before_exchange", "assertion_consumes_grant", "assertion_consumes_exchange_budget", "cancelled_parent", "assertion_cancels_parent", "negative_timeout"} {
		t.Run(name, func(t *testing.T) {
			g, raw, v, id, td := fixture(t, "broker-refusal-"+name)
			_, gd, e := v.Verify(raw)
			if e != nil {
				t.Fatal(e)
			}
			clock := newBrokerTestClock(time.Now())
			var exchanges atomic.Int64
			b := testRFC8693Broker(t, http.HandlerFunc(func(http.ResponseWriter, *http.Request) {
				exchanges.Add(1)
			}), clock.Now)
			ctx, cancel := context.WithCancel(context.Background())
			defer cancel()
			assertions := 0
			b.WorkloadAssertion = func(context.Context, string) (string, error) {
				assertions++
				if name == "assertion_consumes_grant" {
					clock.millis.Store(g.ExpiresAt)
				}
				if name == "assertion_consumes_exchange_budget" {
					clock.Advance(5 * time.Second)
				}
				if name == "assertion_cancels_parent" {
					cancel()
				}
				return "assertion", nil
			}
			switch name {
			case "expired_before_exchange":
				clock.millis.Store(g.ExpiresAt)
			case "cancelled_parent":
				cancel()
			case "negative_timeout":
				b.ExchangeTimeout = -time.Second
			}
			credential, e := b.Exchange(ctx, VerifiedCall{Grant: g, Identity: id, Descriptor: td, GrantDigest: gd, SignedGrant: raw})
			if e == nil || credential.Token != "" || exchanges.Load() != 0 {
				t.Fatal("invalid exchange reached issuer or returned credential", e, exchanges.Load())
			}
			wantAssertions := 0
			if name == "assertion_consumes_grant" || name == "assertion_consumes_exchange_budget" || name == "assertion_cancels_parent" {
				wantAssertions = 1
			}
			if assertions != wantAssertions {
				t.Fatal("unexpected assertion acquisition", assertions, wantAssertions)
			}
		})
	}
}
