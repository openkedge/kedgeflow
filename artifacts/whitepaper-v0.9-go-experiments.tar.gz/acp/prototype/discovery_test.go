package kedgeflow

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	clientv3 "go.etcd.io/etcd/client/v3"
	"net/http"
	"testing"
	"time"
)

func TestAuthenticatedMCPDiscovery(t *testing.T) {
	_, _, _, id, td := fixture(t, "discover")
	p := &Proxy{Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Tools: map[string]ToolDescriptor{"node_drain": td, "node_read": {Name: "node_read", ReadOnly: true, RequiredScope: "read"}}}
	for _, method := range []string{"server/discover", "tools/list"} {
		body := []byte(fmt.Sprintf(`{"jsonrpc":"2.0","id":1,"method":%q,"params":{"_meta":{"io.modelcontextprotocol/protocolVersion":"2026-07-28","io.modelcontextprotocol/clientCapabilities":{}}}}`, method))
		w := call(p, body, "")
		if errorMessage(w) != "" {
			t.Fatal(w.Body.String())
		}
		var resp rpcResponse
		_ = json.Unmarshal(w.Body.Bytes(), &resp)
		var result map[string]any
		_ = json.Unmarshal(resp.Result, &result)
		if result["resultType"] != "complete" {
			t.Fatal("noncompliant result", result)
		}
		if method == "tools/list" && len(result["tools"].([]any)) != 2 {
			t.Fatal("catalog not authorization filtered")
		}
	}
	id.Scopes = map[string]bool{"read": true}
	w := call(p, []byte(`{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{"_meta":{"io.modelcontextprotocol/protocolVersion":"2026-07-28","io.modelcontextprotocol/clientCapabilities":{}}}}`), "")
	var resp rpcResponse
	_ = json.Unmarshal(w.Body.Bytes(), &resp)
	var result struct {
		Tools []struct {
			Name string `json:"name"`
		} `json:"tools"`
	}
	_ = json.Unmarshal(resp.Result, &result)
	if len(result.Tools) != 1 || result.Tools[0].Name != "node_read" {
		t.Fatal("unauthorized tool discovery")
	}
}
func TestFinalPolicyFenceAndOutbox(t *testing.T) {
	g, raw, v, _, _ := fixture(t, "dispatch-fence")
	l := ledger(t, g, raw, v)
	_, d, _ := v.Verify(raw)
	a, e := l.Claim(context.Background(), g, d, "attempt")
	if e != nil {
		t.Fatal(e)
	}
	r, e := l.Client.Get(context.Background(), l.outbox(g, a.ID))
	if e != nil || len(r.Kvs) != 1 || string(r.Kvs[0].Value) != "claimed_not_dispatched" {
		t.Fatal("claim has no durable dispatch intent")
	}
	next := g
	next.Policy.Epoch++
	if e = l.PublishPolicy(context.Background(), next); e != nil {
		t.Fatal(e)
	}
	if e = l.AuthorizeDispatch(context.Background(), g, d, a.ID); !errors.Is(e, ErrRefused) {
		t.Fatal("postclaim policy change ignored", e)
	}
	if e = l.Finish(context.Background(), g, a, "not_dispatched"); e != nil {
		t.Fatal(e)
	}
	if _, e = l.Claim(context.Background(), g, d, "retry"); !errors.Is(e, ErrRefused) {
		t.Fatal("pre-dispatch failure restored consumed nonce")
	}
}
func TestActualLedgerTransportFailureClosed(t *testing.T) {
	g, raw, v, _, _ := fixture(t, "outage")
	l := ledger(t, g, raw, v)
	_, d, _ := v.Verify(raw)
	_ = l
	client, e := clientv3.New(clientv3.Config{Endpoints: []string{"http://127.0.0.1:1"}, DialTimeout: time.Second})
	if e != nil {
		t.Fatal(e)
	}
	defer client.Close()
	bad := Ledger{Client: client, Prefix: "/unavailable"}
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel()
	if _, e = bad.Claim(ctx, g, d, "attempt"); e == nil {
		t.Fatal("unavailable ledger accepted authority")
	}
}
