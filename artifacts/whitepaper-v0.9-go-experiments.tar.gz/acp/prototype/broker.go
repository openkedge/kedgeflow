package kedgeflow

import (
	"context"
	"crypto/tls"
	"encoding/base64"
	"errors"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// RFC8693Broker is an executable client for a compatible authorization server.
// It does not claim every target (including AWS STS) speaks RFC 8693. A provider
// adapter must map the authorized subject/workload/action to native target scopes.
type RFC8693Broker struct {
	Endpoint, TargetAudience, TargetScope string
	Client                                *http.Client
	WorkloadAssertion                     func(context.Context, string) (string, error)
	// ExchangeTimeout bounds assertion acquisition and the HTTP exchange together.
	// Zero uses five seconds; the parent deadline and grant validity can shorten it.
	// WorkloadAssertion must honor its context for prompt cancellation.
	ExchangeTimeout time.Duration
	// Now is an optional clock, shared with the grant verifier when configured.
	Now func() time.Time
}

func (b *RFC8693Broker) now() time.Time {
	if b.Now != nil {
		return b.Now()
	}
	return time.Now()
}

func NewMTLSHTTPClient(config *tls.Config) (*http.Client, error) {
	if config == nil || config.InsecureSkipVerify || len(config.Certificates) == 0 || config.RootCAs == nil {
		return nil, errors.New("verified mTLS required")
	}
	c := config.Clone()
	c.MinVersion = tls.VersionTLS13
	return &http.Client{Transport: &http.Transport{TLSClientConfig: c}, Timeout: 5 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}, nil
}
func (b *RFC8693Broker) Exchange(ctx context.Context, c VerifiedCall) (TargetCredential, error) {
	u, e := url.Parse(b.Endpoint)
	if e != nil || u.Scheme != "https" || u.User != nil || u.RawQuery != "" || b.Client == nil || b.WorkloadAssertion == nil {
		return TargetCredential{}, errors.New("secure broker configuration required")
	}
	transport, ok := b.Client.Transport.(*http.Transport)
	if !ok || transport.TLSClientConfig == nil || transport.TLSClientConfig.InsecureSkipVerify || len(transport.TLSClientConfig.Certificates) == 0 || transport.TLSClientConfig.RootCAs == nil {
		return TargetCredential{}, errors.New("verified mTLS broker client required")
	}
	if c.GrantDigest == "" || len(c.SignedGrant) == 0 {
		return TargetCredential{}, errors.New("missing signed grant boundary")
	}
	started := b.now()
	grantEnd := time.UnixMilli(c.Grant.ExpiresAt)
	remaining := grantEnd.Sub(started)
	if remaining <= 0 {
		return TargetCredential{}, errors.New("grant expired before token exchange")
	}
	budget := b.ExchangeTimeout
	if budget < 0 {
		return TargetCredential{}, errors.New("invalid token exchange timeout")
	}
	if budget == 0 {
		budget = 5 * time.Second
	}
	if remaining < budget {
		budget = remaining
	}
	exchangeEnd := started.Add(budget)
	ctx, cancel := context.WithTimeout(ctx, budget)
	defer cancel()
	if e = ctx.Err(); e != nil {
		return TargetCredential{}, e
	}
	actor, e := b.WorkloadAssertion(ctx, c.Identity.WorkloadID)
	if e != nil || actor == "" {
		return TargetCredential{}, errors.New("workload assertion unavailable")
	}
	if e = ctx.Err(); e != nil {
		return TargetCredential{}, e
	}
	if !b.now().Before(grantEnd) {
		return TargetCredential{}, errors.New("grant expired during assertion acquisition")
	}
	if !b.now().Before(exchangeEnd) {
		return TargetCredential{}, context.DeadlineExceeded
	}
	v := url.Values{"grant_type": {"urn:ietf:params:oauth:grant-type:token-exchange"}, "subject_token": {c.Identity.AccessToken}, "subject_token_type": {"urn:ietf:params:oauth:token-type:access_token"}, "actor_token": {actor}, "actor_token_type": {"urn:ietf:params:oauth:token-type:jwt"}, "requested_token_type": {"urn:ietf:params:oauth:token-type:access_token"}, "audience": {b.TargetAudience}, "scope": {b.TargetScope}}
	// Named KedgeFlow AS extension, not an RFC 8693 standard parameter. The AS
	// must verify envelope and claimed-attempt correlation before minting.
	v.Set("kedgeflow_grant", base64.RawURLEncoding.EncodeToString(c.SignedGrant))
	v.Set("kedgeflow_grant_digest", c.GrantDigest)
	v.Set("kedgeflow_attempt_id", c.AttemptID)
	// Resource-specific requested scope is configured independently of agent
	// strings. Authorization server policy must enforce the signed grant boundary.
	r, e := http.NewRequestWithContext(ctx, "POST", b.Endpoint, strings.NewReader(v.Encode()))
	if e != nil {
		return TargetCredential{}, e
	}
	r.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	client := *b.Client
	client.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	resp, e := client.Do(r)
	if e != nil {
		return TargetCredential{}, e
	}
	defer resp.Body.Close()
	raw, e := io.ReadAll(io.LimitReader(resp.Body, 65537))
	if e != nil || len(raw) > 65536 || resp.StatusCode != 200 {
		return TargetCredential{}, errors.New("token exchange refused")
	}
	if e = ctx.Err(); e != nil {
		return TargetCredential{}, e
	}
	received := b.now()
	if !received.Before(grantEnd) {
		return TargetCredential{}, errors.New("grant expired during token exchange")
	}
	if !received.Before(exchangeEnd) {
		return TargetCredential{}, context.DeadlineExceeded
	}
	var t struct {
		AccessToken string `json:"access_token"`
		IssuedType  string `json:"issued_token_type"`
		TokenType   string `json:"token_type"`
		ExpiresIn   int    `json:"expires_in"`
		Scope       string `json:"scope"`
	}
	if strictJSON(raw, &t) != nil || t.AccessToken == "" || t.TokenType != "Bearer" || t.IssuedType != "urn:ietf:params:oauth:token-type:access_token" || t.ExpiresIn <= 0 || t.ExpiresIn > 300 || t.Scope != b.TargetScope {
		return TargetCredential{}, errors.New("invalid target token")
	}
	lifetime := time.Duration(t.ExpiresIn) * time.Second
	// expires_in starts when the issuer generates the response, not when this
	// client receives it. Receipt time gives a conservative upper bound for the
	// target's expiry, which must fit the grant; exchange start gives a conservative
	// lower bound for local usability. Do not extend usable life by network latency
	// or clamp a broader bearer token to disguise its excess authority.
	if received.Add(lifetime).After(grantEnd) {
		return TargetCredential{}, errors.New("broker credential broader than grant lifetime")
	}
	expires := started.Add(lifetime)
	if e = ctx.Err(); e != nil {
		return TargetCredential{}, e
	}
	usableAt := b.now()
	if !usableAt.Before(exchangeEnd) {
		return TargetCredential{}, context.DeadlineExceeded
	}
	if !usableAt.Before(expires) {
		return TargetCredential{}, errors.New("broker credential lifetime consumed by exchange")
	}
	return TargetCredential{t.AccessToken, expires, b.TargetAudience}, nil
}
