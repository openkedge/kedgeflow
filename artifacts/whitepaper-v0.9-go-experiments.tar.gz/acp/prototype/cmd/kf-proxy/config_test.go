package main

import "testing"

func TestClosedGatewayConfiguration(t *testing.T) {
	valid := []byte(`{"listen":"127.0.0.1:8443","external_url":"https://localhost:8443/mcp"}`)
	c, err := decodeConfig(valid)
	if err != nil || c.ExternalURL != "https://localhost:8443/mcp" || c.Listen != "127.0.0.1:8443" {
		t.Fatalf("config=%+v err=%v", c, err)
	}
	for _, raw := range []string{
		`{"external_url":"https://localhost:8443/mcp","allowed_origins":["*"]}`,
		`{"external_url":"https://localhost:8443/mcp","external_url":"https://attacker.example/mcp"}`,
		`{"external_url":"https://localhost:8443/mcp","EXTERNAL_URL":"https://attacker.example/mcp"}`,
		`{"tools":[{"name":"first","name":"second"}]}`,
		`{"external_url":"https://localhost:8443/mcp"} {"external_url":"https://attacker.example/mcp"}`,
		`{"external_url":"https://localhost:8443/mcp"} trailing`,
		`[]`,
		`null`,
	} {
		if _, err := decodeConfig([]byte(raw)); err == nil {
			t.Fatalf("accepted ambiguous or open configuration: %s", raw)
		}
	}
}
