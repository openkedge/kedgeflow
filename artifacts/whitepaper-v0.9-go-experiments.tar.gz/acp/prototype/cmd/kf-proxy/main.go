package main

import (
	"context"
	"crypto/ed25519"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"log/slog"
	"net/http"
	"os"
	"reflect"
	"strings"
	"time"

	clientv3 "go.etcd.io/etcd/client/v3"
	kf "kedgeflow.local/prototype"
)

type config struct {
	Listen                string              `json:"listen"`
	ExternalURL           string              `json:"external_url"`
	Certificate           string              `json:"certificate"`
	PrivateKey            string              `json:"private_key"`
	WorkloadCA            string              `json:"workload_ca"`
	GrantKeyID            string              `json:"grant_key_id"`
	GrantPublicKey        string              `json:"grant_public_key_base64"`
	OIDCIssuer            string              `json:"oidc_issuer"`
	OIDCPublicKey         string              `json:"oidc_public_key_base64"`
	EtcdEndpoints         []string            `json:"etcd_endpoints"`
	EtcdPrefix            string              `json:"etcd_prefix"`
	EtcdCA                string              `json:"etcd_ca"`
	BrokerEndpoint        string              `json:"broker_endpoint"`
	BrokerCA              string              `json:"broker_ca"`
	GrantResolverEndpoint string              `json:"grant_resolver_endpoint"`
	GrantResolverCA       string              `json:"grant_resolver_ca"`
	TargetAudience        string              `json:"target_audience"`
	TargetScope           string              `json:"target_scope"`
	ActorWorkload         string              `json:"actor_workload"`
	ActorTokenFile        string              `json:"actor_token_file"`
	TargetURL             string              `json:"target_url"`
	TargetCA              string              `json:"target_ca"`
	ReadTokenFile         string              `json:"read_token_file"`
	Tools                 []kf.ToolDescriptor `json:"tools"`
}

func key(s string) ed25519.PublicKey {
	b, e := base64.StdEncoding.DecodeString(s)
	if e != nil || len(b) != 32 {
		log.Fatal("public key must be 32-byte Ed25519 base64")
	}
	return b
}
func ca(path string) *x509.CertPool {
	b, e := os.ReadFile(path)
	if e != nil {
		log.Fatal(e)
	}
	p := x509.NewCertPool()
	if !p.AppendCertsFromPEM(b) {
		log.Fatal("invalid CA")
	}
	return p
}
func readSecret(path string) string {
	b, e := os.ReadFile(path)
	if e != nil {
		log.Fatal(e)
	}
	return strings.TrimSpace(string(b))
}

func decodeConfig(raw []byte) (config, error) {
	var c config
	// The same I-JSON canonicalizer used for contracts rejects duplicate object
	// keys, invalid UTF-8 and ambiguous JSON before the closed typed decoder.
	canonical, err := kf.Canonical(raw)
	if err != nil {
		return c, fmt.Errorf("invalid gateway configuration JSON: %w", err)
	}
	if len(canonical) == 0 || canonical[0] != '{' {
		return c, fmt.Errorf("gateway configuration must contain one JSON object")
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(canonical, &fields); err != nil {
		return c, err
	}
	allowed := map[string]bool{}
	typ := reflect.TypeOf(c)
	for i := 0; i < typ.NumField(); i++ {
		allowed[typ.Field(i).Tag.Get("json")] = true
	}
	for name := range fields {
		if !allowed[name] {
			return c, fmt.Errorf("unknown gateway configuration field %q", name)
		}
	}
	d := json.NewDecoder(strings.NewReader(string(raw)))
	d.DisallowUnknownFields()
	if err := d.Decode(&c); err != nil {
		return c, err
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return c, fmt.Errorf("gateway configuration must contain one JSON object")
	}
	return c, nil
}

func main() {
	path := flag.String("config", "", "trusted gateway configuration JSON")
	flag.Parse()
	if *path == "" {
		flag.Usage()
		os.Exit(2)
	}
	b, e := os.ReadFile(*path)
	if e != nil {
		log.Fatal(e)
	}
	c, e := decodeConfig(b)
	if e != nil {
		log.Fatal(e)
	}
	if !strings.HasPrefix(c.ExternalURL, "https://") || !strings.HasPrefix(c.TargetURL, "https://") || c.EtcdPrefix == "" {
		log.Fatal("HTTPS and dedicated etcd prefix required")
	}
	endpoint, e := kf.NewEndpointPolicy(c.ExternalURL)
	if e != nil {
		log.Fatal(e)
	}
	for _, u := range c.EtcdEndpoints {
		if !strings.HasPrefix(u, "https://") {
			log.Fatal("etcd mTLS HTTPS endpoint required")
		}
	}
	cert, e := tls.LoadX509KeyPair(c.Certificate, c.PrivateKey)
	if e != nil {
		log.Fatal(e)
	}
	makeTLS := func(path string) *tls.Config {
		return &tls.Config{MinVersion: tls.VersionTLS13, RootCAs: ca(path), Certificates: []tls.Certificate{cert}}
	}
	ledgerClient, e := clientv3.New(clientv3.Config{Endpoints: c.EtcdEndpoints, TLS: makeTLS(c.EtcdCA), DialTimeout: 5 * time.Second})
	if e != nil {
		log.Fatal(e)
	}
	defer ledgerClient.Close()
	brokerClient, e := kf.NewMTLSHTTPClient(makeTLS(c.BrokerCA))
	if e != nil {
		log.Fatal(e)
	}
	targetClient, e := kf.NewMTLSHTTPClient(makeTLS(c.TargetCA))
	if e != nil {
		log.Fatal(e)
	}
	broker := &kf.RFC8693Broker{Endpoint: c.BrokerEndpoint, TargetAudience: c.TargetAudience, TargetScope: c.TargetScope, Client: brokerClient, WorkloadAssertion: func(_ context.Context, workload string) (string, error) {
		if workload != c.ActorWorkload {
			return "", fmt.Errorf("actor assertion scope mismatch")
		}
		return readSecret(c.ActorTokenFile), nil
	}}
	tools := map[string]kf.ToolDescriptor{}
	for _, tool := range c.Tools {
		if _, exists := tools[tool.Name]; exists {
			log.Fatal("duplicate tool descriptor")
		}
		tools[tool.Name] = tool
	}
	p := &kf.Proxy{Verifier: kf.GrantVerifier{Keys: map[string]ed25519.PublicKey{c.GrantKeyID: key(c.GrantPublicKey)}, Audience: c.ExternalURL}, Ledger: kf.Ledger{Client: ledgerClient, Prefix: c.EtcdPrefix}, Auth: &kf.DualAuthenticator{Issuer: c.OIDCIssuer, Audience: c.ExternalURL, ExternalURL: c.ExternalURL, IssuerKey: key(c.OIDCPublicKey)}, Broker: broker, Adapter: &kf.HTTPAdapter{Client: targetClient, UpstreamURL: c.TargetURL, Audience: c.TargetAudience, ReadToken: readSecret(c.ReadTokenFile)}, Tools: tools, Logger: slog.Default(), Timeout: 5 * time.Second}
	if (c.GrantResolverEndpoint == "") != (c.GrantResolverCA == "") {
		log.Fatal("grant resolver endpoint and CA must be configured together")
	}
	if c.GrantResolverEndpoint != "" {
		resolverClient, err := kf.NewMTLSHTTPClient(makeTLS(c.GrantResolverCA))
		if err != nil {
			log.Fatal(err)
		}
		p.GrantResolver, err = kf.NewHTTPSGrantResolver(c.GrantResolverEndpoint, resolverClient)
		if err != nil {
			log.Fatal(err)
		}
	}
	server := &http.Server{Addr: c.Listen, Handler: endpoint.Wrap(p), ReadHeaderTimeout: 5 * time.Second, ReadTimeout: 10 * time.Second, WriteTimeout: 10 * time.Second, IdleTimeout: 30 * time.Second, TLSConfig: &tls.Config{MinVersion: tls.VersionTLS13, ClientAuth: tls.RequireAndVerifyClientCert, ClientCAs: ca(c.WorkloadCA), Certificates: []tls.Certificate{cert}}}
	log.Printf("governed MCP prototype listening on %s", c.Listen)
	log.Fatal(server.ListenAndServeTLS("", ""))
}
