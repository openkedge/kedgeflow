package kedgeflow

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"sync/atomic"
	"testing"
	"time"
)

type expiryExchangeFunc func(context.Context, VerifiedCall) (TargetCredential, error)

func (f expiryExchangeFunc) Exchange(ctx context.Context, c VerifiedCall) (TargetCredential, error) {
	return f(ctx, c)
}

type expiryDispatchSpy struct{ calls atomic.Int64 }

func (s *expiryDispatchSpy) Dispatch(context.Context, VerifiedCall, TargetCredential) (json.RawMessage, string, error) {
	s.calls.Add(1)
	return json.RawMessage(`{"resultType":"complete"}`), "committed", nil
}
func (*expiryDispatchSpy) Read(context.Context, Request, Identity) (json.RawMessage, error) {
	return nil, errors.New("unexpected read")
}

func TestProxyExchangeExpiryConsumesClaim(t *testing.T) {
	for _, name := range []string{"rfc8693_late_response", "alternate_broker_late_response"} {
		t.Run(name, func(t *testing.T) {
			g, raw, v, id, td := fixture(t, "exchange-expiry-"+name)
			clock := newBrokerTestClock(time.Now())
			v.Now = clock.Now
			l := ledger(t, g, raw, v)
			_, gd, e := v.Verify(raw)
			if e != nil {
				t.Fatal(e)
			}
			var exchanges atomic.Int64
			var broker CredentialBroker
			if name == "rfc8693_late_response" {
				broker = testRFC8693Broker(t, http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
					exchanges.Add(1)
					clock.millis.Store(g.ExpiresAt)
					_, _ = w.Write([]byte(brokerTestTokenResponse))
				}), clock.Now)
			} else {
				broker = expiryExchangeFunc(func(context.Context, VerifiedCall) (TargetCredential, error) {
					exchanges.Add(1)
					clock.millis.Store(g.ExpiresAt)
					// An alternate broker can return a credential that remains
					// usable on the local wall clock; the proxy must independently
					// recheck grant validity after the exchange has consumed it.
					return TargetCredential{"target-token", time.Now().Add(time.Minute), "mock-target"}, nil
				})
			}
			adapter := &expiryDispatchSpy{}
			p := &Proxy{Verifier: v, Ledger: l, Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: broker, Adapter: adapter, Tools: map[string]ToolDescriptor{"node_drain": td}}
			body := requestBody("node_drain", `{"node":"node-a","expected_version":1}`)
			w := call(p, body, HeaderGrant(raw))
			message := errorMessage(w)
			if message != "CREDENTIAL_UNAVAILABLE" && message != "GRANT_EXPIRED_AFTER_CLAIM" {
				t.Fatal("late exchange did not refuse dispatch", w.Body.String())
			}
			var result struct {
				Error struct {
					Data struct {
						AttemptID string `json:"attempt_id"`
					} `json:"data"`
				} `json:"error"`
			}
			if e := json.Unmarshal(w.Body.Bytes(), &result); e != nil || result.Error.Data.AttemptID == "" {
				t.Fatal("missing claimed attempt correlation", w.Body.String(), e)
			}
			attemptID := result.Error.Data.AttemptID
			attempt, e := l.Status(context.Background(), g, attemptID)
			if e != nil || attempt.Status != "not_dispatched" {
				t.Fatal("late exchange left wrong attempt status", attempt, e)
			}
			if _, e := l.Claim(context.Background(), g, gd, "replayed-late-exchange"); !errors.Is(e, ErrNonceConsumed) {
				t.Fatal("expiry restored claimed allowance", e)
			}
			next := g
			next.GID += "-replacement"
			next.Nonce += "-replacement"
			next.RootGeneration++
			next.Fence++
			if e := l.Replace(context.Background(), g, next, "replacement-digest"); !errors.Is(e, ErrRefused) {
				t.Fatal("expiry permitted claimed-root replacement", e)
			}
			_ = call(p, body, HeaderGrant(raw))
			if exchanges.Load() != 1 || adapter.calls.Load() != 0 {
				t.Fatal("late exchange retried or dispatched", exchanges.Load(), adapter.calls.Load())
			}
			t.Log("expired exchange retained nonce/root allowance; not_dispatched outcome; no retry or privileged dispatch")
		})
	}
}

func TestProxyExpiryAtFinalLedgerGateRetainsConsumption(t *testing.T) {
	g, raw, v, id, td := fixture(t, "final-gate-expiry")
	l := ledger(t, g, raw, v)
	_, gd, err := v.Verify(raw)
	if err != nil {
		t.Fatal(err)
	}
	var checks atomic.Int64
	v.Now = func() time.Time {
		// Initial verification and the postexchange check pass. At the check
		// following the actual ledger authorization, signed validity is gone.
		if checks.Add(1) >= 3 {
			return time.UnixMilli(g.ExpiresAt)
		}
		return time.Now()
	}
	adapter := &expiryDispatchSpy{}
	p := &Proxy{Verifier: v, Ledger: l, Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: &testBroker{}, Adapter: adapter, Tools: map[string]ToolDescriptor{"node_drain": td}}
	w := call(p, requestBody("node_drain", `{"node":"node-a","expected_version":1}`), HeaderGrant(raw))
	if errorMessage(w) != "DISPATCH_VALIDITY_EXPIRED" || adapter.calls.Load() != 0 {
		t.Fatal("final-gate expiry dispatched", w.Body.String())
	}
	var result struct {
		Error struct {
			Data struct {
				AttemptID string `json:"attempt_id"`
			} `json:"data"`
		} `json:"error"`
	}
	if err := json.Unmarshal(w.Body.Bytes(), &result); err != nil || result.Error.Data.AttemptID == "" {
		t.Fatal("missing final-gate attempt", err)
	}
	attempt, err := l.Status(context.Background(), g, result.Error.Data.AttemptID)
	if err != nil || attempt.Status != "not_dispatched" {
		t.Fatal("wrong final-gate state", attempt, err)
	}
	if _, err := l.Claim(context.Background(), g, gd, "final-gate-retry"); !errors.Is(err, ErrNonceConsumed) {
		t.Fatal("final-gate expiry refunded allowance", err)
	}
	t.Log("FINAL_EXPIRY no target dispatch after final ledger round trip; consumed allowance retained")
}
