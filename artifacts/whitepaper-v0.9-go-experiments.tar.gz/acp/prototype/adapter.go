package kedgeflow

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"
)

// HTTPAdapter deliberately constructs a fresh request: it never forwards inbound
// authorization, cookies, grant headers, tracing baggage or client routing hints.
// UpstreamURL is trusted configuration. The prototype mock implements the CAS
// contract; declaring it does not make a Kubernetes drain atomic.
type HTTPAdapter struct {
	Client      *http.Client
	UpstreamURL string
	Audience    string
	ReadToken   string
}

func (a *HTTPAdapter) post(ctx context.Context, req Request, token string) (json.RawMessage, string, error) {
	u, e := url.Parse(a.UpstreamURL)
	if e != nil || u.Host == "" || u.User != nil || u.RawQuery != "" {
		return nil, "unknown", errors.New("invalid fixed upstream")
	}
	b, e := json.Marshal(req)
	if e != nil {
		return nil, "unknown", e
	}
	r, e := http.NewRequestWithContext(ctx, "POST", a.UpstreamURL, bytes.NewReader(b))
	if e != nil {
		return nil, "unknown", e
	}
	r.Header.Set("Content-Type", "application/json")
	r.Header.Set("Authorization", "Bearer "+token)
	resp, e := a.Client.Do(r)
	if e != nil {
		return nil, "unknown", e
	}
	defer resp.Body.Close()
	raw, e := io.ReadAll(io.LimitReader(resp.Body, 1<<20))
	if e != nil || resp.StatusCode != 200 {
		return nil, "unknown", errors.New("ambiguous target response")
	}
	var v struct {
		JSONRPC string          `json:"jsonrpc"`
		ID      json.RawMessage `json:"id"`
		Result  json.RawMessage `json:"result"`
		Error   *rpcError       `json:"error"`
	}
	if strictJSON(raw, &v) != nil || v.JSONRPC != "2.0" || !equalCanonical(v.ID, req.ID) {
		return nil, "unknown", errors.New("invalid correlated target response")
	}
	if v.Error != nil {
		if v.Error.Message == "STATE_GUARD_VIOLATION" {
			return nil, "state_guard_violation", nil
		}
		return nil, "unknown", errors.New("target failed without definitive effect contract")
	}
	if len(v.Result) == 0 {
		return nil, "unknown", errors.New("empty result")
	}
	var toolResult struct {
		ResultType string `json:"resultType"`
		IsError    bool   `json:"isError"`
	}
	if json.Unmarshal(v.Result, &toolResult) != nil || toolResult.ResultType != "complete" || toolResult.IsError {
		return nil, "unknown", errors.New("nonterminal or tool error result is not proof of no effect")
	}
	return v.Result, "complete", nil
}
func (a *HTTPAdapter) Dispatch(ctx context.Context, c VerifiedCall, credential TargetCredential) (json.RawMessage, string, error) {
	if credential.Audience != a.Audience || !time.Now().Before(credential.ExpiresAt) {
		return nil, "unknown", errors.New("credential scope/expiry")
	}
	var args map[string]json.RawMessage
	if json.Unmarshal(c.Request.Params.Arguments, &args) != nil {
		return nil, "unknown", errors.New("invalid arguments")
	}
	args[c.Descriptor.FenceParameter] = json.RawMessage(value(c.Grant.Fence))
	args["kf_attempt_id"] = json.RawMessage(value(c.AttemptID))
	args["kf_grant_digest"] = json.RawMessage(value(c.GrantDigest))
	args["kf_resource_incarnation"] = json.RawMessage(value(c.Grant.Resources[0].Incarnation))
	b, e := json.Marshal(args)
	if e != nil {
		return nil, "unknown", e
	}
	c.Request.Params.Arguments = b
	// Remove capability metadata from privileged dispatch. It is an inbound
	// negotiation artifact and cannot influence target routing/authority.
	c.Request.Params.Meta = map[string]json.RawMessage{"io.modelcontextprotocol/protocolVersion": json.RawMessage(value(ProtocolVersion)), "io.modelcontextprotocol/clientCapabilities": json.RawMessage("{}")}
	result, status, e := a.post(ctx, c.Request, credential.Token)
	if e != nil || status == "state_guard_violation" {
		return result, status, e
	}
	var envelope struct {
		StructuredContent struct {
			Receipt MockTerminalReceipt `json:"kedgeflow_terminal_receipt"`
		} `json:"structuredContent"`
	}
	if json.Unmarshal(result, &envelope) != nil {
		return nil, "unknown", errors.New("invalid target receipt")
	}
	receipt := envelope.StructuredContent.Receipt
	if receipt.AttemptID != c.AttemptID || receipt.GrantDigest != c.GrantDigest || receipt.Resource != c.Grant.Resources[0] || receipt.Fence != c.Grant.Fence || receipt.Status != "committed" {
		return nil, "unknown", errors.New("missing or uncorrelated target terminal receipt")
	}
	return result, "committed", nil
}

// This typed mock-target contract is not a generic MCP success condition or the
// signed KedgeFlow Attempt Receipt. Production targets need their own adapter.
type MockTerminalReceipt struct {
	AttemptID   string   `json:"attempt_id"`
	GrantDigest string   `json:"grant_digest"`
	Resource    Resource `json:"resource"`
	Fence       uint64   `json:"fence"`
	Status      string   `json:"status"`
	PostVersion uint64   `json:"post_version"`
}

func (a *HTTPAdapter) Read(ctx context.Context, r Request, _ Identity) (json.RawMessage, error) {
	if strings.TrimSpace(a.ReadToken) == "" {
		return nil, errors.New("read credential not configured")
	}
	result, _, e := a.post(ctx, r, a.ReadToken)
	return result, e
}
