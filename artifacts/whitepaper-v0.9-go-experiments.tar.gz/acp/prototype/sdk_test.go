package kedgeflow

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"
)

func TestOfficialMCPSDKInterop(t *testing.T) {
	node, e := exec.LookPath("node")
	if e != nil {
		if os.Getenv("KF_REQUIRE_SDK") == "1" {
			t.Fatal("Node runtime required")
		}
		t.Skip("Node runtime unavailable")
	}
	if _, e = os.Stat("sdk/node_modules/@modelcontextprotocol/client/package.json"); e != nil {
		if os.Getenv("KF_REQUIRE_SDK") == "1" {
			t.Fatal("run npm ci --ignore-scripts in sdk first")
		}
		t.Skip("optional official SDK dependencies absent; run make sdk-test")
	}
	g, raw, v, id, td := fixture(t, "official-sdk")
	l := ledger(t, g, raw, v)
	target := &mockTarget{version: 1}
	up := httptest.NewServer(target)
	defer up.Close()
	broker := &testBroker{}
	p := &Proxy{Verifier: v, Ledger: l, Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: broker, Adapter: &HTTPAdapter{up.Client(), up.URL, "mock-target", "target-read-token"}, Tools: map[string]ToolDescriptor{"node_drain": td, "node_read": {Name: "node_read", ReadOnly: true, RequiredScope: "read"}}}
	gateway := httptest.NewServer(p)
	defer gateway.Close()
	_, gd, e := v.Verify(raw)
	if e != nil {
		t.Fatal(e)
	}
	fixturePath := filepath.Join(t.TempDir(), "sdk-fixture.json")
	b, _ := json.Marshal(map[string]string{"endpoint": gateway.URL, "grant": HeaderGrant(raw), "grant_digest": gd})
	if e = os.WriteFile(fixturePath, b, 0600); e != nil {
		t.Fatal(e)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Second)
	defer cancel()
	command := exec.CommandContext(ctx, node, "sdk/interop.mjs", fixturePath)
	out, e := command.CombinedOutput()
	_ = writeResult("official-sdk-client.json", out)
	if e != nil {
		t.Fatalf("official SDK interop failed: %v\n%s", e, out)
	}
	var report struct {
		Status  string `json:"status"`
		Version string `json:"version"`
	}
	if json.Unmarshal(out, &report) != nil || report.Status != "PASS" || report.Version != "2.3.0" {
		t.Fatalf("invalid SDK report: %s", out)
	}
	target.mu.Lock()
	effects, leaked := target.effects, target.leaked
	target.mu.Unlock()
	if effects != 1 || leaked || broker.calls.Load() != 1 {
		t.Fatalf("SDK path effects=%d minted=%d leaked=%t", effects, broker.calls.Load(), leaked)
	}
	t.Logf("OFFICIAL_SDK @modelcontextprotocol/client=%s pin=2026-07-28 discover+tools/list+missing-grant(-32001)+signed-grant-resubmit+replay(-32007) effects=1 minted=1\n%s", report.Version, out)
}
