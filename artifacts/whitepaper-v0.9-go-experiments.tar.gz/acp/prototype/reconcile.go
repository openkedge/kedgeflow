package kedgeflow

import (
	"context"
	"errors"
	clientv3 "go.etcd.io/etcd/client/v3"
)

type AuthoritativeObservation struct{ AttemptID, RootID, GrantDigest, Status, TargetReference string }
type OutcomeQuerier interface {
	Query(context.Context, string) (AuthoritativeObservation, error)
}

// Reconcile is an Outcome Service boundary, deliberately without a Dispatch
// interface. A target adapter must authenticate Query and verify its reference.
// An authoritative committed observation can close Unknown; absent/missing state
// remains Unknown. No nonce, root or reservation is released here.
func (l Ledger) Reconcile(ctx context.Context, g Grant, id string, q OutcomeQuerier) (Attempt, error) {
	a, e := l.Status(ctx, g, id)
	if e != nil {
		return a, e
	}
	if a.Status != "unknown" {
		return a, errors.New("only unknown attempts need reconciliation")
	}
	o, e := q.Query(ctx, id)
	if e != nil {
		return a, e
	}
	if o.AttemptID != a.ID || o.RootID != a.RootID || o.GrantDigest != a.GrantDigest || o.TargetReference == "" {
		return a, errors.New("uncorrelated target observation")
	}
	if o.Status != "committed" {
		return a, nil
	}
	k := l.root(g) + "/attempts/" + keyPart(id)
	before := value(a)
	a.Status = "committed"
	t, e := l.Client.Txn(ctx).If(clientv3.Compare(clientv3.Value(k), "=", before)).Then(clientv3.OpPut(k, value(a)), clientv3.OpPut(k+"/observation", value(o)), clientv3.OpPut(l.outbox(g, id), "committed")).Commit()
	if e != nil {
		return a, e
	}
	if !t.Succeeded {
		return a, ErrRefused
	}
	return a, nil
}
