package kedgeflow

import (
	"encoding/json"
	"testing"
	"time"
)

func TestUnsupportedProfilesFailClosed(t *testing.T) {
	for _, name := range []string{"commit_bound", "saga", "delegated", "expired", "future", "wrong_audience", "unsafe_epoch"} {
		t.Run(name, func(t *testing.T) {
			g, _, v, _, _, key := fixtureWithKey(t, "profile-"+name)
			switch name {
			case "commit_bound":
				g.CompletionMode = "commit_bound"
			case "saga":
				g.SagaBudget = json.RawMessage(`{"root_id":"saga"}`)
			case "delegated":
				s := "1111111111111111111111111111111111111111111111111111111111111111"
				g.ParentGrantDigest = &s
			case "expired":
				g.ExpiresAt = time.Now().Add(-time.Second).UnixMilli()
			case "future":
				g.ValidFrom = time.Now().Add(time.Minute).UnixMilli()
			case "wrong_audience":
				g.Audience = "https://other.test/mcp"
			case "unsafe_epoch":
				g.RootGeneration = 9007199254740992
			}
			b, e := SignGrant(g, "issuer-test", key)
			if e != nil {
				t.Fatal(e)
			}
			if _, _, e = v.Verify(b); e == nil {
				t.Fatal("unsupported profile accepted")
			}
		})
	}
}
