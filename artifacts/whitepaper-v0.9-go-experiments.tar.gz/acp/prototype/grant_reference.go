package kedgeflow

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"net/url"
	"time"
)

// This optional transport resolves an immutable complete envelope. It grants no
// authority of its own and never changes the KF-JSON-0.2 signing contract.
const GrantReferenceProfile = "KF-GRANT-REF-0.1"
const GrantReferenceHeader = "Mcp-KedgeFlow-Grant-Ref"
const MaxInlineGrantHeader = 6 * 1024
const MaxResolvedGrantBytes = 64 * 1024

type GrantResolver interface {
	Resolve(context.Context, Identity, string) ([]byte, error)
}

// GrantReferenceQuery is sent only to an operator-pinned mTLS service. The
// service must authorize the authenticated gateway and the requested identity
// scope before disclosing the original envelope. No caller tokens are relayed.
type GrantReferenceQuery struct {
	GrantDigest      string  `json:"grant_digest"`
	Subject          Subject `json:"subject"`
	WorkloadID       string  `json:"workload_id"`
	DPoPJKT          string  `json:"dpop_jkt"`
	DelegationDigest string  `json:"delegation_digest"`
}

type HTTPSGrantResolver struct {
	endpoint string
	client   *http.Client
}

func NewHTTPSGrantResolver(endpoint string, client *http.Client) (*HTTPSGrantResolver, error) {
	u, err := url.Parse(endpoint)
	if err != nil || u.Scheme != "https" || u.Host == "" || u.User != nil || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" || u.Opaque != "" {
		return nil, errors.New("grant resolver requires a pinned HTTPS endpoint without userinfo, query or fragment")
	}
	if client == nil || client.Timeout <= 0 {
		return nil, errors.New("grant resolver requires a bounded mTLS client")
	}
	t, ok := client.Transport.(*http.Transport)
	if !ok || t.TLSClientConfig == nil || t.TLSClientConfig.InsecureSkipVerify || t.TLSClientConfig.RootCAs == nil || len(t.TLSClientConfig.Certificates) == 0 || t.TLSClientConfig.MinVersion < tls.VersionTLS13 {
		return nil, errors.New("grant resolver requires verified TLS 1.3 and a client certificate")
	}
	// Reuse the connection pool, while independently prohibiting redirects.
	c := *client
	c.CheckRedirect = func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }
	return &HTTPSGrantResolver{endpoint: endpoint, client: &c}, nil
}

func validGrantReference(digest string) bool {
	if len(digest) != 64 {
		return false
	}
	for _, c := range digest {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

func (s *HTTPSGrantResolver) Resolve(ctx context.Context, id Identity, digest string) ([]byte, error) {
	if !validGrantReference(digest) || id.Subject.Iss == "" || id.Subject.Sub == "" || id.WorkloadID == "" || id.DPoPJKT == "" || id.DelegationDigest == "" {
		return nil, errors.New("invalid reference or requester scope")
	}
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	body, err := json.Marshal(GrantReferenceQuery{digest, id.Subject, id.WorkloadID, id.DPoPJKT, id.DelegationDigest})
	if err != nil {
		return nil, err
	}
	r, err := http.NewRequestWithContext(ctx, http.MethodPost, s.endpoint, bytes.NewReader(body))
	if err != nil {
		return nil, err
	}
	r.Header.Set("Content-Type", "application/json")
	r.Header.Set("Accept", "application/json")
	// Do not request compressed responses that conceal their expanded size.
	r.Header.Set("Accept-Encoding", "identity")
	resp, err := s.client.Do(r)
	if err != nil {
		return nil, errors.New("grant reference lookup failed")
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK || resp.Header.Get("Content-Encoding") != "" {
		return nil, errors.New("grant reference unavailable")
	}
	raw, err := io.ReadAll(io.LimitReader(resp.Body, MaxResolvedGrantBytes+1))
	if err != nil || len(raw) == 0 || len(raw) > MaxResolvedGrantBytes || ctx.Err() != nil {
		return nil, errors.New("grant reference response exceeds lookup bounds")
	}
	return raw, nil
}

func referenceNegotiated(m map[string]json.RawMessage) bool {
	var caps struct {
		Extensions map[string]json.RawMessage `json:"extensions"`
	}
	if json.Unmarshal(m["io.modelcontextprotocol/clientCapabilities"], &caps) != nil {
		return false
	}
	var binding struct {
		Profile string `json:"profile"`
	}
	return strictJSON(caps.Extensions["io.kedgeflow/grant-reference"], &binding) == nil && binding.Profile == GrantReferenceProfile
}
