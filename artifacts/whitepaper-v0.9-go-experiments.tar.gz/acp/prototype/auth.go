package kedgeflow

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net/http"
	"strings"
	"sync"
	"time"
)

// DualAuthenticator is a deliberately narrow OAuth access-token profile:
// pinned Ed25519 issuer, string audience, DPoP Ed25519 key and verified SPIFFE
// URI SAN. It accepts access tokens, not OIDC ID tokens as delegation authority.
// Deployment must ensure the issuer actually granted OBO/tool permissions.
type DualAuthenticator struct {
	Issuer, Audience, ExternalURL string
	IssuerKey                     ed25519.PublicKey
	mu                            sync.Mutex
	seen                          map[string]time.Time
}
type jwtHeader struct {
	Alg string          `json:"alg"`
	Typ string          `json:"typ"`
	Kid string          `json:"kid,omitempty"`
	JWK json.RawMessage `json:"jwk,omitempty"`
}
type accessClaims struct {
	ISS   string `json:"iss"`
	SUB   string `json:"sub"`
	AUD   string `json:"aud"`
	EXP   int64  `json:"exp"`
	IAT   int64  `json:"iat"`
	Scope string `json:"scope"`
	CNF   struct {
		JKT string `json:"jkt"`
	} `json:"cnf"`
}
type dpopClaims struct {
	JTI string `json:"jti"`
	HTM string `json:"htm"`
	HTU string `json:"htu"`
	IAT int64  `json:"iat"`
	ATH string `json:"ath"`
}
type edJWK struct {
	KTY string `json:"kty"`
	CRV string `json:"crv"`
	X   string `json:"x"`
}

func decodeJWT(token string) (jwtHeader, []byte, []byte, []byte, error) {
	var h jwtHeader
	parts := strings.Split(token, ".")
	if len(parts) != 3 {
		return h, nil, nil, nil, errors.New("bad JWT")
	}
	hb, e := base64.RawURLEncoding.DecodeString(parts[0])
	if e != nil {
		return h, nil, nil, nil, e
	}
	if e = strictJSON(hb, &h); e != nil {
		return h, nil, nil, nil, e
	}
	p, e := base64.RawURLEncoding.DecodeString(parts[1])
	if e != nil {
		return h, nil, nil, nil, e
	}
	s, e := base64.RawURLEncoding.DecodeString(parts[2])
	return h, p, []byte(parts[0] + "." + parts[1]), s, e
}
func (a *DualAuthenticator) Authenticate(r *http.Request) (Identity, error) {
	fail := func() (Identity, error) { return Identity{}, errors.New("dual identity verification failed") }
	if r.TLS == nil || len(r.TLS.VerifiedChains) == 0 || len(r.TLS.PeerCertificates) == 0 {
		return fail()
	}
	workload := ""
	for _, uri := range r.TLS.PeerCertificates[0].URIs {
		if uri.Scheme == "spiffe" && uri.Host != "" && uri.RawQuery == "" && uri.Fragment == "" {
			if workload != "" {
				return fail()
			}
			workload = uri.String()
		}
	}
	if workload == "" || len(r.Header.Values("Authorization")) != 1 || len(r.Header.Values("DPoP")) != 1 {
		return fail()
	}
	auth := strings.Split(r.Header.Get("Authorization"), " ")
	if len(auth) != 2 || auth[0] != "DPoP" {
		return fail()
	}
	token := auth[1]
	h, p, input, s, e := decodeJWT(token)
	if e != nil || h.Alg != "EdDSA" || h.Typ != "at+jwt" || len(h.JWK) != 0 || !ed25519.Verify(a.IssuerKey, input, s) {
		return fail()
	}
	var ac accessClaims
	if strictJSON(p, &ac) != nil {
		return fail()
	}
	now := time.Now().Unix()
	if ac.ISS != a.Issuer || ac.AUD != a.Audience || ac.SUB == "" || ac.EXP <= now || ac.IAT > now+5 || ac.CNF.JKT == "" {
		return fail()
	}
	dh, dp, di, ds, e := decodeJWT(r.Header.Get("DPoP"))
	if e != nil || dh.Alg != "EdDSA" || dh.Typ != "dpop+jwt" {
		return fail()
	}
	var jwk edJWK
	if strictJSON(dh.JWK, &jwk) != nil || jwk.KTY != "OKP" || jwk.CRV != "Ed25519" {
		return fail()
	}
	pk, e := base64.RawURLEncoding.DecodeString(jwk.X)
	if e != nil || len(pk) != ed25519.PublicKeySize || !ed25519.Verify(pk, di, ds) {
		return fail()
	}
	jwkBytes, e := marshalCanonical(jwk)
	if e != nil {
		return fail()
	}
	jktHash := sha256.Sum256(jwkBytes)
	jkt := base64.RawURLEncoding.EncodeToString(jktHash[:])
	if ac.CNF.JKT != jkt {
		return fail()
	}
	var dc dpopClaims
	if strictJSON(dp, &dc) != nil || dc.JTI == "" || dc.HTM != r.Method || dc.HTU != a.ExternalURL || dc.IAT < now-60 || dc.IAT > now+5 {
		return fail()
	}
	ath := sha256.Sum256([]byte(token))
	if dc.ATH != base64.RawURLEncoding.EncodeToString(ath[:]) {
		return fail()
	}
	// Local anti-replay only; replicas need a shared DPoP replay store or nonce
	// profile. The grant Claim remains globally single-use independently.
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.seen == nil {
		a.seen = map[string]time.Time{}
	}
	for k, t := range a.seen {
		if t.Before(time.Now()) {
			delete(a.seen, k)
		}
	}
	rk := jkt + ":" + dc.JTI
	if _, ok := a.seen[rk]; ok {
		return fail()
	}
	a.seen[rk] = time.Now().Add(65 * time.Second)
	scopes := map[string]bool{}
	for _, scope := range strings.Fields(ac.Scope) {
		scopes[scope] = true
	}
	tokenHash := sha256.Sum256([]byte(token))
	scopeList := strings.Fields(ac.Scope)
	delegation := map[string]any{"access_token_digest": hex.EncodeToString(tokenHash[:]), "dpop_jkt": jkt, "authorization_server": a.Issuer, "token_audience": a.Audience, "scopes": scopeList, "expires_at": ac.EXP * 1000}
	td, e := Digest("delegation", []byte(value(delegation)))
	if e != nil {
		return fail()
	}
	return Identity{Subject{ac.ISS, ac.SUB}, workload, jkt, td, token, scopes}, nil
}
