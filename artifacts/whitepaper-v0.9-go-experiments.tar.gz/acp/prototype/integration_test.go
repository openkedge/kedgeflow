package kedgeflow

import (
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"go.etcd.io/etcd/api/v3/version"
	clientv3 "go.etcd.io/etcd/client/v3"
	"go.etcd.io/etcd/server/v3/embed"
)

var clusterClient *clientv3.Client

func freeURL() url.URL {
	l, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		panic(e)
	}
	addr := l.Addr().String()
	_ = l.Close()
	u, e := url.Parse("http://" + addr)
	if e != nil {
		panic(e)
	}
	return *u
}
func TestMain(m *testing.M) {
	dir, e := os.MkdirTemp("", "kedgeflow-etcd36-")
	if e != nil {
		panic(e)
	}
	peers := make([]url.URL, 3)
	clients := make([]url.URL, 3)
	parts := make([]string, 3)
	for i := 0; i < 3; i++ {
		peers[i] = freeURL()
		clients[i] = freeURL()
		parts[i] = fmt.Sprintf("node%d=%s", i, peers[i].String())
	}
	servers := make([]*embed.Etcd, 0, 3)
	cleanup := func() {
		if clusterClient != nil {
			_ = clusterClient.Close()
		}
		for _, s := range servers {
			s.Close()
		}
		_ = os.RemoveAll(dir)
	}
	for i := 0; i < 3; i++ {
		cfg := embed.NewConfig()
		cfg.Name = fmt.Sprintf("node%d", i)
		cfg.Dir = fmt.Sprintf("%s/node%d", dir, i)
		cfg.ListenPeerUrls = []url.URL{peers[i]}
		cfg.AdvertisePeerUrls = cfg.ListenPeerUrls
		cfg.ListenClientUrls = []url.URL{clients[i]}
		cfg.AdvertiseClientUrls = cfg.ListenClientUrls
		cfg.InitialCluster = strings.Join(parts, ",")
		cfg.InitialClusterToken = "kedgeflow-" + randomID()
		cfg.InitialClusterToken = "kedgeflow-tests"
		cfg.LogLevel = "error"
		cfg.LogOutputs = []string{"/dev/null"}
		cfg.TickMs = 100
		cfg.ElectionMs = 1000
		s, err := embed.StartEtcd(cfg)
		if err != nil {
			cleanup()
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		servers = append(servers, s)
	}
	for _, s := range servers {
		select {
		case <-s.Server.ReadyNotify():
		case <-time.After(30 * time.Second):
			cleanup()
			fmt.Fprintln(os.Stderr, "etcd cluster timeout")
			os.Exit(1)
		}
	}
	endpoints := []string{}
	for _, u := range clients {
		endpoints = append(endpoints, u.String())
	}
	clusterClient, e = clientv3.New(clientv3.Config{Endpoints: endpoints, DialTimeout: 5 * time.Second})
	if e != nil {
		cleanup()
		panic(e)
	}
	fmt.Printf("ENV go=%s os=%s arch=%s cpu=%d etcd=%s members=3 topology=single-host-loopback embedded-real-raft\n", runtime.Version(), runtime.GOOS, runtime.GOARCH, runtime.NumCPU(), version.Version)
	code := m.Run()
	cleanup()
	os.Exit(code)
}
func fixtureWithKey(t *testing.T, root string) (Grant, []byte, GrantVerifier, Identity, ToolDescriptor, ed25519.PrivateKey) {
	t.Helper()
	pub, priv, e := ed25519.GenerateKey(rand.Reader)
	if e != nil {
		t.Fatal(e)
	}
	d := strings.Repeat("1", 64)
	now := time.Now()
	adapter := json.RawMessage(`{"level":"Level_A","guard_primitive":"FencingToken","fence_parameter":"kf_fence","guard_scope":["node-a"],"completion_mode":"dispatch_bound","commit_point":"mock atomic version+fence+mutation","idempotency":{"mode":"resource_key","parameter":"kf_attempt_id","retention_ms":60000}}`)
	params := json.RawMessage(`{"node":"node-a","expected_version":1}`)
	pd, e := Digest("parameters", params)
	if e != nil {
		t.Fatal(e)
	}
	id := Identity{Subject{"https://identity.test", "human-1"}, "spiffe://test/agent", strings.Repeat("a", 43), d, "agent-oauth-token", map[string]bool{"mutate": true, "read": true}}
	g := Grant{GID: "grant-" + root, ProposalDigest: d, CertificateDigest: d, DelegationDigest: d, Subject: id.Subject, WorkloadID: id.WorkloadID, DPoPJKT: id.DPoPJKT, Action: Action{"node.drain", "1.0", d}, Resources: []Resource{{"node-a", "incarnation-1"}}, ParametersDigest: pd, Policy: Policy{"policy-1", 1, d}, EvidenceManifestDigest: d, ConstraintDigest: d, OwnershipEpoch: 1, PredicateDescriptor: json.RawMessage(`{"id":"node-version","version":"1.0","language":"kf-conjunction-v1","clauses":[{"kind":"version_eq","resource":{"id":"node-a","incarnation":"incarnation-1"},"expected_version":"1"}]}`), AdapterContract: adapter, RootID: root, RootGeneration: 1, ParentGrantDigest: nil, SagaBudget: json.RawMessage("null"), ConflictDomain: "cluster-a", Nonce: base64Nonce(root), Fence: 1, Audience: "https://gateway.test/mcp", IssuedAt: now.Add(-time.Second).UnixMilli(), ValidFrom: now.Add(-time.Second).UnixMilli(), ExpiresAt: now.Add(3 * time.Minute).UnixMilli(), CompletionMode: "dispatch_bound"}
	b, e := SignGrant(g, "issuer-test", priv)
	if e != nil {
		t.Fatal(e)
	}
	v := GrantVerifier{Keys: map[string]ed25519.PublicKey{"issuer-test": pub}, Audience: g.Audience}
	td := ToolDescriptor{Name: "node_drain", RequiredScope: "mutate", Action: g.Action, Resource: g.Resources[0], ConflictDomain: g.ConflictDomain, AdapterContract: adapter, PredicateID: "node-version", PredicateVersion: "1.0", VersionParameter: "expected_version", FenceParameter: "kf_fence", AdmissionEndpoint: "https://admission.test/proposals"}
	return g, b, v, id, td, priv
}
func fixture(t *testing.T, root string) (Grant, []byte, GrantVerifier, Identity, ToolDescriptor) {
	g, b, v, id, td, _ := fixtureWithKey(t, root)
	return g, b, v, id, td
}
func base64Nonce(s string) string { return strings.ReplaceAll(s, "/", "_") + "_nonce" }
func ledger(t *testing.T, g Grant, raw []byte, v GrantVerifier) Ledger {
	t.Helper()
	l := Ledger{clusterClient, "/test/" + randomID()}
	ctx := context.Background()
	if e := l.PublishPolicy(ctx, g); e != nil {
		t.Fatal(e)
	}
	_, d, e := v.Verify(raw)
	if e != nil {
		t.Fatal(e)
	}
	if e = l.Issue(ctx, g, d); e != nil {
		t.Fatal(e)
	}
	return l
}
func TestLedgerConcurrencyMatrix(t *testing.T) {
	for _, roots := range []int{1, 8, 32} {
		for _, workers := range []int{32, 128} {
			t.Run(fmt.Sprintf("roots=%d/workers=%d", roots, workers), func(t *testing.T) {
				g, raw, v, _, _, signer := fixtureWithKey(t, "seed")
				l := ledger(t, g, raw, v)

				grants := make([]Grant, roots)
				digests := make([]string, roots)
				for r := 0; r < roots; r++ {
					x := g
					x.RootID = fmt.Sprintf("root-%d", r)
					x.GID = fmt.Sprintf("gid-%d", r)
					x.Nonce = fmt.Sprintf("nonce_%d", r)
					grants[r] = x
					signed, e := SignGrant(x, "issuer-test", signer)
					if e != nil {
						t.Fatal(e)
					}
					_, digests[r], e = v.Verify(signed)
					if e != nil {
						t.Fatal(e)
					}
					if e = l.Issue(context.Background(), x, digests[r]); e != nil {
						t.Fatal(e)
					}
				}
				var wg sync.WaitGroup
				wins := make([]atomic.Int64, roots)
				var refused, failures atomic.Int64
				start := time.Now()
				sem := make(chan struct{}, 512)
				for r := 0; r < roots; r++ {
					for w := 0; w < workers; w++ {
						wg.Add(1)
						go func(r, w int) {
							defer wg.Done()
							sem <- struct{}{}
							defer func() { <-sem }()
							ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
							defer cancel()
							_, err := l.Claim(ctx, grants[r], digests[r], fmt.Sprintf("attempt-%d-%d", r, w))
							if err == nil {
								wins[r].Add(1)
							} else if errors.Is(err, ErrRefused) {
								refused.Add(1)
							} else {
								failures.Add(1)
								t.Errorf("claim transport failure: %v", err)
							}
						}(r, w)
					}
				}
				wg.Wait()
				elapsed := time.Since(start)
				var total int64
				for r := range wins {
					n := wins[r].Load()
					if n != 1 {
						t.Errorf("root %d winners=%d", r, n)
					}
					total += n
				}
				t.Logf("CLAIM roots=%d workers_per_root=%d attempts=%d winners=%d refused=%d transport_errors=%d elapsed_ms=%.3f claims_per_sec=%.1f", roots, workers, roots*workers, total, refused.Load(), failures.Load(), float64(elapsed.Microseconds())/1000, float64(roots*workers)/elapsed.Seconds())
			})
		}
	}
}
func TestGenerationFenceAndReplaceRace(t *testing.T) {
	for i := 0; i < 100; i++ {
		g, raw, v, _, _, signer := fixtureWithKey(t, fmt.Sprintf("race-%d", i))
		l := ledger(t, g, raw, v)
		_, d, _ := v.Verify(raw)
		next := g
		next.GID += "-next"
		next.Nonce += "_next"
		next.RootGeneration++
		next.Fence++
		signed, e := SignGrant(next, "issuer-test", signer)
		if e != nil {
			t.Fatal(e)
		}
		_, nextDigest, e := v.Verify(signed)
		if e != nil {
			t.Fatal(e)
		}
		var wg sync.WaitGroup
		var ce, re error
		wg.Add(2)
		go func() { defer wg.Done(); _, ce = l.Claim(context.Background(), g, d, "claim-old") }()
		go func() { defer wg.Done(); re = l.Replace(context.Background(), g, next, nextDigest) }()
		wg.Wait()
		if (ce == nil) == (re == nil) {
			t.Fatalf("claim/replace winners ce=%v re=%v", ce, re)
		}
		if re == nil {
			if _, e := l.Claim(context.Background(), g, d, "stale"); !errors.Is(e, ErrRefused) {
				t.Fatal("old generation accepted", e)
			}
			if _, e := l.Claim(context.Background(), next, nextDigest, "new"); e != nil {
				t.Fatal(e)
			}
		} else {
			if e := l.Replace(context.Background(), g, next, nextDigest); !errors.Is(e, ErrRefused) {
				t.Fatal("consumed root replaced", e)
			}
		}
	}
	g, raw, v, _, _ := fixture(t, "fence")
	l := ledger(t, g, raw, v)
	_, d, _ := v.Verify(raw)
	bad := g
	bad.Fence++
	if _, e := l.Claim(context.Background(), bad, d, "wrong-fence"); !errors.Is(e, ErrRefused) {
		t.Fatal("wrong fence accepted", e)
	}
	bad = g
	bad.RootGeneration++
	if _, e := l.Claim(context.Background(), bad, d, "wrong-generation"); !errors.Is(e, ErrRefused) {
		t.Fatal("wrong generation accepted", e)
	}
	t.Log("FENCE claim/replace races=100 exclusive_winner=100 stale_generation_refused=true wrong_fence_refused=true claimed_root_replacement_refused=true")
}

type testBroker struct {
	calls atomic.Int64
	fail  bool
}

func (b *testBroker) Exchange(_ context.Context, c VerifiedCall) (TargetCredential, error) {
	b.calls.Add(1)
	if b.fail {
		return TargetCredential{}, errors.New("broker refused")
	}
	return TargetCredential{"distinct-target-token", time.Now().Add(time.Minute), "mock-target"}, nil
}

type mockTarget struct {
	mu             sync.Mutex
	version, fence uint64
	effects        int
	reads          int
	unknown        bool
	leaked         bool
	lastAttempt    string
}

func (m *mockTarget) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	m.mu.Lock()
	defer m.mu.Unlock()
	for _, h := range []string{"Mcp-KedgeFlow-Grant", "DPoP", "Cookie", "X-Agent-Credential"} {
		if r.Header.Get(h) != "" {
			m.leaked = true
		}
	}
	var req Request
	raw, _ := io.ReadAll(r.Body)
	if strictJSON(raw, &req) != nil {
		http.Error(w, "bad", 400)
		return
	}
	if req.Params.Name == "node_read" {
		m.reads++
		if r.Header.Get("Authorization") != "Bearer target-read-token" {
			m.leaked = true
		}
		response(w, req.ID, json.RawMessage(`{"resultType":"complete","content":[{"type":"text","text":"Mock node version"}],"structuredContent":{"version":1},"isError":false}`), 0, "", nil)
		return
	}
	if r.Header.Get("Authorization") != "Bearer distinct-target-token" {
		m.leaked = true
		http.Error(w, "bad credential", 401)
		return
	}
	var args struct {
		Node        string `json:"node"`
		Version     uint64 `json:"expected_version"`
		Fence       uint64 `json:"kf_fence"`
		Attempt     string `json:"kf_attempt_id"`
		GrantDigest string `json:"kf_grant_digest"`
		Incarnation string `json:"kf_resource_incarnation"`
	}
	if strictJSON(req.Params.Arguments, &args) != nil {
		http.Error(w, "bad args", 400)
		return
	}
	// This is an in-memory mock of a target-side atomic version/fence/mutation.
	// No Kubernetes API or SQL engine is exercised or implied by this test.
	if args.Node != "node-a" || args.Incarnation != "incarnation-1" || len(args.GrantDigest) != 64 || args.Version != m.version || args.Fence < m.fence || args.Attempt == "" {
		response(w, req.ID, nil, -32010, "STATE_GUARD_VIOLATION", nil)
		return
	}
	m.version++
	m.fence = args.Fence
	m.effects++
	m.lastAttempt = args.Attempt
	if m.unknown {
		if hijacker, ok := w.(http.Hijacker); ok {
			conn, _, e := hijacker.Hijack()
			if e == nil {
				_ = conn.Close()
				return
			}
		}
		http.Error(w, "lost response after effect", 503)
		return
	}
	result, _ := json.Marshal(map[string]any{"resultType": "complete", "content": []any{map[string]string{"type": "text", "text": "Mock node state changed"}}, "structuredContent": map[string]any{"drained": true, "kedgeflow_terminal_receipt": MockTerminalReceipt{args.Attempt, args.GrantDigest, Resource{args.Node, args.Incarnation}, args.Fence, "committed", m.version}}, "isError": false})
	response(w, req.ID, result, 0, "", nil)
}
func requestBody(tool string, args string) []byte {
	return []byte(fmt.Sprintf(`{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":%q,"arguments":%s,"_meta":{"io.modelcontextprotocol/protocolVersion":"2026-07-28","io.modelcontextprotocol/clientCapabilities":{"extensions":{"io.kedgeflow/governed-mcp":{"profile":"KF-MCP-0.1"}}}}}}`, tool, args))
}
func call(p http.Handler, body []byte, grant string) *httptest.ResponseRecorder {
	r := httptest.NewRequest("POST", "https://gateway.test/mcp", bytes.NewReader(body))
	r.Header.Set("Authorization", "DPoP agent-oauth-token")
	r.Header.Set("DPoP", "proof-never-forward")
	r.Header.Set("Cookie", "agent-cookie")
	r.Header.Set("X-Agent-Credential", "secret")
	if grant != "" {
		r.Header.Set("Mcp-KedgeFlow-Grant", grant)
	}
	w := httptest.NewRecorder()
	p.ServeHTTP(w, r)
	return w
}
func errorMessage(w *httptest.ResponseRecorder) string {
	var r rpcResponse
	_ = json.Unmarshal(w.Body.Bytes(), &r)
	if r.Error == nil {
		return ""
	}
	return r.Error.Message
}
func TestProxyBoundary(t *testing.T) {
	tests := []string{"handshake", "replay", "drift", "transfer", "unknown_tool", "read_authorized", "read_authorized_native", "read_denied", "read_grant_bypass", "batch", "signature_tamper", "state_guard", "outcome_unknown", "ledger_unavailable", "broker_refused", "unsupported_predicate"}
	for _, name := range tests {
		t.Run(name, func(t *testing.T) {
			g, raw, v, id, td := fixture(t, "proxy-"+name)
			l := ledger(t, g, raw, v)
			target := &mockTarget{version: 1}
			up := httptest.NewServer(target)
			defer up.Close()
			broker := &testBroker{}
			read := ToolDescriptor{Name: "node_read", ReadOnly: true, RequiredScope: "read"}
			p := &Proxy{Verifier: v, Ledger: l, Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: broker, Adapter: &HTTPAdapter{up.Client(), up.URL, "mock-target", "target-read-token"}, Tools: map[string]ToolDescriptor{"node_drain": td, "node_read": read}, Timeout: 5 * time.Second}
			body := requestBody("node_drain", `{"node":"node-a","expected_version":1}`)
			header := HeaderGrant(raw)
			want := ""
			switch name {
			case "handshake":
				header = ""
				want = "NEEDS_EVIDENCE"
			case "replay":
				if w := call(p, body, header); errorMessage(w) != "" {
					t.Fatal(w.Body.String())
				}
				want = "NONCE_CONSUMED"
			case "drift":
				body = requestBody("node_drain", `{"node":"node-a","expected_version":2}`)
				want = "GRANT_MISMATCH"
			case "transfer":
				id.WorkloadID = "spiffe://test/other-agent"
				want = "GRANT_MISMATCH"
			case "unknown_tool":
				body = requestBody("unregistered_read_hint", `{}`)
				header = ""
				want = "UNREGISTERED_TOOL"
			case "read_authorized":
				body = requestBody("node_read", `{}`)
				header = ""
			case "read_authorized_native":
				body = requestBody("node_read", `{}`)
				header = ""
				body = bytes.ReplaceAll(body, []byte(`{"extensions":{"io.kedgeflow/governed-mcp":{"profile":"KF-MCP-0.1"}}}`), []byte(`{}`))
			case "read_denied":
				body = requestBody("node_read", `{}`)
				header = ""
				id.Scopes = map[string]bool{"mutate": true}
				want = "INSUFFICIENT_SCOPE"
			case "read_grant_bypass":
				body = requestBody("node_read", `{}`)
				want = "UNEXPECTED_GRANT"
			case "batch":
				body = append(append([]byte("["), body...), ']')
				want = "INVALID_REQUEST"
			case "signature_tamper":
				var env Envelope
				_ = json.Unmarshal(raw, &env)
				env.Signature = strings.Repeat("A", 86)
				tamper, _ := json.Marshal(env)
				header = HeaderGrant(tamper)
				want = "GRANT_MISMATCH"
			case "state_guard":
				target.version = 2
				want = "STATE_GUARD_VIOLATION"
			case "outcome_unknown":
				target.unknown = true
				want = "OUTCOME_UNKNOWN"
			case "ledger_unavailable":
				p.Ledger.Prefix = "/not-issued/" + randomID()
				want = "ROOT_UNAVAILABLE_OR_CONSUMED"
			case "broker_refused":
				broker.fail = true
				want = "CREDENTIAL_UNAVAILABLE"
			case "unsupported_predicate":
				p.Tools[td.Name] = func() ToolDescriptor { x := td; x.PredicateID = "not-implemented"; return x }()
				want = "GRANT_MISMATCH"
			}
			w := call(p, body, header)
			if got := errorMessage(w); got != want {
				t.Fatalf("got=%s want=%s body=%s", got, want, w.Body.String())
			}
			target.mu.Lock()
			effects, leaked := target.effects, target.leaked
			target.mu.Unlock()
			if name == "replay" || name == "outcome_unknown" {
				if effects != 1 {
					t.Fatalf("effects=%d", effects)
				}
			} else if name != "read_authorized" && effects != 0 {
				t.Fatalf("unauthorized effect count=%d", effects)
			}
			if leaked {
				t.Fatal("incoming authority forwarded")
			}
			if name == "handshake" {
				if broker.calls.Load() != 0 {
					t.Fatal("minted credential without claim")
				}
				var rr rpcResponse
				_ = json.Unmarshal(w.Body.Bytes(), &rr)
				if rr.Error.Code != -32001 {
					t.Fatal("wrong negotiated code")
				}
				_ = os.MkdirAll("results", 0755)
				_ = os.WriteFile("results/needs-evidence.json", w.Body.Bytes(), 0644)
			}
			if name == "outcome_unknown" {
				if next := call(p, body, header); errorMessage(next) != "NONCE_CONSUMED" {
					t.Fatal("unknown retried")
				}
			}
		})
	}
}
