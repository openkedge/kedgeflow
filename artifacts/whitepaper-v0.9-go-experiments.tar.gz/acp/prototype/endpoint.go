package kedgeflow

import (
	"errors"
	"net/http"
	"net/netip"
	"net/url"
	"strconv"
	"strings"
)

// EndpointPolicy pins the HTTP authority and path before a request reaches the
// gateway. It does not authenticate callers or constrain native process tools.
// Its private fields are immutable after construction and safe to share.
type EndpointPolicy struct {
	authority string
	path      string
}

// NewEndpointPolicy accepts a trusted HTTPS URL with an explicit unescaped path.
// Host names are ASCII (including preconverted IDNA names), case insensitive,
// and cannot have a trailing dot. Port 443 and its omission are equivalent;
// numeric IP addresses are canonicalized without DNS resolution. The original
// URL remains the caller's configured audience/DPoP URL and is never rewritten.
func NewEndpointPolicy(externalURL string) (*EndpointPolicy, error) {
	u, err := url.Parse(externalURL)
	if err != nil || u.Scheme != "https" || u.Opaque != "" || u.User != nil || u.Host == "" || u.RawQuery != "" || u.ForceQuery || u.Fragment != "" || u.RawFragment != "" || strings.Contains(externalURL, "#") {
		return nil, errors.New("external_url must be a fixed HTTPS endpoint without userinfo, query or fragment")
	}
	authority, err := endpointAuthority(u.Host)
	if err != nil {
		return nil, err
	}
	if u.Path == "" || u.Path[0] != '/' || u.RawPath != "" || u.EscapedPath() != u.Path {
		return nil, errors.New("external_url requires an explicit unescaped absolute path")
	}
	for _, segment := range strings.Split(u.Path, "/") {
		if segment == "." || segment == ".." {
			return nil, errors.New("external_url path cannot contain dot segments")
		}
	}
	if strings.Contains(u.Path, "//") || strings.Contains(u.Path, "\\") {
		return nil, errors.New("external_url path cannot contain repeated or backslash separators")
	}
	return &EndpointPolicy{authority: authority, path: u.Path}, nil
}

func endpointAuthority(authority string) (string, error) {
	bad := func() (string, error) { return "", errors.New("invalid endpoint authority") }
	if authority == "" || strings.ContainsAny(authority, " \t\r\n,/@\\?#%") || strings.HasSuffix(authority, ":") {
		return bad()
	}
	u, err := url.Parse("https://" + authority)
	if err != nil || u.Host != authority || u.User != nil || u.Path != "" {
		return bad()
	}
	host := u.Hostname()
	if host == "" {
		return bad()
	}
	if strings.HasPrefix(authority, "[") {
		addr, err := netip.ParseAddr(host)
		if err != nil || !addr.Is6() || addr.Zone() != "" {
			return bad()
		}
		host = "[" + addr.String() + "]"
	} else if addr, err := netip.ParseAddr(host); err == nil {
		if !addr.Is4() {
			return bad()
		}
		host = addr.String()
	} else {
		if strings.ContainsAny(host, "[]:") || len(host) > 253 || strings.HasSuffix(host, ".") {
			return bad()
		}
		numeric := true
		for _, c := range host {
			if c != '.' && (c < '0' || c > '9') {
				numeric = false
			}
		}
		// Do not interpret abbreviated/legacy IPv4 forms as DNS names.
		if numeric {
			return bad()
		}
		for _, label := range strings.Split(host, ".") {
			if label == "" || len(label) > 63 || label[0] == '-' || label[len(label)-1] == '-' {
				return bad()
			}
			for _, c := range label {
				if !((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-') {
					return bad()
				}
			}
		}
		host = strings.ToLower(host)
	}
	port := u.Port()
	if port != "" {
		if port[0] == '0' {
			return bad()
		}
		p, err := strconv.Atoi(port)
		if err != nil || p < 1 || p > 65535 {
			return bad()
		}
		if p != 443 {
			host += ":" + strconv.Itoa(p)
		}
	}
	return host, nil
}

// Wrap rejects browser-origin traffic and endpoint aliases before invoking next.
// No Origin is the native-client profile; it still needs the gateway's normal
// mTLS, OAuth/DPoP authentication and grant checks. Forwarding headers do not
// participate in authority selection. An HTTP server rejects duplicate wire
// Host headers itself; the additional header check also closes synthetic ones.
func (p *EndpointPolicy) Wrap(next http.Handler) http.Handler {
	if next == nil {
		panic("nil endpoint handler")
	}
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		refuse := func(code int) {
			w.Header().Set("Cache-Control", "no-store")
			http.Error(w, http.StatusText(code), code)
		}
		for name := range r.Header {
			if strings.EqualFold(name, "Origin") {
				refuse(http.StatusForbidden)
				return
			}
			if strings.EqualFold(name, "Host") {
				refuse(http.StatusMisdirectedRequest)
				return
			}
		}
		authority, err := endpointAuthority(r.Host)
		if err != nil || authority != p.authority {
			refuse(http.StatusMisdirectedRequest)
			return
		}
		if r.URL == nil || r.URL.Scheme != "" || r.URL.Host != "" || r.URL.Opaque != "" || r.URL.User != nil || r.URL.RawQuery != "" || r.URL.ForceQuery || r.URL.Fragment != "" || r.URL.RawFragment != "" {
			refuse(http.StatusBadRequest)
			return
		}
		if r.URL.Path != p.path || r.URL.RawPath != "" || r.URL.EscapedPath() != p.path {
			refuse(http.StatusNotFound)
			return
		}
		next.ServeHTTP(w, r)
	})
}
