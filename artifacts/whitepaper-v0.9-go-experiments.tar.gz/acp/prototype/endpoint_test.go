package kedgeflow

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"sync/atomic"
	"testing"
)

func TestEndpointPolicyConfiguration(t *testing.T) {
	for _, tc := range []struct{ raw, authority, path string }{
		{"https://LOCALHOST:443/mcp", "localhost", "/mcp"},
		{"https://localhost/mcp", "localhost", "/mcp"},
		{"https://127.0.0.1:8443/mcp", "127.0.0.1:8443", "/mcp"},
		{"https://[0:0:0:0:0:0:0:1]:8443/mcp", "[::1]:8443", "/mcp"},
		{"https://[::1]:443/", "[::1]", "/"},
		{"https://xn--bcher-kva.example/a-b_~.v1/", "xn--bcher-kva.example", "/a-b_~.v1/"},
	} {
		t.Run(tc.raw, func(t *testing.T) {
			p, err := NewEndpointPolicy(tc.raw)
			if err != nil || p.authority != tc.authority || p.path != tc.path {
				t.Fatalf("policy=%+v err=%v", p, err)
			}
		})
	}
	for _, raw := range []string{
		"", "http://localhost/mcp", "https:localhost/mcp", "https:///mcp",
		"https://user:secret@localhost/mcp", "https://localhost", "https://localhost/mcp?x=1",
		"https://localhost/mcp?", "https://localhost/mcp#fragment", "https://localhost/mcp#",
		"https://localhost:/mcp", "https://localhost:0/mcp", "https://localhost:0443/mcp",
		"https://localhost:65536/mcp", "https://localhost:abc/mcp", "https://localhost./mcp",
		"https://local_host/mcp", "https://bücher.example/mcp", "https://a..example/mcp",
		"https://-bad.example/mcp", "https://bad-.example/mcp", "https://127.1/mcp",
		"https://127.000.000.001/mcp", "https://[localhost]/mcp", "https://::1/mcp",
		"https://[fe80::1%25lo0]/mcp", "https://localhost/%6dcp", "https://localhost/a%2fb",
		"https://localhost/a/../mcp", "https://localhost/./mcp", "https://localhost//mcp",
		"https://localhost/mcp\\next", "https://localhost/path with space", "https://localhost/λ",
	} {
		t.Run("reject "+raw, func(t *testing.T) {
			if _, err := NewEndpointPolicy(raw); err == nil {
				t.Fatal("accepted malformed or ambiguous endpoint")
			}
		})
	}
}

func TestEndpointPolicyRejectsBeforeDownstream(t *testing.T) {
	p, err := NewEndpointPolicy("https://localhost:8443/mcp")
	if err != nil {
		t.Fatal(err)
	}
	for _, tc := range []struct {
		name   string
		mutate func(*http.Request)
		status int
	}{
		{"alternate DNS Host", func(r *http.Request) { r.Host = "attacker.example:8443" }, 421},
		{"loopback IP alias", func(r *http.Request) { r.Host = "127.0.0.1:8443" }, 421},
		{"other port", func(r *http.Request) { r.Host = "localhost:8444" }, 421},
		{"missing port", func(r *http.Request) { r.Host = "localhost" }, 421},
		{"missing Host", func(r *http.Request) { r.Host = "" }, 421},
		{"trailing dot", func(r *http.Request) { r.Host = "localhost.:8443" }, 421},
		{"userinfo Host", func(r *http.Request) { r.Host = "attacker@localhost:8443" }, 421},
		{"comma Host", func(r *http.Request) { r.Host = "localhost:8443,attacker.example" }, 421},
		{"empty port", func(r *http.Request) { r.Host = "localhost:" }, 421},
		{"duplicate Host representation", func(r *http.Request) { r.Header.Add("Host", "localhost:8443") }, 421},
		{"lowercase duplicate Host", func(r *http.Request) { r.Header["host"] = []string{"localhost:8443"} }, 421},
		{"external browser Origin", func(r *http.Request) { r.Header.Set("Origin", "https://attacker.example") }, 403},
		{"same Origin also unsupported", func(r *http.Request) { r.Header.Set("Origin", "https://localhost:8443") }, 403},
		{"opaque Origin", func(r *http.Request) { r.Header.Set("Origin", "null") }, 403},
		{"blank Origin", func(r *http.Request) { r.Header["Origin"] = []string{""} }, 403},
		{"duplicate Origin", func(r *http.Request) { r.Header["Origin"] = []string{"", "https://attacker.example"} }, 403},
		{"lowercase Origin", func(r *http.Request) { r.Header["origin"] = []string{"https://attacker.example"} }, 403},
		{"different path", func(r *http.Request) { r.URL.Path = "/admin" }, 404},
		{"trailing slash", func(r *http.Request) { r.URL.Path = "/mcp/" }, 404},
		{"dot path", func(r *http.Request) { r.URL.Path = "/a/../mcp" }, 404},
		{"encoded path alias", func(r *http.Request) { r.URL.RawPath = "/%6dcp" }, 404},
		{"encoded separator", func(r *http.Request) { r.URL.Path = "/mcp/"; r.URL.RawPath = "/mcp%2f" }, 404},
		{"query", func(r *http.Request) { r.URL.RawQuery = "next=attacker" }, 400},
		{"empty query marker", func(r *http.Request) { r.URL.ForceQuery = true }, 400},
		{"fragment", func(r *http.Request) { r.URL.Fragment = "attacker" }, 400},
		{"absolute-form request", func(r *http.Request) { r.URL.Scheme = "https"; r.URL.Host = "localhost:8443" }, 400},
		{"opaque URL", func(r *http.Request) { r.URL.Opaque = "//localhost:8443/mcp" }, 400},
		{"nil URL", func(r *http.Request) { r.URL = nil }, 400},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var downstream atomic.Int32
			h := p.Wrap(http.HandlerFunc(func(http.ResponseWriter, *http.Request) { downstream.Add(1) }))
			r := httptest.NewRequest(http.MethodPost, "/mcp", nil)
			r.Host = "localhost:8443"
			r.Header.Set("Mcp-KedgeFlow-Grant", "malicious-not-inspected")
			tc.mutate(r)
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			if w.Code != tc.status || downstream.Load() != 0 || w.Header().Get("Cache-Control") != "no-store" {
				t.Fatalf("status=%d downstream=%d headers=%v", w.Code, downstream.Load(), w.Header())
			}
		})
	}
}

func TestEndpointPolicyPermitsPinnedNativeRequestWithoutRewriting(t *testing.T) {
	for _, tc := range []struct{ endpoint, host string }{
		{"https://localhost:8443/mcp", "LOCALHOST:8443"},
		{"https://localhost/mcp", "localhost:443"},
		{"https://localhost:443/mcp", "localhost"},
		{"https://[::1]:8443/mcp", "[0:0:0:0:0:0:0:1]:8443"},
		{"https://[::1]/mcp", "[::1]:443"},
		{"https://127.0.0.1:8443/mcp", "127.0.0.1:8443"},
	} {
		t.Run(tc.endpoint+" "+tc.host, func(t *testing.T) {
			p, err := NewEndpointPolicy(tc.endpoint)
			if err != nil {
				t.Fatal(err)
			}
			r := httptest.NewRequest(http.MethodPost, "/mcp", nil)
			r.Host = tc.host
			r.Header.Set("DPoP", "proof-of-exact-configured-url")
			r.Header.Set("Forwarded", "host=attacker.example")
			r.Header.Set("X-Forwarded-Host", "attacker.example")
			originalURL := r.URL.String()
			calls := 0
			h := p.Wrap(http.HandlerFunc(func(w http.ResponseWriter, got *http.Request) {
				calls++
				if got != r || got.URL.String() != originalURL || got.Host != tc.host || got.Header.Get("DPoP") != "proof-of-exact-configured-url" {
					t.Fatal("endpoint policy rewrote request or proof")
				}
				w.WriteHeader(http.StatusNoContent)
			}))
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			if calls != 1 || w.Code != http.StatusNoContent {
				t.Fatalf("calls=%d status=%d", calls, w.Code)
			}
		})
	}
}

func TestEndpointPolicyNativeClientStillAuthenticates(t *testing.T) {
	const body = `{"jsonrpc":"2.0","id":1,"method":"server/discover","params":{"_meta":{"io.modelcontextprotocol/protocolVersion":"2026-07-28","io.modelcontextprotocol/clientCapabilities":{}}}}`
	p, err := NewEndpointPolicy("https://localhost:8443/mcp")
	if err != nil {
		t.Fatal(err)
	}
	var authCalls atomic.Int32
	proxy := &Proxy{Auth: AuthFunc(func(*http.Request) (Identity, error) {
		authCalls.Add(1)
		return Identity{}, errors.New("no valid identity")
	})}
	h := p.Wrap(proxy)
	for _, origin := range []bool{true, false} {
		r := httptest.NewRequest(http.MethodPost, "/mcp", strings.NewReader(body))
		r.Host = "localhost:8443"
		if origin {
			r.Header.Set("Origin", "https://attacker.example")
		}
		w := httptest.NewRecorder()
		h.ServeHTTP(w, r)
		if origin {
			if w.Code != 403 || authCalls.Load() != 0 {
				t.Fatalf("origin request reached authentication: %d %d", w.Code, authCalls.Load())
			}
		} else if authCalls.Load() != 1 || errorMessage(w) != "IDENTITY_CONFLICT" {
			t.Fatalf("native request bypassed authentication: %d %s", authCalls.Load(), w.Body.String())
		}
	}
}

func TestEndpointPolicyConcurrentBoundary(t *testing.T) {
	p, err := NewEndpointPolicy("https://[::1]:8443/mcp")
	if err != nil {
		t.Fatal(err)
	}
	var calls atomic.Int32
	h := p.Wrap(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
		calls.Add(1)
		w.WriteHeader(http.StatusNoContent)
	}))
	for i := range 32 {
		t.Run(strconv.Itoa(i), func(t *testing.T) {
			t.Parallel()
			r := httptest.NewRequest(http.MethodPost, "/mcp", nil)
			r.Host = "[::1]:8443"
			if i%2 == 0 {
				r.Header.Set("Origin", "https://attacker.example")
			}
			w := httptest.NewRecorder()
			h.ServeHTTP(w, r)
			want := http.StatusNoContent
			if i%2 == 0 {
				want = http.StatusForbidden
			}
			if w.Code != want {
				t.Fatalf("status=%d want=%d", w.Code, want)
			}
		})
	}
	// Cleanup runs after every parallel child, so the count is final here.
	t.Cleanup(func() {
		if calls.Load() != 16 {
			t.Fatalf("downstream calls=%d want=16", calls.Load())
		}
	})
}
