# Governed MCP gateway reference slice

This is executable Go code for the **v0.9 proposed profiles**, not a production
control plane or an adopted MCP extension. It implements single-action admission
remediation, authenticated grant redemption, an etcd v3.6.5 authority transaction,
credential custody, and query-only outcome reconciliation. The gateway binary
requires verified TLS. Tests start three real embedded etcd servers with a Raft
cluster on loopback and use disposable mock target/authorization services.

## Run and reproduce

From this directory, with Go 1.24 or newer:

```sh
make build
make test
make race
make sdk-test
bin/kf-proxy -h
```

`go.mod` and `go.sum` pin all Go dependencies, including etcd client/server v3.6.5
and the RFC 8785 reference canonicalizer. `Makefile` keeps module/build caches in
the ignored `.cache/` directory. The tests need permission to bind ephemeral
loopback ports and fetch dependencies on their first run. They never connect to
production resources or install system software. `results/raw-tests.txt` and
`results/raw-race-tests.txt` record the executed suite;
`results/raw-mcp-result-tests.txt` records the final target-result boundary checks; `results/benchmarks.json`
records the extracted non-instrumented race matrix. Test results describe one
host, not a fault-tolerant multi-host deployment.

Focused local endpoint checks are recorded in
`results/raw-endpoint-boundary-tests.txt`; configuration checks are also recorded
in `results/raw-endpoint-config-tests.txt`. These tests wrap the actual Proxy
with the CLI's `EndpointPolicy` and prove that rejected Host/Origin/path requests
never invoke downstream authentication, while permitted native requests still
need identity verification. The official SDK fixture exercises the generic
Proxy rather than the CLI endpoint wrapper; its protocol result does not establish
CLI deployment or complete HTTP transport conformance.

Build and run the container on a host with Docker:

```sh
docker build -t kedgeflow-proxy:0.9 .
docker compose up --build
```

Compose requires `KF_GATEWAY_CONFIG` to name an existing trusted JSON configuration
file and `KF_GATEWAY_SECRETS` to name a directory containing the certificates,
trust bundles and credential-provider files referenced by that configuration.
It binds the listener to host loopback, runs as UID 65532 with a read-only root,
and mounts those files read-only. The Dockerfile compiles a static binary into a
scratch image. **Docker was unavailable on the validation host; a container build
or launch was not executed.** Native compilation, the local Go suite, and a
pinned official MCP SDK integration were executed. Production builds must resolve base-image tags to reviewed digests.

## Protected wire path

The HTTP profile accepts one JSON-RPC request with an ID per POST. It implements
`server/discover`, authorization-filtered `tools/list`, and `tools/call`; other
methods, batches, notifications, streaming and session resumption are refused.
Required request metadata uses the MCP 2026-07-28 keys:

```json
{
  "io.modelcontextprotocol/protocolVersion": "2026-07-28",
  "io.modelcontextprotocol/clientCapabilities": {
    "extensions": {
      "io.kedgeflow/governed-mcp": {"profile": "KF-MCP-0.1"}
    }
  }
}
```

The KedgeFlow capability is necessary for consequential calls. Registered reads
can use ordinary MCP capabilities, but still require verified identity, explicit
tool authorization, and the registered closed parameter contract. MCP tool
`readOnlyHint` does not authorize a read and never classifies an unknown tool.
Discovery publishes the local registry; it does not copy an untrusted catalog.

A consequential call without a grant receives negotiated custom application
error `-32001 NEEDS_EVIDENCE`, with a schema-valid `RemediationContract` in
`error.data`. The proxy binds the exact action and canonical parameters; its
initial `proposal_digest` is null. An Agent Adapter must freeze the **full**
proposal, acquire evidence, obtain admission and authority, then resubmit.
Missing evidence is not admission. Automatic evidence acquisition and SDK retry
adaptation are not implemented here. `make sdk-test` executes the pinned official
`@modelcontextprotocol/client` 2.3.0 with Node 20 or newer. The SDK itself is
unmodified: documented Client capabilities/protocol-pin options and a fetch hook
add the grant header. The executed sequence is discovery, tools/list,
`NEEDS_EVIDENCE`, preissued signed-fixture resubmission, terminal receipt, and
`NONCE_CONSUMED` replay refusal. Exactly one mock effect and credential are
asserted. The SDK fixture uses a disclosed synthetic AuthFunc over loopback;
cryptographic authentication is independently covered by the Go suite. This is
a narrow SDK protocol test, not proof that an unmodified agent harness can
acquire evidence or admission automatically. The optional SDK test skips when
Node/package dependencies are absent unless `KF_REQUIRE_SDK=1` is set.

The SDK test uncovered missing catalog cache fields; tools/list now explicitly
returns `ttlMs: 0` and `cacheScope: private`. Package versions and integrity are
locked in `sdk/package-lock.json`. Executed logs and a machine-readable report
are in `results/raw-official-sdk-tests.txt` and
`results/official-sdk-client.json`; the initial failed catalog check is retained
in `results/raw-official-sdk-initial-failure.txt`. The implementation follows
the [official SDK protocol-version guide](https://ts.sdk.modelcontextprotocol.io/v2/protocol-versions)
and [client calling guide](https://ts.sdk.modelcontextprotocol.io/v2/clients/calling).

`Mcp-KedgeFlow-Grant` carries **unpadded base64url of the complete signed grant
envelope**, not an opaque grant identifier. Exactly one header/call is accepted.
The proxy verifies the trusted Ed25519 signature, the KF-JSON-0.2 profile/schema,
validity, audience, user issuer/subject, workload, DPoP thumbprint, delegation
digest, action/version/digest, exact canonical parameters, resource incarnation,
predicate and adapter descriptor. It cannot bootstrap a root from a request.

The inline header value is capped at **6 KiB**. An optional, separately negotiated
[KF-GRANT-REF-0.1 transport](../spec/GRANT_REFERENCE_PROFILE.md) accepts one
`Mcp-KedgeFlow-Grant-Ref` value: the existing 64-hex digest of the **complete signed
envelope**. The proxy retrieves the original envelope from an operator-pinned,
verified mTLS resolver, bounds it to 64 KiB and two seconds, then verifies and
claims it exactly like an inline grant. Duplicate/mixed carriage, caller URLs,
digest substitution and missing negotiation fail closed. Carriage changes do
not permit replay. The CLI's optional `grant_resolver_endpoint` and
`grant_resolver_ca` must be configured together; otherwise the extension is
disabled. Resolver requests contain scoped identity context and no caller token,
DPoP proof, cookie or target credential. Production store-side retrieval ACLs,
publication, immutable retention, rate/concurrency bounds and real intermediary
header budgets remain deployment work. No production grant-store service is
supplied. The signed schema and original remediation carriage are unchanged.

The accepted adapter profile is deliberately narrow: one `version_eq` clause,
one resource, the `FencingToken` Level A mock guard, a nondelegated leaf root, and
`dispatch_bound`. CommitBound, Saga budgets, reservation clauses, multi-resource
predicates, Level B/C and other guard primitives fail closed. The mock guard
atomically checks resource version and fence while changing its in-memory state;
**no SQL engine or Kubernetes node drain was executed**. Level A applies to that
mock state predicate only. Grant/policy/evidence validity at a later target commit
is not implemented and is not inferred from the pre-dispatch checks.

## Authority ledger and recovery

Keys are partitioned by conflict domain and root. This gives independent key
names, not separate Raft groups or automatic horizontal throughput scaling.
`Claim` atomically compares the complete current root generation/fence/active
grant/status, signed grant digest, unused nonce, unused attempt, policy reference
and ownership epoch. It writes the claimed root, consumed nonce, attempt and a
durable `claimed_not_dispatched` outbox record in that same transaction.

`AuthorizeDispatch` rechecks those bindings and current policy/owner immediately
before dispatch, and advances the outbox. It is still separate from the remote
physical effect. Policy publication is an atomic monotonic test/authority helper;
it is not a complete signed Policy Authority, enrollment or revocation service.
`Replace` races against Claim on the same root and can replace only an unclaimed
generation, with a higher fence and an unused successor nonce. A claimed or
Unknown root cannot be reset. `NONCE_CONSUMED` denotes an already consumed nonce;
other failed conditions return a refusal without dispatch.

Token exchange follows claim and is bounded across workload assertion, HTTP and
body processing by the shorter exchange/grant/parent budget. The CLI reuses one
mTLS client/transport pool. `expires_in` is conservatively measured from exchange
start for local usability; receipt-time plus TTL must also fit grant validity,
so a broader bearer token is refused rather than locally clipped. Workload
assertion providers must honor their context. The proxy rechecks the signed
grant after exchange and after the final ledger round trip, and bounds target
I/O by signed expiry. A pre-send gate/request deadline does not prove target
acceptance before expiry or cancel an already sent effect; required acceptance
or commit deadlines need target enforcement. An uncertain sent request retains
consumption and requires reconciliation.

`Issue`, `PublishPolicy` and `Replace` are **trusted authority-side library
operations**, not public agent endpoints. Callers must authenticate and verify
their signed authority records before invoking them; the gateway HTTP handler
does not expose them. Production deployments must protect etcd credentials and
issuer keys. Stable admission issuance-key deduplication, Saga accounting,
cross-root capacity reservations, and complete external-writer coverage are not
implemented by this leaf-root slice.

Outcome writes retain the root/nonce. A response severed after the mock effect
produces `OUTCOME_UNKNOWN`. `Reconcile` accepts an authenticated Resource Adapter
query contract with exact attempt/root/grant correlation and target reference;
missing or uncorrelated observations cannot become completion. The implemented
test query is a mock authoritative observation, not a production target client.
A correlated committed observation closes Unknown without re-execution or
restoring authority. Outbox workers must reconcile rather than blindly redeliver.
Signed Attempt Receipt issuance, a persistent reconciliation scheduler and
reservation retention are specified elsewhere but are not implemented here.

## Identity and credential boundary

`DualAuthenticator` implements a narrow cryptographic access-token profile:
verified client TLS chain with exactly one SPIFFE URI SAN; pinned Ed25519 OAuth
access-token issuer; exact issuer/audience/subject; `cnf.jkt`; and Ed25519 RFC 9449
DPoP proof binding method, external URL, token hash, time and unique proof ID.
It accepts `typ=at+jwt` access tokens, not OIDC ID tokens as delegation authority.
The user issuer must have granted the underlying OBO and tool permissions; DPoP
alone establishes neither. The delegation digest matches the schema's canonical
delegation descriptor; token digest is SHA-256 over its raw UTF-8 octets.

The replay cache for DPoP proof IDs is local and bounded by time, not distributed.
Replicas require a shared replay store/nonce profile for complete DPoP replay
protection. Globally single-use grant Claim is independently backed by etcd.
Issuer discovery, JWKS rotation, full OAuth metadata discovery, SPIRE enrollment,
multi-algorithm token support and malicious gateway/issuer compromise are outside
this reference slice. The CLI requires TLS 1.3 and verified client certificates.

Before the CLI invokes the Proxy, `EndpointPolicy` pins the request to the trusted
`external_url` authority and exact unescaped path. Host names are compared as
ASCII case-insensitive names; omission of HTTPS port 443 is equivalent to an
explicit 443, and bracketed IPv6 literals are numerically canonicalized. Other
ports, DNS aliases, loopback IP aliases, trailing dots, malformed authorities and
duplicate Host representations are refused with HTTP 421. Query parameters,
including an empty query marker, fragments and absolute-form requests are refused
with HTTP 400. Different paths, trailing slashes and encoded path aliases are
refused with HTTP 404. The configured URL requires an explicit path and cannot
contain userinfo, query, fragment, encoded characters, dot segments or repeated
slash separators. These comparisons perform no DNS lookup and ignore forwarding
headers. The original configured audience and DPoP URL remain unchanged.

This is a native-client profile: **any Origin header is refused with HTTP 403**,
including same-origin, null, blank and duplicate values. There is no wildcard
localhost or allowed-origin option. A native client without Origin proceeds to
the existing mTLS and OAuth/DPoP authentication, authorization, grant and ledger
checks; absence of Origin supplies no identity or authority. All boundary
refusals occur before parsing the tool body or reaching authentication, Claim or
token exchange. Complete MCP HTTP transport conformance remains an acceptance
gate: these checks do not verify MCP-Protocol-Version, Mcp-Method or Mcp-Name
header/body consistency.

The wrapper governs only HTTP requests delivered to this gateway. It does not
intercept a harness's built-in shell, filesystem or native tools, restrict the
agent's direct network access, or isolate credential files from another process
running under the same UID. Such bypass paths need a separately enforced OS,
credential and egress boundary; endpoint pinning and TLS alone do not provide it.

`RFC8693Broker` is an executable mTLS client for a compatible authorization server.
Only after Claim does it submit the verified user access token and an explicitly
provided workload assertion, fixed target audience and scope. It transmits the
signed grant and attempt as named KedgeFlow authorization-server extension
parameters (`kedgeflow_grant`, `kedgeflow_grant_digest`,
`kedgeflow_attempt_id`). These are **not RFC 8693 standard parameters**. A compatible
issuer must verify that boundary and its claimed-attempt correlation before
minting. The client rejects missing bindings, insecure TLS, unexpected scope/type,
excessive lifetime and redirects. A target credential must expire within the
grant's remaining lifetime.

This is not a universal AWS/STS, database or SaaS exchange adapter. Those targets
need provider-specific issuer/credential adapters and target-side authorization.
The proxy constructs a fresh upstream request: it forwards no inbound OAuth or
DPoP token, grant, cookie, credential header or arbitrary request routing header.
It adds a distinct target credential and trusted adapter fence, attempt, grant
digest and resource-incarnation parameters. The mock target returns a terminal
receipt bound to those fields. A generic MCP complete result, tool business error,
missing receipt or mismatched receipt leaves the attempt Unknown; it cannot prove
enterprise commit. Read credentials also remain at the gateway. Telemetry contains
tool classification only, not arguments, grant bodies or credentials.

## CLI configuration

`cmd/kf-proxy/main.go` loads one trusted JSON object with these closed fields.
It rejects duplicate keys, extra JSON values and unknown or case-aliased top-level
field names before loading credentials or starting the listener:

| Fields | Meaning |
| --- | --- |
| `listen`, `external_url` | Listener address and fixed HTTPS endpoint with an explicit path; pins Host/path and remains the exact authenticated audience/DPoP URL. |
| `certificate`, `private_key`, `workload_ca` | Gateway certificate/key and incoming agent workload trust bundle. |
| `grant_key_id`, `grant_public_key_base64` | Trusted grant issuer key ID and 32-byte Ed25519 public key in standard base64. |
| `oidc_issuer`, `oidc_public_key_base64` | Explicit user authorization issuer and its pinned access-token verification key. |
| `etcd_endpoints`, `etcd_prefix`, `etcd_ca` | Verified HTTPS etcd endpoints, dedicated authority namespace and CA. |
| `broker_endpoint`, `broker_ca`, `target_audience`, `target_scope` | Compatible HTTPS token issuer, trust bundle and configured target scope. |
| `actor_workload`, `actor_token_file` | Exact workload permitted to use the provider-supplied signed actor assertion. |
| `target_url`, `target_ca`, `read_token_file` | Fixed protected upstream HTTPS URL, target trust bundle and read credential. |
| `tools` | Trusted `ToolDescriptor` records with identity, authorization, exact adapter and predicate contracts. |

The sample tests exercise the node-version action contract. Extending tools
requires implementing and registering the closed parameter schema, native guard,
complete predicate coverage and target outcome contract. A tool's emergence or
catalog annotation cannot grant itself authority or silently choose a lower
guarantee.
