package kedgeflow

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
)

type mockQuery struct {
	Target   *mockTarget
	G        Grant
	Digest   string
	Mismatch bool
	Unknown  bool
	Calls    int
}

func (q *mockQuery) Query(_ context.Context, id string) (AuthoritativeObservation, error) {
	q.Calls++
	q.Target.mu.Lock()
	defer q.Target.mu.Unlock()
	status := "unknown"
	if !q.Unknown && q.Target.lastAttempt == id && q.Target.effects == 1 {
		status = "committed"
	}
	root := q.G.RootID
	if q.Mismatch {
		root = "wrong-root"
	}
	return AuthoritativeObservation{id, root, q.Digest, status, "mock://node-a/version-2"}, nil
}
func TestUnknownAuthoritativeReconciliation(t *testing.T) {
	g, raw, v, id, td := fixture(t, "reconcile")
	l := ledger(t, g, raw, v)
	target := &mockTarget{version: 1, unknown: true}
	up := httptest.NewServer(target)
	defer up.Close()
	broker := &testBroker{}
	p := &Proxy{Verifier: v, Ledger: l, Auth: AuthFunc(func(*http.Request) (Identity, error) { return id, nil }), Broker: broker, Adapter: &HTTPAdapter{up.Client(), up.URL, "mock-target", "target-read-token"}, Tools: map[string]ToolDescriptor{"node_drain": td}}
	w := call(p, requestBody("node_drain", `{"node":"node-a","expected_version":1}`), HeaderGrant(raw))
	if errorMessage(w) != "OUTCOME_UNKNOWN" {
		t.Fatal(w.Body.String())
	}
	var resp rpcResponse
	_ = json.Unmarshal(w.Body.Bytes(), &resp)
	data := resp.Error.Data.(map[string]any)
	attemptID := data["attempt_id"].(string)
	a, e := l.Status(context.Background(), g, attemptID)
	if e != nil || a.Status != "unknown" {
		t.Fatal(a, e)
	}
	_, gd, _ := v.Verify(raw)
	q := &mockQuery{Target: target, G: g, Digest: gd, Unknown: true}
	if a, e = l.Reconcile(context.Background(), g, attemptID, q); e != nil || a.Status != "unknown" {
		t.Fatal("absence became completion", a, e)
	}
	q.Unknown = false
	q.Mismatch = true
	if _, e = l.Reconcile(context.Background(), g, attemptID, q); e == nil {
		t.Fatal("uncorrelated observation accepted")
	}
	q.Mismatch = false
	if a, e = l.Reconcile(context.Background(), g, attemptID, q); e != nil || a.Status != "committed" {
		t.Fatal(a, e)
	}
	if _, e = l.Claim(context.Background(), g, gd, "recovery-retry"); !errors.Is(e, ErrRefused) {
		t.Fatal("reconciliation restored authority", e)
	}
	target.mu.Lock()
	effects := target.effects
	target.mu.Unlock()
	if effects != 1 || broker.calls.Load() != 1 || q.Calls != 3 {
		t.Fatal("recovery redispatched/minted credential", effects, broker.calls.Load(), q.Calls)
	}
	t.Log("UNKNOWN effect committed then TCP response closed; missing observation retained Unknown; mismatched observation rejected; authoritative correlated observation closed Committed; root/nonce retained; dispatches=1")
}
func TestDirectTargetCredentialBypass(t *testing.T) {
	target := &mockTarget{version: 1}
	up := httptest.NewServer(target)
	defer up.Close()
	body := requestBody("node_drain", `{"node":"node-a","expected_version":1,"kf_fence":1,"kf_attempt_id":"forged"}`)
	r, e := http.NewRequest("POST", up.URL, bytes.NewReader(body))
	if e != nil {
		t.Fatal(e)
	}
	r.Header.Set("Mcp-KedgeFlow-Grant", "forged-claim")
	r.Header.Set("Authorization", "DPoP agent-oauth-token")
	resp, e := up.Client().Do(r)
	if e != nil {
		t.Fatal(e)
	}
	_ = resp.Body.Close()
	target.mu.Lock()
	effects := target.effects
	target.mu.Unlock()
	if resp.StatusCode != http.StatusUnauthorized || effects != 0 {
		t.Fatal("direct agent credential bypassed target")
	}
}
