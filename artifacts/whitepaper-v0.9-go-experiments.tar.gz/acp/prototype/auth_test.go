package kedgeflow

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/base64"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"testing"
	"time"
)

func jwt(t *testing.T, h, c any, key ed25519.PrivateKey) string {
	t.Helper()
	hb, e := json.Marshal(h)
	if e != nil {
		t.Fatal(e)
	}
	cb, e := json.Marshal(c)
	if e != nil {
		t.Fatal(e)
	}
	s := base64.RawURLEncoding.EncodeToString(hb) + "." + base64.RawURLEncoding.EncodeToString(cb)
	return s + "." + base64.RawURLEncoding.EncodeToString(ed25519.Sign(key, []byte(s)))
}
func TestDualIdentityAndDPoP(t *testing.T) {
	issuerPub, issuerPriv, _ := ed25519.GenerateKey(rand.Reader)
	proofPub, proofPriv, _ := ed25519.GenerateKey(rand.Reader)
	jwk := edJWK{"OKP", "Ed25519", base64.RawURLEncoding.EncodeToString(proofPub)}
	b, _ := marshalCanonical(jwk)
	hash := sha256.Sum256(b)
	jkt := base64.RawURLEncoding.EncodeToString(hash[:])
	uri, _ := url.Parse("spiffe://test/agent")
	cert := &x509.Certificate{URIs: []*url.URL{uri}}
	for _, name := range []string{"valid", "no_verified_chain", "expired_access_token", "wrong_audience", "wrong_user_signature", "wrong_method", "wrong_uri", "wrong_access_token_hash", "wrong_dpop_signature", "proof_replay"} {
		t.Run(name, func(t *testing.T) {
			a := &DualAuthenticator{Issuer: "https://identity.test", Audience: "https://gateway.test/mcp", ExternalURL: "https://gateway.test/mcp", IssuerKey: issuerPub}
			ac := accessClaims{ISS: a.Issuer, SUB: "user", AUD: a.Audience, EXP: time.Now().Add(3 * time.Minute).Unix(), IAT: time.Now().Unix(), Scope: "mutate read"}
			ac.CNF.JKT = jkt
			if name == "expired_access_token" {
				ac.EXP = time.Now().Add(-time.Second).Unix()
			}
			if name == "wrong_audience" {
				ac.AUD = "https://other.test"
			}
			userKey := issuerPriv
			if name == "wrong_user_signature" {
				_, userKey, _ = ed25519.GenerateKey(rand.Reader)
			}
			token := jwt(t, jwtHeader{Alg: "EdDSA", Typ: "at+jwt"}, ac, userKey)
			ath := sha256.Sum256([]byte(token))
			dc := dpopClaims{randomID(), "POST", a.ExternalURL, time.Now().Unix(), base64.RawURLEncoding.EncodeToString(ath[:])}
			if name == "wrong_method" {
				dc.HTM = "GET"
			}
			if name == "wrong_uri" {
				dc.HTU = "https://other.test/mcp"
			}
			if name == "wrong_access_token_hash" {
				dc.ATH = "bad"
			}
			proofKey := proofPriv
			if name == "wrong_dpop_signature" {
				_, proofKey, _ = ed25519.GenerateKey(rand.Reader)
			}
			jb, _ := json.Marshal(jwk)
			proof := jwt(t, jwtHeader{Alg: "EdDSA", Typ: "dpop+jwt", JWK: jb}, dc, proofKey)
			r := httptest.NewRequest("POST", a.ExternalURL, nil)
			r.Header.Set("Authorization", "DPoP "+token)
			r.Header.Set("DPoP", proof)
			r.TLS = &tls.ConnectionState{PeerCertificates: []*x509.Certificate{cert}, VerifiedChains: [][]*x509.Certificate{{cert}}}
			if name == "no_verified_chain" {
				r.TLS.VerifiedChains = nil
			}
			if name == "proof_replay" {
				if _, e := a.Authenticate(r); e != nil {
					t.Fatal(e)
				}
			}
			id, e := a.Authenticate(r)
			if name == "valid" {
				if e != nil || id.Subject.Sub != "user" || id.WorkloadID != uri.String() || !id.Scopes["mutate"] || len(id.DelegationDigest) != 64 {
					t.Fatal(id, e)
				}
			} else if e == nil {
				t.Fatal("invalid identity/proof accepted")
			}
		})
	}
}
func TestCanonicalAndRequiredEnvelope(t *testing.T) {
	if b, e := Canonical([]byte(`{"z":1,"a":2}`)); e != nil || string(b) != `{"a":2,"z":1}` {
		t.Fatal(string(b), e)
	}
	for _, bad := range []string{`{"a":1,"a":2}`, `{"x":"\ud800"}`, `{"x":NaN}`, `{} {}`} {
		if _, e := Canonical([]byte(bad)); e == nil {
			t.Fatal("noncanonicalizable accepted", bad)
		}
	}
	g, raw, v, _, _ := fixture(t, "required")
	if _, _, e := v.Verify(raw); e != nil {
		t.Fatal(e)
	}
	_ = g
	var env map[string]json.RawMessage
	_ = json.Unmarshal(raw, &env)
	delete(env, "signature")
	b, _ := json.Marshal(env)
	if _, _, e := v.Verify(b); e == nil {
		t.Fatal("missing field accepted")
	}
	_ = osWriteResult("signed-grant.json", raw)
	_ = osWriteResult("grant-public-key.txt", []byte(base64.StdEncoding.EncodeToString(v.Keys["issuer-test"])))
}
func osWriteResult(name string, b []byte) error { return writeResult(name, b) }

// Compile-time conformance keeps production authentication pluggable without
// accidentally substituting header strings for a verified Identity.
var _ Authenticator = (*DualAuthenticator)(nil)
var _ http.Handler = (*Proxy)(nil)
