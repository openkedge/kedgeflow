# KedgeFlow v0.9 verification record

This is the historical 4–5 October Go and shared-contract verification record. It does not report Rust runtime results or the final frozen PDF layout. The primary Rust evidence is retained in the implementation repository at `docs/RUST_VERIFICATION.md`; the final paper and contract hashes are recorded in [the freeze manifest](../archive/whitepaper-v0.9/FREEZE.json).

Date: 4 October 2026. This record distinguishes the delivered candidate contracts and executed local checks from deployment conformance.

## Machine contracts and compatibility vectors

The complete Draft 2020-12 schema validates Proposal, Certificate, Grant, CTD v1.0, Attempt Receipt and supporting records. The PDF appendix indexes the external schema, envelope types and fixture digests instead of printing the full JSON. The acp schema and the sibling openkedge/code/kedgeflow schema are equal as parsed JSON objects. CTD YAML decodes to the signed JSON descriptor payload.

Executed from the repository root:

    PYTHONPATH=/private/tmp/kedgeflow-schema-deps /Users/joehe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 acp/spec/validate.py
    PYTHONPATH=/private/tmp/kedgeflow-schema-deps /Users/joehe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m unittest discover -s acp/spec/tests -v
    /Users/joehe/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node acp/spec/tests/cross_language.mjs

The temporary dependency directory contains the pinned Python dependencies from spec/requirements.txt. For another machine, install those dependencies into an isolated environment and use its Python executable.

Results: all 13 signed Ed25519 envelope fixtures and declared cross-record bindings passed; **21 tests passed**; the independent Node verifier passed signatures, JCS hashes, approval challenges, numeric-key ordering and UTF-16 property ordering. Raw outputs are in [spec/results](../spec/results/). Software authenticator fixtures cannot discharge a hardware-required profile.

The sibling package's offline validator was also run read-only from the repository root:

    PYTHONPATH=/private/tmp/kedgeflow-schema-deps PYTHONDONTWRITEBYTECODE=1 /Users/joehe/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 ../code/kedgeflow/spec/validate.py

Its schema, all 13 signed Ed25519 envelopes, declared cross-record bindings, OAuth/DPoP vectors, CTD YAML and A2A reference passed. The [raw package result](../spec/results/package-fixtures.txt) verifies these mirrored contract artifacts, not full conformance of the package runtime.

## Real etcd claim races

The proxy integration suite starts three embedded **etcd 3.6.5 servers**, each with a distinct data directory, peer/client endpoint and actual Raft membership. This is a real three-member cluster on one host, using loopback networking. It is not a mock key-value store or a multi-host performance measurement.

Environment: Go 1.26.1, macOS/darwin, arm64, 10 logical CPUs.

| Roots | Contenders per root | Attempted claims | Successful claims | Refused claims |
| ---: | ---: | ---: | ---: | ---: |
| 1 | 32 | 32 | 1 | 31 |
| 1 | 128 | 128 | 1 | 127 |
| 8 | 32 | 256 | 8 | 248 |
| 8 | 128 | 1,024 | 8 | 1,016 |
| 32 | 32 | 1,024 | 32 | 992 |
| 32 | 128 | 4,096 | 32 | 4,064 |
| **Total** | | **6,560** | **82** | **6,478** |

Every root had exactly one successful claim, with zero transport errors in the reported run. One hundred claim/replacement races had one exclusive winner; stale generation, wrong fence, consumed nonce and replacement of a claimed root were refused.

The raw logs include elapsed milliseconds and attempted claims per second. Those rates are dominated by refused claims and should not be presented as successful target-mutation throughput. A single-host cluster does not establish wide-area latency, quorum-failure availability, restore safety or cross-cluster atomicity. Conflict-domain prefixes do not shard the Raft log.

The proxy writes an atomic claim/dispatch-intent outbox and performs a final policy/owner/root/nonce dispatch gate. Its supported target path uses dispatch-bound validity and an atomic mock version/fence/state predicate. It rejects commit-bound paths because the mock target does not enforce grant/policy/evidence validity at the physical commit point. The ledger slice does not implement composite saga allocation or capacity reservations.

## Proxy boundary and recovery

The integration suite exercises missing-grant remediation, exact parameter/identity bindings, tampered grants, nonce consumption, multiple gateway replicas, denied and authorized reads, protected batches, unsupported tools/predicates, false target guards, unavailable ledger/broker, credential leakage, postclaim policy changes, real signature/proof validation, and metadata discovery.

The unknown-outcome test commits a mock effect, severs the TCP response, retains the claimed root/nonce, rejects an uncorrelated observation, and reconciles a correlated authoritative observation without redispatch. The effect count remains one. Direct use of the agent token against the mock target is refused.

The broker test exercises an RFC 8693 form request over mTLS to a test authorization server, including the exact grant binding and response scope/lifetime checks. Real enterprise federation, directory integration, target credential issuance, key rotation and distributed DPoP replay storage are separate deployment work.

Native macOS and static Linux arm64 builds, CLI startup/help, Go vet and race-detector suites passed. Generated Grant and Remediation outputs also passed the complete v0.9 schema with format checking. Raw results and the exact runnable commands are in [prototype/results](../prototype/results/) and [prototype/README.md](../prototype/README.md). The source includes a non-root Docker build recipe. Docker is unavailable in this environment, so no image build or container launch is claimed. The existing Unix socket was also probed through the Docker API; both normal and authorized probes failed to connect, confirming no reachable engine. A focused race-detector suite verifies that an ordinary MCP complete result is not proof of an enterprise commit: missing/mismatched terminal receipts, tool errors and asynchronous results remain Unknown. The supported mock target receipt must bind the exact attempt, grant digest, resource incarnation, fence and terminal status. No live Kubernetes/SQL target is claimed.

## Local endpoint and configuration checks

The reference CLI pins a trusted HTTPS authority and explicit unescaped path. It rejects alternate Host authorities/ports, ambiguous paths, query/fragment or absolute-form targets before authentication, claim or credential issuance. Its native-client profile refuses any supplied Origin header, including blank, null and duplicate values; human browser review uses a separate Evidence Provider origin. No-Origin requests still require caller authentication. Accepted hostname/default-port equivalences leave the configured authenticated URL unchanged for proof validation. Closed configuration parsing rejects duplicate keys, case aliases, unknown fields and trailing JSON.

Five endpoint-policy test groups and one closed-configuration group passed, including concurrent requests and refusal-before-downstream assertions. Focused logs are [endpoint boundary](../prototype/results/raw-endpoint-boundary-tests.txt) and [CLI configuration](../prototype/results/raw-endpoint-config-tests.txt). Go vet, native macOS and static Linux arm64 builds, and CLI help passed; build evidence is [endpoint-build.txt](../prototype/results/endpoint-build.txt).

The final full suite was rerun with the SDK required:

    KF_REQUIRE_SDK=1 make race

Executed in acp/prototype: proxy race suite PASS (14.751 seconds), CLI suite PASS (1.431 seconds), including the official SDK flow and the 6,560-claim matrix. The [complete final log](../prototype/results/raw-polish-race-tests.txt) retains the results.

These checks do not provision a workstation sandbox, protect a keychain item, intercept native Claude Code/Codex tools or implement a Git/filesystem Resource Adapter. The reference slice also does not validate every MCP HTTP requirement: MCP-Protocol-Version, Mcp-Method and Mcp-Name header/body consistency remain outside its tested profile. SDK compatibility is not full transport conformance.

## Official MCP client SDK integration

The pinned official @modelcontextprotocol/client **2.3.0** runs unmodified Client and StreamableHTTPClientTransport against the proxy using Node **25.2.1** and protocol **2026-07-28**. The race-detector integration test passed discovery, tools/list, structured NEEDS_EVIDENCE (-32001), signed-fixture grant resubmission with a verified mock terminal receipt, and NONCE_CONSUMED replay rejection. The Go assertions verify exactly one target effect and one issued credential. Documented client options negotiate the capability; a custom fetch function injects the grant header without modifying SDK source or RPC bodies.

Reproduce with make sdk-test in acp/prototype, using the pinned package lock. The [raw success log](../prototype/results/raw-official-sdk-tests.txt) and [machine-readable report](../prototype/results/official-sdk-client.json) retain the exact flow. The [initial failure log](../prototype/results/raw-official-sdk-initial-failure.txt) records the SDK's rejection of missing catalog cache metadata; the proxy now emits ttlMs=0 and cacheScope=private.

This test uses a disclosed synthetic AuthFunc over loopback and a preissued signed grant. The independent proxy authentication tests exercise the real signature/proof verifier. It establishes this SDK's interoperability with the negotiated gateway slice, without claiming automatic admission by an unmodified agent harness, a full Cedar-service-to-proxy deployment, or a cross-runtime interoperability matrix.

## Cedar admission and WebAuthn service checks

The bounded service uses real pinned cedar-policy/cedar-go v1.8.0 and JSON Schema validation. Its tests exercise a local HTTP challenge → verified WebAuthn assertion → signed witness → Cedar admission → schema-valid signed certificate flow. Missing/stale/future/unknown capacity evidence defers, violated evidence denies, and satisfied obligations admit only under a Cedar permit. Cedar forbid and evaluation diagnostics deny without issuing a certificate.

WebAuthn tests use real Ed25519 and ES256 signature operations over authenticatorData plus SHA-256(clientDataJSON), with software-generated test keys. They reject challenge, origin, RP ID, proposal, template and policy substitutions; absent UV; unregistered credentials; invalid signatures; post-review parameter changes; and provider impersonation. An eight-contender assertion replay race admits one consumption. Hardware-required configuration rejects the software/test-only enrollment.

The runnable CLI serves admission, review challenge/verification, review rendering and health status with configured mTLS and DPoP authentication. Caller authentication in the local service tests uses an explicitly injected test identity, while the proxy's independent auth tests exercise the real signature/proof verifier. Physical device enrollment, attestation-chain validation, an actual browser ceremony, enterprise directory provisioning and distributed review/replay state are not tested.

Reproduction commands and endpoint/configuration contract are in [services/README.md](../services/README.md); raw output is retained under services/results/. The service tests and race detector passed. These service and proxy examples have distinct supported action profiles; a complete service-to-proxy deployment is not claimed.

## Artifact and deployment distinction

The paper's Kubernetes maintenance trace is a blueprint: Level A SQL reservation, followed by Level C physical draining. The mock adapter tests an analogous atomic state guard without running SQL or Kubernetes.

Full production conformance still requires a declared resource/action scope, all relevant writers and bypass routes, trusted identity and credential provisioning, hardware enrollment and renderer assurance, durable receipts/retention, static/JIT freshness, saga allocation/compensation under faults, and additional independent peer/runtime exchange. The local checks establish only their named artifact properties.

## Adoption scope

The proposed adoption stages distinguish shadow observation from an enforced pilot, production privilege cutover and wider coordination. Atomic grant claim is required on every grant-backed route from the pilot onward. Security/GRC, platform/SRE and application/developer responsibilities are assigned, and the onboarding record requires actual bypass, fault and cost evidence. No adoption forecast, compliance certification, universal observation percentage or latency/cost benefit is claimed.

## Manuscript build and layout

The current 67-page PDF (5 October 2026, iteration 3) built with make deliverables
and TeX Live 2026. The final LaTeX log has no warnings, undefined references or
overfull boxes. All 67 pages were rendered and visually checked; new timing,
reference-carriage, escalation, OS-boundary, acceptance and executed-check
pages received detailed inspection. Existing workflow, OpenFlow, Component Map,
local gateway and adoption figures remain intact. Current page counts,
schema/package equality and PDF SHA-256 are recorded in
[V0_9_ARTIFACT_CHECK.json](V0_9_ARTIFACT_CHECK.json); prior round-specific artifact
records preserve their 64-page builds.


## Mock-review iteration 1

The first audience-driven revision replaces Figure 3's periodic-table framing with a responsibility/privilege map and adds scoped first-adoption work packages and an owned friction register. These are architecture/adoption refinements, not new empirical results. The five reviews and response map are under docs/mock-reviews/. Reference code and machine contracts are unchanged; the existing named code checks remain applicable.


## Mock-review iteration 2

All five personas reassessed the first iteration and audited the second refinement. Workflow/status handling, pre-claim versus post-claim cancellation, outage durability, safe cutover/restore/exit and buyer control/evidence records are now explicit. The final artifact includes refined Figure 3 labels and the new operating/procurement tables. The researcher cancellation clarification was applied; no remaining material manuscript issue was identified in the closing audits.

Iteration 2's 64-page PDF was rebuilt and fully rendered. Machine contracts and
reference code did not change in either of those two iterations; their prior
named checks were not rerun or promoted into new deployment results. Independent
production/pilot evidence remains required. Round-specific response and artifact
records preserve both iterations.

## Mock-review iteration 3: implementation watchpoints (5 October 2026)

Five simulated audience lenses reassessed the new shell, exchange-latency,
unknown-effect and large-header concerns. Independent source/code reviews
prompted completion-checkpoint clarification, store ownership and exact-profile
links, and effectful versus query-only escalation behavior. Reports and the
applied response are under docs/mock-reviews/.

Reference code changed in this round. The optional proposed KF-GRANT-REF-0.1
binding accepts a full signed-envelope digest only after authentication/scope
and extension activation. Its client uses a pinned verified mTLS endpoint,
scoped context without caller credentials, no redirects, a two-second parent-
bounded deadline and 64 KiB response cap. Original grant validation and atomic
claim are unchanged. Store ACL/publication/retention and rate/concurrency controls
are external deployment work; the client is not a production grant-store service.

The [focused reference suite](../prototype/results/raw-grant-reference-tests.txt)
passed eight top-level groups and fifty-nine subcases (6.818 seconds). It tests
real TLS 1.3 mutual authentication, caller-context and credential separation,
redirect/size/deadline bounds, optional discovery/activation, duplicate/mixed/
malformed carriage, wrong signature/digest/identity/parameters/expiry, failure
before claim, and reference/inline single-use conservation. A 14,272-byte signed
mock envelope has a 19,030-byte inline value: inline refusal leaves authority
unclaimed, and authenticated reference retrieval produces one claim, credential
and mock effect. The long bound adapter description changes size without adding
multi-predicate, B/C, commit-bound or saga support.

Broker regressions inject deterministic clock advances for assertion/response
latency, expired authority, exhausted request budgets and broad token lifetime.
Local usable expiry is conservative from exchange start; receipt-time plus
TTL must still fit the grant. Oversized token responses are refused even when
the bounded prefix alone would be valid JSON. Proxy tests independently reject
late alternate-broker output and expiry after final ledger authorization,
record no dispatch, preserve nonce consumption and refuse replacement.
Target acceptance/commit deadlines still require resource-side enforcement;
request cancellation after a possible send does not prove no effect.

The final [complete race log](../prototype/results/raw-watchpoints-race-tests.txt)
records `KF_REQUIRE_SDK=1 GOTELEMETRY=off make race`: proxy PASS (20.938 seconds),
CLI PASS (1.869 seconds), including the real three-member single-host etcd
matrix and official MCP SDK integration. Go vet passed, native macOS arm64 and
static Linux arm64 builds passed, and native CLI help ran. Linux execution and
Docker launch were not performed. The complete signed schema remains equal to
the sibling package and all normative fixtures are unchanged.

The 67-page PDF was rebuilt cleanly and fully rendered/inspected. Real workstation
isolation, provider-tail budgets, grant-store policy, intermediary route limits,
legacy-target reconciliation/escalation and target deadline enforcement remain
explicit adoption gates. No operating-value or production-conformance result is
inferred from these local checks.
